import { err, ok, type Result } from './result.ts';

export type PhoneError = 'PHONE_INVALID' | 'PHONE_UNSUPPORTED_REGION';
export type NormalizedPhone = { readonly e164: string; readonly national: string };

const PERSIAN_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
const ARABIC_DIGITS = '٠١٢٣٤٥٦٧٨٩';

export function toLatinDigits(input: string): string {
  let out = '';
  for (const ch of input) {
    const p = PERSIAN_DIGITS.indexOf(ch);
    const a = ARABIC_DIGITS.indexOf(ch);
    out += p >= 0 ? String(p) : a >= 0 ? String(a) : ch;
  }
  return out;
}

/** Characters users commonly paste: spaces, dashes, brackets, ZWNJ/ZWSP, bidi marks. */
const NOISE = /[\s\-().\u200b\u200c\u200d\u200e\u200f\u202a-\u202e\u2066-\u2069]/g;

/**
 * MVP supports Iranian mobile numbers only. Accepts:
 * +98912…, 0098912…, 98912…, 0912…, 912… (Persian/Arabic digits allowed).
 * Anything else is rejected explicitly rather than guessed.
 */
export function normalizeIranMobile(raw: string): Result<NormalizedPhone, PhoneError> {
  if (typeof raw !== 'string' || raw.length > 40) return err('PHONE_INVALID');
  let s = toLatinDigits(raw).replace(NOISE, '');
  if (s.startsWith('+')) {
    if (!s.startsWith('+98')) return /^\+\d{6,15}$/.test(s) ? err('PHONE_UNSUPPORTED_REGION') : err('PHONE_INVALID');
    s = s.slice(3);
  } else if (s.startsWith('0098')) {
    s = s.slice(4);
  } else if (s.startsWith('98') && s.length === 12) {
    s = s.slice(2);
  } else if (s.startsWith('0')) {
    s = s.slice(1);
  }
  if (!/^9\d{9}$/.test(s)) return err('PHONE_INVALID');
  return ok({ e164: `+98${s}`, national: `0${s}` });
}

export const maskPhone = (e164: string): string =>
  e164.length < 8 ? '***' : `${e164.slice(0, 5)}*****${e164.slice(-2)}`;
