# ADR-0005 Tenant isolation via RLS + membership-verified context

Status: Accepted

Defence in depth: application PolicyEngine plus PostgreSQL RLS (ENABLE+FORCE) driven by transaction-local settings; org id re-verified against active membership at the persistence choke point.
