import { NextResponse } from 'next/server';
import { api, clientIp, deviceId, isSameOrigin, setSession } from '@/lib/bff';

type Tokens = { accessToken: string; accessExpiresAt: string; refreshToken: string; refreshExpiresAt: string; organizationId: string | null; isNewUser: boolean };

export async function POST(req: Request) {
  if (!isSameOrigin(req)) return NextResponse.json({ error: { code: 'CSRF', message: 'Forbidden.' } }, { status: 403 });
  const body = (await req.json().catch(() => null)) as { challengeId?: unknown; code?: unknown } | null;
  if (typeof body?.challengeId !== 'string' || typeof body.code !== 'string') {
    return NextResponse.json({ error: { code: 'VALIDATION_FAILED', message: 'Invalid request.' } }, { status: 400 });
  }
  const r = await api<Tokens>('/auth/otp/verify', {
    method: 'POST',
    ip: clientIp(req),
    body: { challengeId: body.challengeId, code: body.code, device: { deviceId: await deviceId(), platform: 'web', label: 'Web' } },
  });
  if (!r.ok) return NextResponse.json({ error: r.error }, { status: r.status });
  await setSession(r.data);
  // Tokens are NOT returned to the browser.
  return NextResponse.json({ ok: true, isNewUser: r.data.isNewUser, hasOrganization: r.data.organizationId !== null });
}
