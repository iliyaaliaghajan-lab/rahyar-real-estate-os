'use client';

import { useRef, useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { normalizeIranMobile } from '@rahyar/domain-kernel/phone'; // browser-safe subpath (the root index imports node:crypto)

type Step = 'phone' | 'code';
const MESSAGES: Record<string, string> = {
  PHONE_INVALID: 'شماره موبایل معتبر نیست. مثال: ۰۹۱۲۱۲۳۴۵۶۷',
  PHONE_UNSUPPORTED_REGION: 'در حال حاضر فقط شماره‌های موبایل ایران پشتیبانی می‌شود.',
  OTP_RATE_LIMITED: 'درخواست‌های بیش از حد. لطفاً کمی بعد دوباره تلاش کنید.',
  OTP_INVALID: 'کد واردشده درست نیست.',
  OTP_EXPIRED: 'کد منقضی شده است. کد جدید دریافت کنید.',
  OTP_LOCKED: 'تعداد تلاش‌ها بیش از حد مجاز بود. کد جدید دریافت کنید.',
  OTP_ALREADY_USED: 'این کد قبلاً استفاده شده است.',
  ACCOUNT_DISABLED: 'دسترسی این حساب مسدود است.',
  DEVICE_REVOKED: 'این دستگاه مسدود شده است.',
  OTP_DELIVERY_FAILED: 'ارسال پیامک ممکن نشد. دوباره تلاش کنید.',
};

export default function LoginPage() {
  const router = useRouter();
  const [step, setStep] = useState<Step>('phone');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [challengeId, setChallengeId] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const codeRef = useRef<HTMLInputElement>(null);

  async function post(url: string, body: unknown) {
    const res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
    const json = (await res.json().catch(() => ({}))) as { error?: { code: string }; challengeId?: string };
    return { ok: res.ok, json };
  }
  const fail = (code?: string) => setError(MESSAGES[code ?? ''] ?? 'خطایی رخ داد. دوباره تلاش کنید.');

  async function onPhone(e: FormEvent) {
    e.preventDefault();
    setError('');
    const local = normalizeIranMobile(phone); // fast client-side hint only; the server re-validates
    if (!local.ok) return fail(local.error);
    setBusy(true);
    const r = await post('/api/auth/request', { phone });
    setBusy(false);
    if (!r.ok || !r.json.challengeId) return fail(r.json.error?.code);
    setChallengeId(r.json.challengeId);
    setStep('code');
    setTimeout(() => codeRef.current?.focus(), 0);
  }

  async function onCode(e: FormEvent) {
    e.preventDefault();
    setError('');
    setBusy(true);
    const r = await post('/api/auth/verify', { challengeId, code });
    setBusy(false);
    if (!r.ok) return fail(r.json.error?.code);
    router.replace('/app');
  }

  return (
    <main>
      <section className="card" aria-labelledby="title">
        <h1 id="title">ورود به راهیار</h1>
        <p className="muted">{step === 'phone' ? 'شماره موبایل خود را وارد کنید تا کد تأیید برایتان ارسال شود.' : 'کد تأیید ارسال‌شده به موبایل را وارد کنید.'}</p>
        {step === 'phone' ? (
          <form onSubmit={onPhone} noValidate>
            <label htmlFor="phone">شماره موبایل</label>
            <input id="phone" name="phone" type="tel" inputMode="tel" autoComplete="tel" dir="ltr" placeholder="09123456789" value={phone} onChange={(e) => setPhone(e.target.value)} aria-describedby="err" aria-invalid={error ? true : undefined} required />
            <p id="err" className="error" role="alert" aria-live="polite">{error}</p>
            <button type="submit" disabled={busy}>{busy ? 'در حال ارسال…' : 'دریافت کد تأیید'}</button>
          </form>
        ) : (
          <form onSubmit={onCode} noValidate>
            <label htmlFor="code">کد تأیید</label>
            <input id="code" ref={codeRef} name="code" type="text" inputMode="numeric" autoComplete="one-time-code" dir="ltr" maxLength={8} value={code} onChange={(e) => setCode(e.target.value)} aria-describedby="err" aria-invalid={error ? true : undefined} required />
            <p id="err" className="error" role="alert" aria-live="polite">{error}</p>
            <button type="submit" disabled={busy}>{busy ? 'در حال بررسی…' : 'ورود'}</button>
            <button type="button" className="secondary" onClick={() => { setStep('phone'); setCode(''); setError(''); }}>ویرایش شماره</button>
          </form>
        )}
      </section>
    </main>
  );
}
