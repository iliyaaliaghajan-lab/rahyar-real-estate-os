// Static checks over the SQL text. These run WITHOUT a database and guard the security invariants.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadMigrations } from '../migration-files.ts';

const dir = join(dirname(fileURLToPath(import.meta.url)), '..', 'migrations');
const migrations = loadMigrations(dir);
const all = migrations.map((m) => m.sql).join('\n');
const strip = (s: string): string => s.replace(/--.*$/gm, '');
const sql = strip(all);

const tables = [...sql.matchAll(/CREATE TABLE\s+(\w+)\s*\(([\s\S]*?)\n\);/g)].map((m) => ({
  name: m[1] ?? '',
  body: m[2] ?? '',
}));
const policies = [...sql.matchAll(/CREATE POLICY\s+(\w+)\s+ON\s+(\w+)\s+FOR\s+(\w+)\s+TO\s+rahyar_app([\s\S]*?);/gi)].map(
  (m) => ({ name: m[1] ?? '', table: m[2] ?? '', cmd: (m[3] ?? '').toUpperCase(), text: m[4] ?? '' }),
);

test('migrations: deterministic, contiguous, immutable naming', () => {
  assert.equal(migrations.length, 10);
  assert.deepEqual(
    migrations.map((m) => m.version),
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
  );
  assert.ok(migrations.every((m) => /^[0-9a-f]{64}$/.test(m.checksum)));
});

test('migrations: forward-only (no DROP TABLE/TRUNCATE/DELETE FROM in migrations)', () => {
  assert.doesNotMatch(sql, /\bDROP\s+TABLE\b/i);
  assert.doesNotMatch(sql, /\bDELETE\s+FROM\b/i);
});

test('rls: every table has ENABLE and FORCE ROW LEVEL SECURITY', () => {
  assert.ok(tables.length >= 10, `parsed ${tables.length} tables`);
  for (const t of tables) {
    assert.match(sql, new RegExp(`ALTER TABLE\\s+${t.name}\\s+ENABLE ROW LEVEL SECURITY`, 'i'), `${t.name} ENABLE`);
    assert.match(sql, new RegExp(`ALTER TABLE\\s+${t.name}\\s+FORCE ROW LEVEL SECURITY`, 'i'), `${t.name} FORCE`);
  }
});

test('rls: tenant-owned tables (organization_id) have a policy bound to current org', () => {
  // `sessions` carries an *active* organization_id but is user-scoped (bound to app.current_user_id()).
  const USER_SCOPED = new Set(['sessions']);
  const tenantTables = tables
    .filter((t) => /\borganization_id\b/.test(t.body) && !USER_SCOPED.has(t.name))
    .map((t) => t.name);
  assert.ok(tenantTables.includes('roles') && tenantTables.includes('audit_logs'));
  for (const name of tenantTables) {
    const ps = policies.filter((p) => p.table === name);
    assert.ok(ps.length > 0, `${name} has policies`);
    assert.ok(
      ps.some((p) => p.text.includes('app.current_org_id()')),
      `${name} policies reference app.current_org_id()`,
    );
  }
  const orgPolicies = policies.filter((p) => p.table === 'organizations');
  assert.ok(orgPolicies.length >= 3);
});

test('rls: every privilege granted to rahyar_app has a matching policy (default deny otherwise)', () => {
  // Table grants only (schema/function grants are not row-level).
  const grants = [
    ...sql.matchAll(/GRANT\s+((?:SELECT|INSERT|UPDATE|DELETE)(?:\s*,\s*(?:SELECT|INSERT|UPDATE|DELETE))*)\s+ON\s+([\w, ]+?)\s+TO\s+rahyar_app/g),
  ];
  assert.ok(grants.length > 0);
  for (const g of grants) {
    const privs = (g[1] ?? '').split(',').map((s) => s.trim());
    const tbls = (g[2] ?? '').split(',').map((s) => s.trim());
    for (const tbl of tbls) {
      for (const priv of privs) {
        const ok = policies.some((p) => p.table === tbl && (p.cmd === 'ALL' || p.cmd === priv));
        assert.ok(ok, `GRANT ${priv} ON ${tbl} has no policy`);
      }
    }
  }
});

test('rls: user-scoped and auth-only tables are not readable cross-user', () => {
  for (const t of ['otp_challenges']) {
    const ps = policies.filter((p) => p.table === t);
    assert.ok(ps.every((p) => p.text.includes('app.is_auth_scope()')), `${t} is auth-scope only`);
  }
  for (const t of ['devices', 'sessions', 'refresh_tokens']) {
    const ps = policies.filter((p) => p.table === t);
    assert.ok(ps.every((p) => p.text.includes('app.current_user_id()')), `${t} is user-bound`);
  }
});

test('audit: append-only (no UPDATE/DELETE/TRUNCATE/ALL grants, triggers present)', () => {
  const auditGrants = [...sql.matchAll(/GRANT\s+([A-Z, ]+?)\s+ON\s+([\w, ]*audit_logs[\w, ]*)\s+TO\s+/g)];
  assert.ok(auditGrants.length >= 1);
  for (const g of auditGrants) {
    assert.doesNotMatch(g[1] ?? '', /UPDATE|DELETE|TRUNCATE|ALL/);
  }
  assert.match(sql, /audit_logs_no_update BEFORE UPDATE OR DELETE ON audit_logs/);
  assert.match(sql, /audit_logs_no_truncate BEFORE TRUNCATE ON audit_logs/);
  assert.ok(!policies.some((p) => p.table === 'audit_logs' && ['UPDATE', 'DELETE', 'ALL'].includes(p.cmd)));
});

test('roles: app role is NOSUPERUSER NOBYPASSRLS, has no password, nothing grants BYPASSRLS', () => {
  assert.match(sql, /CREATE ROLE rahyar_app NOLOGIN NOSUPERUSER NOBYPASSRLS/);
  assert.doesNotMatch(sql, /(?<!NO)BYPASSRLS(?!;)/);
  assert.doesNotMatch(sql, /(?<!NO)SUPERUSER(?! *NOBYPASSRLS)/);
  assert.doesNotMatch(sql, /PASSWORD\s+'/i);
});

test('extensions: postgis, vector enabled via SQL migrations', () => {
  assert.match(sql, /CREATE EXTENSION IF NOT EXISTS postgis/);
  assert.match(sql, /CREATE EXTENSION IF NOT EXISTS vector/);
});

test('integrity: memberships reference roles of the same organization (composite FK)', () => {
  assert.match(sql, /FOREIGN KEY \(organization_id, role_id\) REFERENCES roles \(organization_id, id\)/);
});

test('otp: no plaintext code column', () => {
  const otp = tables.find((t) => t.name === 'otp_challenges');
  assert.ok(otp);
  assert.match(otp.body, /\bcode_hash\b/);
  assert.doesNotMatch(otp.body, /\b(code|otp|plain\w*)\s+text/i);
});

test('role lifecycle: migrations never alter the app role, never set a password, and assert safety', () => {
  assert.doesNotMatch(sql, /ALTER ROLE/i);
  assert.doesNotMatch(sql, /CREATE ROLE(?! rahyar_app NOLOGIN)/);
  assert.match(sql, /role rahyar_app has privileged attributes/);
  assert.match(sql, /CREATE FUNCTION app\.assert_role_safe\(role_name name\)/);
  assert.match(sql, /REVOKE CREATE ON SCHEMA public FROM rahyar_app/);
  assert.doesNotMatch(sql, /SECURITY DEFINER/i, 'no privilege-escalating functions');
  const runner = readFileSync(join(dir, '..', 'migrate.ts'), 'utf8');
  assert.match(runner, /assert_role_safe\('rahyar_app'\)/);
  assert.match(runner, /Refusing to migrate as the application role/);
});

test('rls: org-bound context sees only that org (no cross-org widening via user_id)', () => {
  for (const name of ['memberships_select', 'organizations_select']) {
    const p = policies.find((x) => x.name === name);
    assert.ok(p, name);
    assert.match(p.text, /app\.current_org_id\(\) IS NULL/, `${name} must only widen when no org is bound`);
  }
});

test('audit: actor cannot be forged (insert policy pins actor_user_id)', () => {
  const p = policies.find((x) => x.name === 'audit_logs_insert');
  assert.ok(p);
  assert.match(p.text, /actor_user_id = app\.current_user_id\(\)/);
});
