// Reusable tenant-isolation harness. Runs against in-memory ports (unit) AND real PostgreSQL (integration).
import assert from 'node:assert/strict';
import { AppError } from '@rahyar/domain-kernel';
import type { AuthService } from '../../src/modules/identity/application/auth.service.ts';
import type { OrganizationService } from '../../src/modules/organization/application/organization.service.ts';
import type { TenantUnitOfWork } from '../../src/modules/organization/application/ports.ts';
import type { Principal } from '../../src/modules/authorization/domain/policy-engine.ts';

export type HarnessDeps = {
  auth: AuthService;
  orgs: OrganizationService;
  tenantUow: TenantUnitOfWork;
  /** Logs a phone in (request OTP + verify) and returns the access token. */
  login: (phone: string, deviceId: string) => Promise<{ accessToken: string; sessionId: string }>;
};
export type Tenant = { phone: string; accessToken: string; sessionId: string; organizationId: string; principal: Principal };

export async function seedTenant(d: HarnessDeps, phone: string, deviceId: string, orgName: string, key: string): Promise<Tenant> {
  const s = await d.login(phone, deviceId);
  const first = await d.auth.authenticate(s.accessToken);
  const org = await d.orgs.createOrganization(first, { name: orgName, idempotencyKey: key });
  const principal = await d.auth.authenticate(s.accessToken);
  return { phone, accessToken: s.accessToken, sessionId: s.sessionId, organizationId: org.organizationId, principal };
}

const code = (e: unknown): string | undefined => (e instanceof AppError ? e.code : undefined);

export async function assertTenantIsolation(d: HarnessDeps, a: Tenant, b: Tenant): Promise<void> {
  assert.notEqual(a.organizationId, b.organizationId);
  // 1. Each principal reads only its own organization.
  assert.equal((await d.orgs.getCurrentOrganization(a.principal)).id, a.organizationId);
  assert.equal((await d.orgs.getCurrentOrganization(b.principal)).id, b.organizationId);
  // 2. Audit trails never mix tenants (and are non-empty, so the check is meaningful).
  const logsA = await d.orgs.listAuditLogs(a.principal);
  const logsB = await d.orgs.listAuditLogs(b.principal);
  assert.ok(logsA.length > 0 && logsB.length > 0);
  const idsB = new Set(logsB.map((l) => l.id));
  assert.ok(logsA.every((l) => !idsB.has(l.id)));
  // 3. FORGED PRINCIPAL: B's identity claiming A's organization is rejected at the persistence boundary.
  const forged: Principal = { ...b.principal, organizationId: a.organizationId };
  await assert.rejects(d.orgs.getCurrentOrganization(forged), (e: unknown) => code(e) === 'TENANT_ACCESS_DENIED');
  await assert.rejects(d.orgs.listAuditLogs({ ...forged, permissions: new Set(['audit:read']) }), (e: unknown) => code(e) === 'TENANT_ACCESS_DENIED');
  // 4. Raw unit-of-work with a forged context is rejected too (no service involved).
  await assert.rejects(
    d.tenantUow.run({ userId: b.principal.userId, organizationId: a.organizationId, sessionId: b.sessionId }, (tx) => tx.getOrganization(a.organizationId)),
    (e: unknown) => code(e) === 'TENANT_ACCESS_DENIED',
  );
  // 5. Session cannot be switched into a foreign (or non-existent) tenant; same answer for both (no enumeration).
  await assert.rejects(d.auth.switchOrganization(b.principal, a.organizationId), (e: unknown) => code(e) === 'ORGANIZATION_NOT_FOUND');
  // 6. Legitimate access is unaffected.
  assert.equal((await d.orgs.getCurrentOrganization(await d.auth.authenticate(a.accessToken))).id, a.organizationId);
}
