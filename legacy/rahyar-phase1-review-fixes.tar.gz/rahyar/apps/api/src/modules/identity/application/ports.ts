import type { AuditEntry } from '../../audit/audit.types.ts';
import type { ChallengeState } from '../domain/otp.ts';
import type { RefreshRecord } from '../domain/refresh.ts';

export type UserRecord = {
  readonly id: string;
  readonly phoneE164: string;
  readonly status: 'active' | 'disabled';
  readonly displayName: string | null;
};
export type ChallengeRecord = ChallengeState & { readonly purpose: 'login' | 'step_up' };
export type DeviceRecord = { readonly id: string; readonly userId: string; readonly revokedAt: Date | null };
export type SessionRecord = {
  readonly id: string;
  readonly userId: string;
  readonly deviceId: string;
  readonly organizationId: string | null;
  readonly accessExpiresAt: Date;
  readonly absoluteExpiresAt: Date;
  readonly stepUpAt: Date | null;
  readonly lastSeenAt: Date;
  readonly revokedAt: Date | null;
};
export type SessionWithContext = SessionRecord & {
  readonly userStatus: 'active' | 'disabled';
  readonly deviceRevokedAt: Date | null;
};
export type DevicePlatform = 'web' | 'ios' | 'android' | 'desktop' | 'unknown';
export type SessionListItem = {
  readonly id: string;
  readonly deviceId: string;
  readonly deviceLabel: string | null;
  readonly platform: DevicePlatform;
  readonly organizationId: string | null;
  readonly createdAt: Date;
  readonly lastSeenAt: Date;
};
export type DeviceListItem = {
  readonly id: string;
  readonly label: string | null;
  readonly platform: DevicePlatform;
  readonly trustedAt: Date | null;
  readonly revokedAt: Date | null;
  readonly lastSeenAt: Date;
};

/**
 * One database transaction in the pre-tenant "auth scope". Implementations are infrastructure
 * (Kysely) or in-memory fakes; no ORM types cross this boundary.
 */
export interface AuthTx {
  recentChallengeTimes(by: { phoneE164: string } | { ipHash: string }, since: Date): Promise<Date[]>;
  insertChallenge(c: {
    id: string;
    phoneE164: string;
    purpose: 'login' | 'step_up';
    codeHash: string;
    maxAttempts: number;
    ipHash: string | null;
    createdAt: Date;
    expiresAt: Date;
  }): Promise<void>;
  /** Supersede any still-open challenge for this phone/purpose (only the newest code is ever valid). */
  invalidateOpenChallenges(phoneE164: string, purpose: 'login' | 'step_up', now: Date): Promise<void>;
  getChallengeForUpdate(id: string): Promise<ChallengeRecord | null>;
  updateChallengeAttempts(id: string, attempts: number, lockedAt: Date | null): Promise<void>;
  /** Atomic single-use: UPDATE ... WHERE consumed_at IS NULL. Returns false if already consumed (replay). */
  consumeChallenge(id: string, now: Date): Promise<boolean>;
  expireChallenge(id: string, now: Date): Promise<void>;

  findUserByPhone(phoneE164: string): Promise<UserRecord | null>;
  createUser(u: { id: string; phoneE164: string; now: Date }): Promise<UserRecord>;
  markLogin(userId: string, now: Date): Promise<void>;
  upsertDevice(d: {
    id: string;
    userId: string;
    fingerprintHash: string;
    label: string | null;
    platform: DevicePlatform;
    now: Date;
  }): Promise<DeviceRecord>;
  listActiveOrganizationIds(userId: string): Promise<string[]>;

  createSession(s: {
    id: string;
    userId: string;
    deviceId: string;
    organizationId: string | null;
    accessTokenHash: string;
    accessExpiresAt: Date;
    absoluteExpiresAt: Date;
    now: Date;
  }): Promise<void>;
  insertRefreshToken(r: {
    id: string;
    sessionId: string;
    userId: string;
    tokenHash: string;
    generation: number;
    expiresAt: Date;
  }): Promise<void>;
  findSessionByAccessHash(hash: string): Promise<SessionWithContext | null>;
  touchSession(id: string, now: Date): Promise<void>;
  /** Permissions of the user's ACTIVE membership in the organization, or null if there is none. */
  loadPermissions(userId: string, organizationId: string): Promise<string[] | null>;
  getRefreshForUpdate(tokenHash: string): Promise<{
    record: RefreshRecord & { readonly userId: string };
    session: SessionWithContext;
  } | null>;
  /** Atomic single-use: UPDATE ... WHERE used_at IS NULL. Returns false if another request won the race. */
  markRefreshUsed(id: string, now: Date): Promise<boolean>;
  rotateAccess(sessionId: string, accessTokenHash: string, accessExpiresAt: Date, now: Date): Promise<void>;
  setSessionOrganization(sessionId: string, organizationId: string): Promise<void>;
  /** Revokes the session and all of its refresh tokens. */
  revokeSession(id: string, reason: string, now: Date): Promise<void>;
  /** Revokes the device (if owned by the user) and all of its sessions. */
  revokeDevice(userId: string, deviceId: string, now: Date): Promise<boolean>;
  getSession(id: string): Promise<SessionRecord | null>;
  listSessions(userId: string): Promise<SessionListItem[]>;
  listDevices(userId: string): Promise<DeviceListItem[]>;
  appendAudit(entry: AuditEntry): Promise<void>;
}

export interface AuthUnitOfWork {
  /** Pre-authentication scope (OTP, token lookup, refresh): RLS permits cross-user access. Use sparingly. */
  run<T>(fn: (tx: AuthTx) => Promise<T>): Promise<T>;
  /**
   * User-bound scope for operations an authenticated user performs on THEIR OWN sessions/devices.
   * PostgreSQL RLS (not just application code) then confines every statement to `userId`.
   */
  runAsUser<T>(userId: string, fn: (tx: AuthTx) => Promise<T>): Promise<T>;
}

export interface OtpSender {
  send(args: { phoneE164: string; code: string; purpose: 'login' | 'step_up'; ttlSeconds: number }): Promise<void>;
}
