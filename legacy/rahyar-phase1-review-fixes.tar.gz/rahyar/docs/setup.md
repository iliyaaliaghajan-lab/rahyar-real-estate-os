# Setup, verification and what a restricted sandbox cannot run

## 1. Install tooling
Node ≥ 22.12 (`.nvmrc`) and pnpm 9.15 (pinned in `package.json` → `packageManager`):
```bash
corepack enable
corepack prepare pnpm@9.15.0 --activate      # or: npm i -g pnpm@9.15.0
```

## 2. Generate the lockfile (REQUIRED, one time, needs network)
`pnpm-lock.yaml` is **not in the repository yet**. It cannot be fabricated; it must come from a real resolve:
```bash
pnpm install                  # resolves from the registry, writes pnpm-lock.yaml
git add pnpm-lock.yaml && git commit -m "chore: add pnpm lockfile"
```
CI then uses `pnpm install --frozen-lockfile` (never weakened) and fails fast with a clear message if the file is absent.
Also run `pnpm format` once and commit: the code was written without Prettier available, so `pnpm format:check` will fail until then.
**CI must not be considered ready until the lockfile is committed and the pipeline has actually passed.**

## 3. Start infrastructure (Docker)
```bash
cp .env.example .env     # replace every change-me value (OTP_PEPPER: openssl rand -base64 48)
set -a; . ./.env; set +a
pnpm infra:up            # PostgreSQL 16 + PostGIS + pgvector, Redis, MinIO — localhost only
```
First start provisions both `rahyar` (dev) and `rahyar_test` databases via `infra/db/provision.sh`
(role + extensions; see `docs/database-roles.md`).

## 4. Migrate
```bash
pnpm db:migrate          # uses DATABASE_MIGRATOR_URL (privileged); verifies rahyar_app is still unprivileged afterwards
```

## 5. Run the checks
```bash
pnpm check:repo --require-lockfile && pnpm check:secrets
pnpm format:check && pnpm lint && pnpm typecheck
pnpm test                # unit + static suites (Node only, no database)
pnpm build
pnpm test:integration    # real PostgreSQL; needs TEST_DATABASE_URL (rahyar_app) and TEST_DATABASE_MIGRATOR_URL (admin)
```

## 6. Which checks need what
| Check | Needs |
|---|---|
| `check:repo`, `check:secrets`, unit/static tests, framework-free `tsc` subset | Node only — **runnable in a restricted sandbox** |
| install, lockfile, lint, full typecheck, build, web/BFF runtime | package registry |
| `test:integration` (migrations, RLS, FORCE RLS, role safety, tenancy, auth, refresh concurrency, audit append-only) | PostgreSQL + PostGIS + pgvector (Docker or managed) |
| CI workflow | GitHub Actions run |

Integration tests are never mocked and never silently pass: without `TEST_DATABASE_*` they are reported as skipped
("NOT EXECUTED — REQUIRES EXTERNAL INFRASTRUCTURE") or fail to load; either way they are **not** a pass.
