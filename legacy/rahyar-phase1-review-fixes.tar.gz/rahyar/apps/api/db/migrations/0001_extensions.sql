-- Extensions. In managed environments these may need to be pre-created by a privileged role
-- (see infra/db/init). CREATE EXTENSION IF NOT EXISTS is a no-op when already present.
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS unaccent;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
