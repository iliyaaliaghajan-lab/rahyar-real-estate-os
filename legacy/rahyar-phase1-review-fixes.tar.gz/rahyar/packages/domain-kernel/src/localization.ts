import { toLatinDigits } from './phone.ts';

/** Presentation-boundary localization. Storage is always UTC / canonical digits. */
export type SupportedLocale = 'fa-IR';
export type LocaleConfig = {
  readonly tag: string;
  readonly dir: 'rtl' | 'ltr';
  readonly calendarTag: string;
  readonly defaultTimeZone: string;
  readonly defaultCurrencyDisplay: 'IRT' | 'IRR';
};

export const LOCALES: Readonly<Record<SupportedLocale, LocaleConfig>> = {
  'fa-IR': {
    tag: 'fa-IR',
    dir: 'rtl',
    calendarTag: 'fa-IR-u-ca-persian',
    defaultTimeZone: 'Asia/Tehran',
    defaultCurrencyDisplay: 'IRT',
  },
};

export function formatDate(
  instant: Date,
  locale: SupportedLocale = 'fa-IR',
  opts: { timeZone?: string; withTime?: boolean } = {},
): string {
  const cfg = LOCALES[locale];
  return new Intl.DateTimeFormat(cfg.calendarTag, {
    dateStyle: 'long',
    ...(opts.withTime ? { timeStyle: 'short' as const } : {}),
    timeZone: opts.timeZone ?? cfg.defaultTimeZone,
  }).format(instant);
}

/** Parse user-typed digits (Persian/Arabic/Latin) into a Latin-digit string for validation. */
export const canonicalDigits = (input: string): string => toLatinDigits(input).trim();
