import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import './globals.css';

export const metadata: Metadata = { title: 'راهیار', description: 'سامانه هوشمند مدیریت املاک' };
export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#0b5fff' };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
