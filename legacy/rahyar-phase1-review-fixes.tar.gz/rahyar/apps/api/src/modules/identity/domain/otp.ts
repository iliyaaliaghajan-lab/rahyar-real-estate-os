import { createHmac, randomInt, timingSafeEqual } from 'node:crypto';
import { toLatinDigits } from '@rahyar/domain-kernel';

export type OtpPolicy = {
  readonly length: number;
  readonly ttlSeconds: number;
  readonly maxAttempts: number;
  readonly resendCooldownSeconds: number;
  readonly phoneWindow: { readonly maxRequests: number; readonly windowSeconds: number };
  readonly ipWindow: { readonly maxRequests: number; readonly windowSeconds: number };
};

export const DEFAULT_OTP_POLICY: OtpPolicy = {
  length: 6,
  ttlSeconds: 120,
  maxAttempts: 5,
  resendCooldownSeconds: 60,
  phoneWindow: { maxRequests: 5, windowSeconds: 3600 },
  ipWindow: { maxRequests: 30, windowSeconds: 3600 },
};

/** CSPRNG, uniform digits (randomInt is unbiased). */
export function generateOtpCode(length: number): string {
  let out = '';
  for (let i = 0; i < length; i++) out += String(randomInt(0, 10));
  return out;
}

/**
 * Keyed hash bound to challenge id + phone, so a hash cannot be replayed across challenges/phones.
 * 6-digit codes are brute-forceable offline from a plain hash; the server-side pepper plus attempt limits
 * and a short TTL are what protect them.
 */
export function hashOtp(pepper: string, challengeId: string, phoneE164: string, code: string): string {
  return createHmac('sha256', pepper).update(`otp\u0000${challengeId}\u0000${phoneE164}\u0000${code}`).digest('hex');
}

export function safeEqualHex(a: string, b: string): boolean {
  const ab = Buffer.from(a, 'hex');
  const bb = Buffer.from(b, 'hex');
  return ab.length === bb.length && ab.length > 0 && timingSafeEqual(ab, bb);
}

export type ChallengeState = {
  readonly id: string;
  readonly phoneE164: string;
  readonly codeHash: string;
  readonly attempts: number;
  readonly maxAttempts: number;
  readonly expiresAt: Date;
  readonly consumedAt: Date | null;
  readonly lockedAt: Date | null;
};

export type OtpEvaluation =
  | { readonly outcome: 'verified' }
  | { readonly outcome: 'invalid'; readonly attempts: number; readonly remaining: number; readonly lockedAt: Date | null }
  | { readonly outcome: 'locked' | 'expired' | 'consumed' };

/** Pure state machine. The caller persists `attempts`/`lockedAt` and consumes atomically in the DB. */
export function evaluateOtpAttempt(
  state: ChallengeState,
  rawCode: string,
  now: Date,
  pepper: string,
  length = DEFAULT_OTP_POLICY.length,
): OtpEvaluation {
  if (state.consumedAt) return { outcome: 'consumed' };
  if (state.lockedAt || state.attempts >= state.maxAttempts) return { outcome: 'locked' };
  if (now.getTime() >= state.expiresAt.getTime()) return { outcome: 'expired' };

  const code = toLatinDigits(rawCode).trim();
  const wellFormed = new RegExp(`^\\d{${length}}$`).test(code);
  const matches = wellFormed && safeEqualHex(hashOtp(pepper, state.id, state.phoneE164, code), state.codeHash);
  if (matches) return { outcome: 'verified' };

  const attempts = state.attempts + 1;
  const lockedAt = attempts >= state.maxAttempts ? now : null;
  return { outcome: 'invalid', attempts, remaining: Math.max(0, state.maxAttempts - attempts), lockedAt };
}

export type RateDecision =
  | { readonly allowed: true }
  | { readonly allowed: false; readonly reason: 'cooldown' | 'phone_limit' | 'ip_limit'; readonly retryAfterSeconds: number };

export function evaluateOtpRequestRate(args: {
  readonly phoneRequests: readonly Date[];
  readonly ipRequests: readonly Date[];
  readonly now: Date;
  readonly policy: OtpPolicy;
}): RateDecision {
  const { phoneRequests, ipRequests, now, policy } = args;
  const nowMs = now.getTime();
  const secsUntil = (ms: number): number => Math.max(1, Math.ceil((ms - nowMs) / 1000));

  const latest = phoneRequests.reduce<number>((m, d) => Math.max(m, d.getTime()), 0);
  if (latest > 0 && nowMs - latest < policy.resendCooldownSeconds * 1000) {
    return { allowed: false, reason: 'cooldown', retryAfterSeconds: secsUntil(latest + policy.resendCooldownSeconds * 1000) };
  }
  const within = (list: readonly Date[], windowSeconds: number): number[] =>
    list.map((d) => d.getTime()).filter((t) => nowMs - t < windowSeconds * 1000).sort((a, b) => a - b);

  const p = within(phoneRequests, policy.phoneWindow.windowSeconds);
  if (p.length >= policy.phoneWindow.maxRequests) {
    return { allowed: false, reason: 'phone_limit', retryAfterSeconds: secsUntil((p[0] ?? nowMs) + policy.phoneWindow.windowSeconds * 1000) };
  }
  const i = within(ipRequests, policy.ipWindow.windowSeconds);
  if (i.length >= policy.ipWindow.maxRequests) {
    return { allowed: false, reason: 'ip_limit', retryAfterSeconds: secsUntil((i[0] ?? nowMs) + policy.ipWindow.windowSeconds * 1000) };
  }
  return { allowed: true };
}
