#!/usr/bin/env node
// Static repository / dependency-graph checks that need NO network and NO installed packages.
// They cannot replace `pnpm install --frozen-lockfile` + a real CI run, but they catch manifest drift early.
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { builtinModules } from 'node:module';
import { join, relative } from 'node:path';

const root = new URL('..', import.meta.url).pathname;
const requireLockfile = process.argv.includes('--require-lockfile');
const errors = [];
const warnings = [];
const read = (p) => readFileSync(join(root, p), 'utf8');
const json = (p) => JSON.parse(read(p));

// ── root manifest
const rootPkg = json('package.json');
if (!/^pnpm@\d+\.\d+\.\d+$/.test(rootPkg.packageManager ?? '')) errors.push('root packageManager must pin an exact pnpm version');
if (!rootPkg.engines?.node || !rootPkg.engines?.pnpm) errors.push('root engines.node and engines.pnpm are required');
if (!existsSync(join(root, '.nvmrc'))) errors.push('.nvmrc missing');
if (!/engine-strict=true/.test(read('.npmrc'))) errors.push('.npmrc must set engine-strict=true');

// ── workspaces
const globs = read('pnpm-workspace.yaml').match(/-\s*"([^"]+)"/g)?.map((g) => g.replace(/-\s*"|"/g, '')) ?? [];
const pkgDirs = [];
for (const g of globs) {
  const base = g.replace('/*', '');
  for (const d of readdirSync(join(root, base))) if (existsSync(join(root, base, d, 'package.json'))) pkgDirs.push(`${base}/${d}`);
}
const pkgs = new Map(pkgDirs.map((d) => [json(`${d}/package.json`).name, { dir: d, pkg: json(`${d}/package.json`) }]));
for (const d of ['apps', 'packages']) for (const n of readdirSync(join(root, d))) {
  if (existsSync(join(root, d, n, 'package.json')) && !pkgDirs.includes(`${d}/${n}`)) errors.push(`${d}/${n} is not covered by pnpm-workspace.yaml`);
}

const tsMin = (range) => { const m = /(\d+)\.(\d+)/.exec(range ?? ''); return m ? [Number(m[1]), Number(m[2])] : [0, 0]; };
for (const [name, { dir, pkg }] of pkgs) {
  if (pkg.private !== true || pkg.license !== 'UNLICENSED') errors.push(`${name}: must be private and UNLICENSED`);
  const all = { ...pkg.dependencies, ...pkg.devDependencies };
  for (const [dep, range] of Object.entries(all)) {
    if (range.startsWith('workspace:')) { if (!pkgs.has(dep)) errors.push(`${name}: workspace dependency ${dep} does not exist`); }
    else if (['*', 'latest', ''].includes(range)) errors.push(`${name}: unpinned range for ${dep}`);
  }
  const ts = all.typescript; if (ts) { const [a, b] = tsMin(ts); if (a < 5 || (a === 5 && b < 8)) errors.push(`${name}: typescript must be >=5.8 (erasableSyntaxOnly)`); }
}
const rootTs = tsMin(rootPkg.devDependencies?.typescript); if (rootTs[0] < 5 || (rootTs[0] === 5 && rootTs[1] < 8)) errors.push('root: typescript must be >=5.8');

// ── every bare import must be declared by the package that uses it
const NODE = new Set([...builtinModules, ...builtinModules.map((m) => `node:${m}`)]);
const walk = (dir) => readdirSync(dir).flatMap((n) => {
  if (['node_modules', 'dist', '.next', '.turbo'].includes(n)) return [];
  const f = join(dir, n); return statSync(f).isDirectory() ? walk(f) : /\.(ts|tsx|mjs)$/.test(n) ? [f] : [];
});
const pkgOf = (spec) => (spec.startsWith('@') ? spec.split('/').slice(0, 2).join('/') : spec.split('/')[0]);
for (const [name, { dir, pkg }] of pkgs) {
  const declared = new Set(Object.keys({ ...pkg.dependencies, ...pkg.devDependencies }));
  for (const f of walk(join(root, dir))) {
    const src = readFileSync(f, 'utf8');
    for (const m of src.matchAll(/(?:^|\n)\s*(?:import|export)\s[^'"\n]*?from\s+['"]([^'"]+)['"]|(?:^|\n)\s*import\s+['"]([^'"]+)['"]/g)) {
      const spec = m[1] ?? m[2];
      if (spec.startsWith('.') || spec.startsWith('@/') || spec.startsWith('node:') || NODE.has(spec)) continue;
      if (!declared.has(pkgOf(spec))) errors.push(`${relative(root, f)}: imports "${spec}" but ${name} does not declare ${pkgOf(spec)}`);
    }
  }
}

// ── CI determinism
const ci = read('.github/workflows/ci.yml');
const installs = ci.split('\n').filter((l) => /pnpm install/.test(l));
if (!installs.length || installs.some((l) => !l.includes('--frozen-lockfile'))) errors.push('every `pnpm install` in CI must use --frozen-lockfile');
if (/no-frozen-lockfile|--force|--fix-lockfile/.test(ci)) errors.push('CI must not weaken or regenerate the lockfile');
if (!/test -f pnpm-lock\.yaml/.test(ci)) errors.push('CI must fail fast with a clear message when pnpm-lock.yaml is missing');
if (!/pnpm\/action-setup@/.test(ci)) errors.push('CI must install pnpm via pnpm/action-setup (version from packageManager)');

// ── infra hygiene
const compose = read('docker-compose.yml');
if (/^\s*\w*PASSWORD:\s*(?!\$\{)\S/m.test(compose)) errors.push('docker-compose.yml: passwords must come from the environment');
if (/ports:\s*\["(?!127\.0\.0\.1)/.test(compose)) errors.push('docker-compose.yml: ports must bind to 127.0.0.1');
if (!/^APP_ENV=/m.test(read('.env.example'))) errors.push('.env.example must define APP_ENV');

// ── lockfile (cannot be fabricated)
if (existsSync(join(root, 'pnpm-lock.yaml'))) console.log('pnpm-lock.yaml: present');
else if (requireLockfile) errors.push('pnpm-lock.yaml is missing');
else warnings.push('pnpm-lock.yaml is MISSING — it must be generated in a network-enabled environment (docs/setup.md); CI will fail until it is committed');

for (const w of warnings) console.warn(`WARNING: ${w}`);
if (errors.length) { console.error(`Repo check FAILED:\n${errors.map((e) => `  - ${e}`).join('\n')}`); process.exit(1); }
console.log(`Repo check passed (${pkgs.size} workspace packages, ${warnings.length} warning(s)).`);
