// Requires PostgreSQL (PostGIS + pgvector). Skipped — NOT executed — when TEST_DATABASE_* are unset.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import pg from 'pg';
import { migrate } from '../../db/migrate.ts';
import { APP_URL, MIGRATOR_URL, SKIP, asApp } from '../support/pg.ts';

describe('database foundation (PostgreSQL)', { skip: SKIP }, () => {
  let app: pg.Pool;
  let owner: pg.Pool;
  before(async () => {
    await migrate(MIGRATOR_URL as string);
    app = new pg.Pool({ connectionString: APP_URL as string, max: 4 });
    owner = new pg.Pool({ connectionString: MIGRATOR_URL as string, max: 2 });
  });
  after(async () => {
    await app.end();
    await owner.end();
  });

  it('migrations are idempotent and checksum-verified (second run applies nothing)', async () => {
    assert.deepEqual((await migrate(MIGRATOR_URL as string)).applied, []);
  });

  it('extensions postgis and vector are installed', async () => {
    const r = await owner.query<{ extname: string }>("select extname from pg_extension where extname in ('postgis','vector','pg_trgm','unaccent')");
    assert.equal(r.rowCount, 4);
  });

  it('application role is not superuser, not BYPASSRLS, and owns no tables', async () => {
    const r = await app.query<{ rolsuper: boolean; rolbypassrls: boolean; owns: boolean }>(
      "select rolsuper, rolbypassrls, exists(select 1 from pg_tables where schemaname='public' and tableowner=current_user) as owns from pg_roles where rolname=current_user",
    );
    assert.deepEqual(r.rows[0], { rolsuper: false, rolbypassrls: false, owns: false });
  });

  it('every public table has RLS enabled and forced (catalog check)', async () => {
    const r = await owner.query<{ relname: string }>(
      "select c.relname from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relkind='r' and c.relname <> 'schema_migrations' and not (c.relrowsecurity and c.relforcerowsecurity)",
    );
    assert.deepEqual(r.rows, []);
  });

  it('without any request context the app role sees zero rows in every table', async () => {
    for (const t of ['users', 'organizations', 'roles', 'organization_memberships', 'devices', 'sessions', 'refresh_tokens', 'otp_challenges', 'audit_logs', 'idempotency_keys', 'outbox_events']) {
      const r = await app.query<{ n: string }>(`select count(*)::text as n from ${t}`);
      assert.equal(r.rows[0]?.n, '0', t);
    }
  });

  it('malformed tenant context fails closed (error, not data)', async () => {
    await assert.rejects(asApp(app, { orgId: 'not-a-uuid' }, (c) => c.query('select * from roles')));
  });

  it('audit_logs is append-only for the app role (UPDATE/DELETE/TRUNCATE denied) and for the owner (trigger)', async () => {
    const orgId = '0192f0a0-0000-7000-8000-0000000000aa';
    await asApp(app, { orgId }, (c) =>
      c.query("insert into audit_logs (id, organization_id, actor_type, action, outcome) values (gen_random_uuid(), $1, 'system', 'test.append', 'success')", [orgId]),
    );
    await assert.rejects(asApp(app, { orgId }, (c) => c.query("update audit_logs set action='tampered'")), /permission denied/);
    await assert.rejects(asApp(app, { orgId }, (c) => c.query('delete from audit_logs')), /permission denied/);
    await assert.rejects(app.query('truncate audit_logs'), /permission denied/);
    await assert.rejects(owner.query("update audit_logs set action='tampered'"), /append-only/);
    await assert.rejects(owner.query('delete from audit_logs'), /append-only/);
    await assert.rejects(owner.query('truncate audit_logs'), /append-only/);
    const seen = await asApp(app, { orgId }, (c) => c.query('select action from audit_logs'));
    assert.equal(seen.rows[0]?.action, 'test.append');
    // Another tenant cannot read it.
    const other = await asApp(app, { orgId: '0192f0a0-0000-7000-8000-0000000000bb' }, (c) => c.query('select 1 from audit_logs'));
    assert.equal(other.rowCount, 0);
  });

  it('audit insert for a foreign organization is rejected by RLS', async () => {
    await assert.rejects(
      asApp(app, { orgId: '0192f0a0-0000-7000-8000-0000000000aa' }, (c) =>
        c.query("insert into audit_logs (id, organization_id, actor_type, action, outcome) values (gen_random_uuid(), '0192f0a0-0000-7000-8000-0000000000bb', 'system', 'x.forged', 'success')"),
      ),
      /row-level security/,
    );
  });

  it('role safety function: passes for the app role, rejects a privileged role', async () => {
    await app.query('select app.assert_role_safe(current_user)');
    const admin = await owner.query<{ u: string }>('select current_user as u');
    await assert.rejects(owner.query('select app.assert_role_safe($1)', [admin.rows[0]?.u]), /privileged attributes|owns database objects/);
    await assert.rejects(app.query("select app.assert_role_safe('no_such_role_xyz')"), /does not exist/);
  });

  it('app role cannot create objects, escalate, or disable RLS', async () => {
    await assert.rejects(app.query('create table public.evil (id int)'), /permission denied/);
    await assert.rejects(app.query('alter table roles disable row level security'), /must be owner|permission denied/);
    await assert.rejects(app.query('create role evil'), /permission denied/);
    await assert.rejects(app.query('set role postgres'), /permission denied|does not exist/);
  });

  it('audit rows cannot be forged in another user\'s name', async () => {
    const orgId = '0192f0a0-0000-7000-8000-0000000000aa';
    const a = '0192f0a0-0000-7000-8000-0000000000c1';
    const b = '0192f0a0-0000-7000-8000-0000000000c2';
    await assert.rejects(
      asApp(app, { userId: a, orgId }, (c) =>
        c.query("insert into audit_logs (id, organization_id, actor_type, actor_user_id, action, outcome) values (gen_random_uuid(), $1, 'user', $2, 'x.forged_actor', 'success')", [orgId, b]),
      ),
      /row-level security/,
    );
  });
});
