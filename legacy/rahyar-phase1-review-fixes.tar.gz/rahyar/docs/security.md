# Security controls (Phase 1)

* **Auth**: phone → OTP (6 digits, CSPRNG, TTL 120 s, 5 attempts, resend cooldown 60 s, 5/h per phone, 30/h per IP hash). OTP stored only as
  HMAC-SHA256(pepper, challengeId‖phone‖code); constant-time compare; single use enforced by `UPDATE … WHERE consumed_at IS NULL`.
  Failed attempts and denials are committed (not rolled back) so limits and audit survive.
* **Tokens**: opaque 256-bit access (15 min) and refresh (30 d, ≤ 90 d absolute) tokens; only SHA-256 digests stored; instant revocation.
  Refresh is single-use; reuse (or a lost race) revokes the whole session. Device/session revoke is immediate.
* **Step-up**: `step_up_at` on sessions + `requiresStepUp` in the action registry + `step_up_required` policy effect exist; the challenge flow itself is a later phase.
* **Authorization**: unknown actions denied; tenant mismatch denied before permissions; rules can only restrict.
* **Audit**: append-only (no grants, row + truncate triggers); metadata sanitised for credentials; IP stored as keyed hash.
* **Web**: tokens only in httpOnly SameSite=Strict cookies via BFF; same-origin check; CSP/HSTS/nosniff headers.
* **Config**: zod-validated at boot; production forbids console OTP, privileged DB roles, placeholder pepper. Logs redact credentials/PII.
* **Refresh concurrency**: the refresh row is locked (`FOR UPDATE`) and consumed with `UPDATE … WHERE used_at IS NULL`; a second
  concurrent use is treated as reuse and revokes the session (strict policy; a legitimate double-submit logs the user out).
* **OTP**: issuing a new code supersedes older open codes for that phone; hashes are domain-separated (`otp\0…`).
* **BFF**: `APP_ORIGIN`-based CSRF check (fails closed in production), Fetch-Metadata check on the cookie-rotating GET, real client IP
  forwarded for per-client limits, non-JSON upstream bodies never surfaced, browser bundle cannot import `node:crypto` (browser-safe
  `@rahyar/domain-kernel/phone` subpath).
* **Known limits**: device ids are client-asserted (device revoke blocks sessions and that id, not the physical device); no per-user cap on
  organization creation beyond the global rate limit; `unsafe-inline` in the web CSP.
* **Not in Phase 1**: SMS provider (D8), CSRF tokens beyond SameSite+Origin, Redis-backed global rate limits, audit hash-chaining, WAF.
