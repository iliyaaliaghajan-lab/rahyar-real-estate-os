# ADR-0007 Append-only audit

Status: Accepted

Audit written in the same transaction as the mutation (or committed independently for denials); UPDATE/DELETE/TRUNCATE blocked by privileges and triggers.
