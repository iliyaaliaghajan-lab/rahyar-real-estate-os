import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { api, clearSession, COOKIE, isSameOrigin } from '@/lib/bff';

export async function POST(req: Request) {
  if (!isSameOrigin(req)) return NextResponse.json({ error: { code: 'CSRF', message: 'Forbidden.' } }, { status: 403 });
  const token = (await cookies()).get(COOKIE.access)?.value;
  if (token) await api('/auth/logout', { method: 'POST', token }); // best effort; cookies are cleared regardless
  await clearSession();
  return new NextResponse(null, { status: 204 });
}
