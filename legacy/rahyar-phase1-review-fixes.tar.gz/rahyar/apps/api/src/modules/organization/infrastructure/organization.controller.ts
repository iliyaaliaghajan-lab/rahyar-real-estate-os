import { Body, Controller, Get, Headers, HttpCode, Inject, Post, Query } from '@nestjs/common';
import { CreateOrganizationBody } from '@rahyar/contracts';
import { CurrentPrincipal, RequestMeta, parseBody } from '../../../platform/http/http.ts';
import type { Principal } from '../../authorization/domain/policy-engine.ts';
import { OrganizationService } from '../application/organization.service.ts';

@Controller()
export class OrganizationController {
  constructor(@Inject(OrganizationService) private readonly orgs: OrganizationService) {}

  @Post('organizations') @HttpCode(201)
  create(@Body() body: unknown, @Headers('idempotency-key') key: string | undefined, @CurrentPrincipal() p: Principal, @RequestMeta() meta: { requestId: string }) {
    return this.orgs.createOrganization(p, { name: parseBody(CreateOrganizationBody, body).name, idempotencyKey: key ?? '' }, meta);
  }

  @Get('organizations/current')
  current(@CurrentPrincipal() p: Principal) {
    return this.orgs.getCurrentOrganization(p);
  }

  @Get('audit-logs')
  async audit(@CurrentPrincipal() p: Principal, @Query('limit') limit?: string, @Query('before') before?: string) {
    const b = before ? new Date(before) : null;
    const items = await this.orgs.listAuditLogs(p, { limit: limit ? Number(limit) : 50, before: b && !Number.isNaN(b.getTime()) ? b : null });
    return { items };
  }
}
