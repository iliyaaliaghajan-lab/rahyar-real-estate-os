import { NextResponse } from 'next/server';
import { api, clientIp, isSameOrigin } from '@/lib/bff';

export async function POST(req: Request) {
  if (!isSameOrigin(req)) return NextResponse.json({ error: { code: 'CSRF', message: 'Forbidden.' } }, { status: 403 });
  const body = (await req.json().catch(() => null)) as { phone?: unknown } | null;
  if (typeof body?.phone !== 'string') return NextResponse.json({ error: { code: 'VALIDATION_FAILED', message: 'Invalid request.' } }, { status: 400 });
  const r = await api<{ challengeId: string; resendAfterSeconds: number }>('/auth/otp/request', { method: 'POST', body: { phone: body.phone }, ip: clientIp(req) });
  return NextResponse.json(r.ok ? r.data : { error: r.error }, { status: r.status });
}
