# ADR-0004 Opaque tokens

Status: Accepted

Opaque hashed tokens with DB lookup per request chosen over JWT for instant revocation and no signing-key handling; a short-TTL cache can be added later.
