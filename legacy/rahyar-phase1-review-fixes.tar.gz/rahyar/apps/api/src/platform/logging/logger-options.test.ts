import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createLoggerOptions, REDACT_PATHS } from './logger-options.ts';

test('logging: credentials and PII are in the redaction list', () => {
  for (const p of ['req.headers.authorization', 'req.headers.cookie', '*.refreshToken', '*.accessToken', '*.code', '*.phone']) {
    assert.ok(REDACT_PATHS.includes(p), p);
  }
  assert.equal(createLoggerOptions('info', true).redact.censor, '[redacted]');
});
