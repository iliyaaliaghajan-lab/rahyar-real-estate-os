export type AuditOutcome = 'success' | 'denied' | 'failure';

export type AuditEntry = {
  readonly organizationId: string | null;
  readonly actorType: 'user' | 'system' | 'ai';
  readonly actorUserId: string | null;
  readonly actorSessionId: string | null;
  readonly action: string;
  readonly resourceType?: string;
  readonly resourceId?: string;
  readonly outcome: AuditOutcome;
  readonly requestId?: string;
  readonly ipHash?: string;
  readonly metadata?: Readonly<Record<string, unknown>>;
};

/** Our own bearer-token shapes must never appear in audit values, whatever key they were stored under. */
const TOKEN_VALUE = /rhy_(?:at|rt)_[A-Za-z0-9_-]{20,}/g;
const SENSITIVE_KEY = /otp|code|token|secret|password|authorization|cookie|pepper|hash/i;

/** Audit metadata must never carry credentials. Keys that look sensitive are redacted, recursively. */
export function sanitizeAuditMetadata(value: unknown, depth = 0): unknown {
  if (depth > 4) return '[truncated]';
  if (Array.isArray(value)) return value.slice(0, 50).map((v) => sanitizeAuditMetadata(v, depth + 1));
  if (value && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      out[k] = SENSITIVE_KEY.test(k) ? '[redacted]' : sanitizeAuditMetadata(v, depth + 1);
    }
    return out;
  }
  if (typeof value === 'string') {
    const redacted = value.replace(TOKEN_VALUE, '[redacted]');
    return redacted.length > 500 ? `${redacted.slice(0, 500)}…` : redacted;
  }
  return value;
}
