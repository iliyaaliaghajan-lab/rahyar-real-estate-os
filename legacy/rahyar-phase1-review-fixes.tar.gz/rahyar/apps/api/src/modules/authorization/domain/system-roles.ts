export const PERMISSIONS = [
  'organization:read',
  'organization:update',
  'membership:read',
  'role:read',
  'audit:read',
] as const;
export type Permission = (typeof PERMISSIONS)[number];

export type SystemRoleKey = 'owner' | 'admin' | 'agent' | 'viewer';
export type SystemRole = { readonly key: SystemRoleKey; readonly name: string; readonly permissions: readonly Permission[] };

/** Seeded per organization at creation. Persian display names; keys are stable identifiers. */
export const SYSTEM_ROLES: readonly SystemRole[] = [
  { key: 'owner', name: 'مالک', permissions: PERMISSIONS },
  { key: 'admin', name: 'مدیر', permissions: ['organization:read', 'organization:update', 'membership:read', 'role:read', 'audit:read'] },
  { key: 'agent', name: 'مشاور', permissions: ['organization:read', 'membership:read', 'role:read'] },
  { key: 'viewer', name: 'مشاهده‌گر', permissions: ['organization:read'] },
];
