import { Module } from '@nestjs/common';
import { APP_FILTER, APP_GUARD } from '@nestjs/core';
import { systemClock, type Clock } from '@rahyar/domain-kernel';
import { DefaultDenyPolicyEngine, type PolicyEngine } from './modules/authorization/domain/policy-engine.ts';
import { AuthService } from './modules/identity/application/auth.service.ts';
import { AuthController } from './modules/identity/infrastructure/auth.controller.ts';
import { AuthGuard } from './modules/identity/infrastructure/auth.guard.ts';
import { KyselyAuthUnitOfWork } from './modules/identity/infrastructure/kysely-auth.uow.ts';
import { ConsoleOtpSender, UnconfiguredOtpSender } from './modules/identity/infrastructure/otp-senders.ts';
import { HealthController } from './modules/health/health.controller.ts';
import { OrganizationService } from './modules/organization/application/organization.service.ts';
import { OrganizationController } from './modules/organization/infrastructure/organization.controller.ts';
import { KyselyTenantUnitOfWork } from './modules/organization/infrastructure/kysely-tenant.uow.ts';
import { loadEnv, type Env } from './platform/config/env.schema.ts';
import { DB, ENV } from './platform/database/database.tokens.ts';
import { assertSafeApplicationRole, createDb, type Db } from './platform/database/tenant-context.ts';
import { AllExceptionsFilter } from './platform/errors/http-exception.filter.ts';

const CLOCK = Symbol('CLOCK');
const POLICY = Symbol('POLICY');

@Module({
  controllers: [HealthController, AuthController, OrganizationController],
  providers: [
    { provide: ENV, useFactory: (): Env => loadEnv() },
    {
      provide: DB,
      inject: [ENV],
      useFactory: async (env: Env): Promise<Db> => {
        const db = createDb(env.DATABASE_URL, env.DATABASE_POOL_MAX);
        await assertSafeApplicationRole(db); // refuse to boot with a role that could bypass RLS
        return db;
      },
    },
    { provide: CLOCK, useValue: systemClock },
    { provide: POLICY, useFactory: (): PolicyEngine => new DefaultDenyPolicyEngine() },
    {
      provide: AuthService,
      inject: [DB, ENV, CLOCK, POLICY],
      useFactory: (db: Db, env: Env, clock: Clock, policy: PolicyEngine) =>
        new AuthService({
          uow: new KyselyAuthUnitOfWork(db),
          sender: env.OTP_DELIVERY === 'console' ? new ConsoleOtpSender((m) => process.stdout.write(`${m}\n`)) : new UnconfiguredOtpSender(),
          clock,
          policy,
          config: { pepper: env.OTP_PEPPER },
        }),
    },
    {
      provide: OrganizationService,
      inject: [DB, CLOCK, POLICY],
      useFactory: (db: Db, clock: Clock, policy: PolicyEngine) => new OrganizationService({ uow: new KyselyTenantUnitOfWork(db), clock, policy }),
    },
    { provide: APP_GUARD, useClass: AuthGuard },
    { provide: APP_FILTER, useClass: AllExceptionsFilter },
  ],
})
export class AppModule {}
