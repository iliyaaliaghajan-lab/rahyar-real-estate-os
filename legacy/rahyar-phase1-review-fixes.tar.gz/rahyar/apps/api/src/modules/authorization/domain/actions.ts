export type RiskLevel = 'low' | 'medium' | 'high' | 'irreversible';

export type ActionDescriptor = {
  readonly action: string;
  /** Permission required; null = any authenticated principal (still default-deny for unknown actions). */
  readonly permission: string | null;
  readonly risk: RiskLevel;
  readonly tenantScoped: boolean;
  /** Resource must be owned by the principal (e.g. "revoke MY session"). */
  readonly ownerOnly: boolean;
  readonly requiresStepUp: boolean;
  readonly requiresConfirmation: boolean;
};

const a = (d: Partial<ActionDescriptor> & Pick<ActionDescriptor, 'action' | 'permission'>): ActionDescriptor => ({
  risk: 'low',
  tenantScoped: true,
  ownerOnly: false,
  requiresStepUp: false,
  requiresConfirmation: false,
  ...d,
});

/** The ONLY actions that exist. Anything not listed here is denied. Later phases append to this registry. */
export const ACTIONS = {
  'organization.create': a({ action: 'organization.create', permission: null, tenantScoped: false, risk: 'medium' }),
  'organization.read': a({ action: 'organization.read', permission: 'organization:read' }),
  'organization.update': a({ action: 'organization.update', permission: 'organization:update', risk: 'medium' }),
  'membership.read': a({ action: 'membership.read', permission: 'membership:read' }),
  'role.read': a({ action: 'role.read', permission: 'role:read' }),
  'audit.read': a({ action: 'audit.read', permission: 'audit:read', risk: 'medium' }),
  'session.read_own': a({ action: 'session.read_own', permission: null, tenantScoped: false, ownerOnly: true }),
  'session.revoke_own': a({ action: 'session.revoke_own', permission: null, tenantScoped: false, ownerOnly: true, risk: 'medium' }),
  'device.revoke_own': a({ action: 'device.revoke_own', permission: null, tenantScoped: false, ownerOnly: true, risk: 'medium' }),
} as const satisfies Record<string, ActionDescriptor>;

export type ActionName = keyof typeof ACTIONS;
export const isKnownAction = (s: string): s is ActionName => Object.hasOwn(ACTIONS, s);
