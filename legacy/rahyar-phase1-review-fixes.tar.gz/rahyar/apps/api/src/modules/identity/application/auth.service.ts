import { AppError, normalizeIranMobile, uuidv7, type Clock } from '@rahyar/domain-kernel';
import { enforce, type PolicyEngine, type Principal } from '../../authorization/domain/policy-engine.ts';
import { DEFAULT_OTP_POLICY, evaluateOtpAttempt, evaluateOtpRequestRate, generateOtpCode, hashOtp, type OtpPolicy } from '../domain/otp.ts';
import {
  DEFAULT_SESSION_POLICY,
  addSeconds,
  evaluateRefresh,
  refreshExpiry,
  type SessionPolicy,
} from '../domain/refresh.ts';
import { generateToken, hasTokenShape, hashToken, keyedHash } from '../domain/tokens.ts';
import type { AuthUnitOfWork, DeviceListItem, DevicePlatform, OtpSender, SessionListItem } from './ports.ts';

export type AuthServiceConfig = {
  readonly pepper: string;
  readonly otp?: OtpPolicy;
  readonly session?: SessionPolicy;
};
export type RequestMeta = { readonly ip?: string | undefined; readonly requestId?: string | undefined };
export type DeviceInfo = { readonly deviceId: string; readonly label?: string | undefined; readonly platform?: DevicePlatform | undefined };

export type OtpRequestResult = { challengeId: string; expiresAt: Date; resendAfterSeconds: number };
export type TokenPair = {
  accessToken: string;
  accessExpiresAt: Date;
  refreshToken: string;
  refreshExpiresAt: Date;
};
export type LoginResult = TokenPair & {
  sessionId: string;
  userId: string;
  organizationId: string | null;
  isNewUser: boolean;
};

export class AuthService {
  private readonly uow: AuthUnitOfWork;
  private readonly sender: OtpSender;
  private readonly clock: Clock;
  private readonly policy: PolicyEngine;
  private readonly pepper: string;
  private readonly otp: OtpPolicy;
  private readonly sess: SessionPolicy;

  constructor(deps: { uow: AuthUnitOfWork; sender: OtpSender; clock: Clock; policy: PolicyEngine; config: AuthServiceConfig }) {
    this.uow = deps.uow;
    this.sender = deps.sender;
    this.clock = deps.clock;
    this.policy = deps.policy;
    this.pepper = deps.config.pepper;
    this.otp = deps.config.otp ?? DEFAULT_OTP_POLICY;
    this.sess = deps.config.session ?? DEFAULT_SESSION_POLICY;
    if (this.pepper.length < 32) throw new Error('OTP/identifier pepper must be at least 32 characters');
  }

  // ───────────────────────── OTP request ─────────────────────────
  async requestOtp(input: { phone: string }, meta: RequestMeta = {}): Promise<OtpRequestResult> {
    const phone = normalizeIranMobile(input.phone);
    if (!phone.ok) throw new AppError('validation', phone.error, 'Phone number is not valid.');
    const phoneE164 = phone.value.e164;
    const now = this.clock.now();
    const ipHash = meta.ip ? keyedHash(this.pepper, 'ip', meta.ip) : null;
    const challengeId = uuidv7(now.getTime());
    const code = generateOtpCode(this.otp.length);
    const expiresAt = addSeconds(now, this.otp.ttlSeconds);

    // Decision + persistence commit together; the error (if any) is thrown AFTER commit so audit survives.
    const outcome = await this.uow.run(async (tx) => {
      const since = addSeconds(now, -Math.max(this.otp.phoneWindow.windowSeconds, this.otp.ipWindow.windowSeconds));
      const phoneRequests = await tx.recentChallengeTimes({ phoneE164 }, since);
      const ipRequests = ipHash ? await tx.recentChallengeTimes({ ipHash }, since) : [];
      const rate = evaluateOtpRequestRate({ phoneRequests, ipRequests, now, policy: this.otp });
      if (!rate.allowed) {
        await tx.appendAudit(this.audit('auth.otp.request', 'denied', meta, ipHash, { reason: rate.reason }));
        return rate;
      }
      await tx.invalidateOpenChallenges(phoneE164, 'login', now);
      await tx.insertChallenge({
        id: challengeId,
        phoneE164,
        purpose: 'login',
        codeHash: hashOtp(this.pepper, challengeId, phoneE164, code),
        maxAttempts: this.otp.maxAttempts,
        ipHash,
        createdAt: now,
        expiresAt,
      });
      await tx.appendAudit(this.audit('auth.otp.request', 'success', meta, ipHash, { challengeId }));
      return { allowed: true as const };
    });

    if (!outcome.allowed) {
      throw new AppError('rate_limited', 'OTP_RATE_LIMITED', 'Too many OTP requests.', { retryAfterSeconds: outcome.retryAfterSeconds });
    }
    try {
      await this.sender.send({ phoneE164, code, purpose: 'login', ttlSeconds: this.otp.ttlSeconds });
    } catch {
      await this.uow.run(async (tx) => {
        await tx.expireChallenge(challengeId, this.clock.now());
        await tx.appendAudit(this.audit('auth.otp.delivery', 'failure', meta, ipHash, { challengeId }));
      });
      throw new AppError('internal', 'OTP_DELIVERY_FAILED', 'Could not deliver the verification code.');
    }
    return { challengeId, expiresAt, resendAfterSeconds: this.otp.resendCooldownSeconds };
  }

  // ───────────────────────── OTP verify → session ─────────────────────────
  async verifyOtp(input: { challengeId: string; code: string; device: DeviceInfo }, meta: RequestMeta = {}): Promise<LoginResult> {
    const dev = input.device;
    if (typeof dev.deviceId !== 'string' || dev.deviceId.length < 16 || dev.deviceId.length > 128) {
      throw new AppError('validation', 'DEVICE_ID_INVALID', 'Device identifier is not valid.');
    }
    const now = this.clock.now();
    const ipHash = meta.ip ? keyedHash(this.pepper, 'ip', meta.ip) : null;
    const fingerprintHash = keyedHash(this.pepper, 'device', dev.deviceId);
    const accessToken = generateToken('access');
    const refreshToken = generateToken('refresh');

    type Out =
      | { kind: 'ok'; result: LoginResult }
      | { kind: 'fail'; code: string; error: 'unauthenticated' | 'rate_limited' | 'forbidden'; remaining?: number };

    const out: Out = await this.uow.run(async (tx): Promise<Out> => {
      const ch = await tx.getChallengeForUpdate(input.challengeId);
      if (!ch) {
        await tx.appendAudit(this.audit('auth.otp.verify', 'denied', meta, ipHash, { reason: 'unknown_challenge' }));
        return { kind: 'fail', code: 'OTP_INVALID', error: 'unauthenticated' };
      }
      const ev = evaluateOtpAttempt(ch, input.code, now, this.pepper, this.otp.length);
      if (ev.outcome !== 'verified') {
        if (ev.outcome === 'invalid') {
          await tx.updateChallengeAttempts(ch.id, ev.attempts, ev.lockedAt);
          await tx.appendAudit(this.audit('auth.otp.verify', 'denied', meta, ipHash, { reason: 'invalid', challengeId: ch.id }));
          return { kind: 'fail', code: 'OTP_INVALID', error: 'unauthenticated', remaining: ev.remaining };
        }
        await tx.appendAudit(this.audit('auth.otp.verify', 'denied', meta, ipHash, { reason: ev.outcome, challengeId: ch.id }));
        if (ev.outcome === 'locked') return { kind: 'fail', code: 'OTP_LOCKED', error: 'rate_limited' };
        if (ev.outcome === 'expired') return { kind: 'fail', code: 'OTP_EXPIRED', error: 'unauthenticated' };
        return { kind: 'fail', code: 'OTP_ALREADY_USED', error: 'unauthenticated' };
      }
      // Single-use enforced by the database, not by this process's memory.
      if (!(await tx.consumeChallenge(ch.id, now))) {
        await tx.appendAudit(this.audit('auth.otp.verify', 'denied', meta, ipHash, { reason: 'replay', challengeId: ch.id }));
        return { kind: 'fail', code: 'OTP_ALREADY_USED', error: 'unauthenticated' };
      }

      let user = await tx.findUserByPhone(ch.phoneE164);
      const isNewUser = user === null;
      user ??= await tx.createUser({ id: uuidv7(now.getTime()), phoneE164: ch.phoneE164, now });
      if (user.status !== 'active') {
        await tx.appendAudit({ ...this.audit('auth.login', 'denied', meta, ipHash, { reason: 'account_disabled' }), actorUserId: user.id });
        return { kind: 'fail', code: 'ACCOUNT_DISABLED', error: 'forbidden' };
      }
      const device = await tx.upsertDevice({
        id: uuidv7(now.getTime()),
        userId: user.id,
        fingerprintHash,
        label: dev.label?.slice(0, 120) ?? null,
        platform: dev.platform ?? 'unknown',
        now,
      });
      if (device.revokedAt) {
        await tx.appendAudit({ ...this.audit('auth.login', 'denied', meta, ipHash, { reason: 'device_revoked' }), actorUserId: user.id });
        return { kind: 'fail', code: 'DEVICE_REVOKED', error: 'forbidden' };
      }
      const orgs = await tx.listActiveOrganizationIds(user.id);
      const organizationId = orgs.length === 1 ? (orgs[0] ?? null) : null;

      const sessionId = uuidv7(now.getTime());
      const absoluteExpiresAt = addSeconds(now, this.sess.absoluteTtlSeconds);
      const accessExpiresAt = addSeconds(now, this.sess.accessTtlSeconds);
      const refreshExpiresAt = refreshExpiry(now, absoluteExpiresAt, this.sess);
      await tx.createSession({
        id: sessionId,
        userId: user.id,
        deviceId: device.id,
        organizationId,
        accessTokenHash: hashToken(accessToken),
        accessExpiresAt,
        absoluteExpiresAt,
        now,
      });
      await tx.insertRefreshToken({
        id: uuidv7(now.getTime()),
        sessionId,
        userId: user.id,
        tokenHash: hashToken(refreshToken),
        generation: 1,
        expiresAt: refreshExpiresAt,
      });
      await tx.markLogin(user.id, now);
      await tx.appendAudit({
        ...this.audit('auth.login', 'success', meta, ipHash, { isNewUser, deviceId: device.id }),
        organizationId,
        actorUserId: user.id,
        actorSessionId: sessionId,
        resourceType: 'session',
        resourceId: sessionId,
      });
      return {
        kind: 'ok',
        result: { accessToken, accessExpiresAt, refreshToken, refreshExpiresAt, sessionId, userId: user.id, organizationId, isNewUser },
      };
    });

    if (out.kind === 'ok') return out.result;
    throw new AppError(out.error, out.code, 'Verification failed.', out.remaining === undefined ? undefined : { remainingAttempts: out.remaining });
  }

  // ───────────────────────── Refresh (rotation + reuse detection) ─────────────────────────
  async refresh(input: { refreshToken: string }, meta: RequestMeta = {}): Promise<TokenPair> {
    if (!hasTokenShape('refresh', input.refreshToken)) throw new AppError('unauthenticated', 'REFRESH_INVALID', 'Invalid refresh token.');
    const now = this.clock.now();
    const ipHash = meta.ip ? keyedHash(this.pepper, 'ip', meta.ip) : null;
    const newAccess = generateToken('access');
    const newRefresh = generateToken('refresh');

    type Out = { kind: 'ok'; pair: TokenPair } | { kind: 'fail'; code: string };
    const out: Out = await this.uow.run(async (tx): Promise<Out> => {
      const found = await tx.getRefreshForUpdate(hashToken(input.refreshToken));
      if (!found) {
        await tx.appendAudit(this.audit('auth.refresh', 'denied', meta, ipHash, { reason: 'unknown_token' }));
        return { kind: 'fail', code: 'REFRESH_INVALID' };
      }
      const { record, session } = found;
      const base = { organizationId: session.organizationId, actorUserId: session.userId, actorSessionId: session.id };
      const decision = evaluateRefresh(record, session, now);

      if (decision.decision === 'reuse_detected') {
        await tx.revokeSession(session.id, 'refresh_reuse_detected', now);
        await tx.appendAudit({ ...this.audit('auth.refresh.reuse_detected', 'denied', meta, ipHash, { generation: record.generation }), ...base });
        return { kind: 'fail', code: 'REFRESH_REUSED' };
      }
      if (decision.decision === 'reject') {
        await tx.appendAudit({ ...this.audit('auth.refresh', 'denied', meta, ipHash, { reason: decision.reason }), ...base });
        return { kind: 'fail', code: 'REFRESH_INVALID' };
      }
      if (session.userStatus !== 'active' || session.deviceRevokedAt) {
        await tx.revokeSession(session.id, 'principal_disabled', now);
        await tx.appendAudit({ ...this.audit('auth.refresh', 'denied', meta, ipHash, { reason: 'principal_disabled' }), ...base });
        return { kind: 'fail', code: 'REFRESH_INVALID' };
      }
      if (!(await tx.markRefreshUsed(record.id, now))) {
        // Lost a race with a concurrent use of the same token: treat as reuse.
        await tx.revokeSession(session.id, 'refresh_reuse_detected', now);
        await tx.appendAudit({ ...this.audit('auth.refresh.reuse_detected', 'denied', meta, ipHash, { race: true }), ...base });
        return { kind: 'fail', code: 'REFRESH_REUSED' };
      }
      const accessExpiresAt = addSeconds(now, this.sess.accessTtlSeconds);
      const refreshExpiresAt = refreshExpiry(now, session.absoluteExpiresAt, this.sess);
      await tx.rotateAccess(session.id, hashToken(newAccess), accessExpiresAt, now);
      await tx.insertRefreshToken({
        id: uuidv7(now.getTime()),
        sessionId: session.id,
        userId: session.userId,
        tokenHash: hashToken(newRefresh),
        generation: record.generation + 1,
        expiresAt: refreshExpiresAt,
      });
      await tx.appendAudit({ ...this.audit('auth.refresh', 'success', meta, ipHash, { generation: record.generation + 1 }), ...base });
      return { kind: 'ok', pair: { accessToken: newAccess, accessExpiresAt, refreshToken: newRefresh, refreshExpiresAt } };
    });

    if (out.kind === 'ok') return out.pair;
    throw new AppError('unauthenticated', out.code, 'Refresh failed.');
  }

  // ───────────────────────── Authentication (every request) ─────────────────────────
  async authenticate(accessToken: unknown): Promise<Principal & { deviceId: string }> {
    if (!hasTokenShape('access', accessToken)) throw new AppError('unauthenticated', 'UNAUTHENTICATED', 'Authentication required.');
    const now = this.clock.now();
    const principal = await this.uow.run(async (tx) => {
      const s = await tx.findSessionByAccessHash(hashToken(accessToken));
      if (
        !s ||
        s.revokedAt ||
        s.userStatus !== 'active' ||
        s.deviceRevokedAt ||
        now.getTime() >= s.accessExpiresAt.getTime() ||
        now.getTime() >= s.absoluteExpiresAt.getTime()
      ) {
        return null;
      }
      if (now.getTime() - s.lastSeenAt.getTime() > 60_000) await tx.touchSession(s.id, now);
      let organizationId = s.organizationId;
      let permissions: string[] = [];
      if (organizationId) {
        const perms = await tx.loadPermissions(s.userId, organizationId);
        if (perms === null) organizationId = null; // membership revoked since session start
        else permissions = perms;
      }
      return { userId: s.userId, sessionId: s.id, deviceId: s.deviceId, organizationId, permissions: new Set(permissions), stepUpAt: s.stepUpAt };
    });
    if (!principal) throw new AppError('unauthenticated', 'UNAUTHENTICATED', 'Authentication required.');
    return principal;
  }

  async logout(principal: Principal, meta: RequestMeta = {}): Promise<void> {
    const now = this.clock.now();
    await this.uow.runAsUser(principal.userId, async (tx) => {
      await tx.revokeSession(principal.sessionId, 'logout', now);
      await tx.appendAudit(this.principalAudit(principal, 'auth.logout', 'success', meta, { sessionId: principal.sessionId }));
    });
  }

  async switchOrganization(principal: Principal, organizationId: string, meta: RequestMeta = {}): Promise<void> {
    const orgs = await this.uow.runAsUser(principal.userId, (tx) => tx.listActiveOrganizationIds(principal.userId));
    // Same answer for "no such org" and "not a member": no tenant enumeration.
    if (!orgs.includes(organizationId)) throw new AppError('not_found', 'ORGANIZATION_NOT_FOUND', 'Organization not found.');
    await this.uow.runAsUser(principal.userId, async (tx) => {
      await tx.setSessionOrganization(principal.sessionId, organizationId);
      await tx.appendAudit({ ...this.principalAudit(principal, 'auth.session.switch_organization', 'success', meta, {}), organizationId });
    });
  }

  // ───────────────────────── Sessions & devices ─────────────────────────
  async listSessions(principal: Principal): Promise<SessionListItem[]> {
    enforce(this.policy.decide({ principal, action: 'session.read_own', resource: { ownerUserId: principal.userId }, now: this.clock.now() }));
    return this.uow.runAsUser(principal.userId, (tx) => tx.listSessions(principal.userId));
  }

  async revokeSession(principal: Principal, sessionId: string, meta: RequestMeta = {}): Promise<void> {
    const now = this.clock.now();
    const target = await this.uow.runAsUser(principal.userId, (tx) => tx.getSession(sessionId));
    // Not-owned and non-existent are indistinguishable to the caller.
    if (!target || target.userId !== principal.userId) throw new AppError('not_found', 'SESSION_NOT_FOUND', 'Session not found.');
    enforce(this.policy.decide({ principal, action: 'session.revoke_own', resource: { type: 'session', id: sessionId, ownerUserId: target.userId }, now }));
    await this.uow.runAsUser(principal.userId, async (tx) => {
      await tx.revokeSession(sessionId, 'user_revoked', now);
      await tx.appendAudit({ ...this.principalAudit(principal, 'auth.session.revoke', 'success', meta, {}), resourceType: 'session', resourceId: sessionId });
    });
  }

  async listDevices(principal: Principal): Promise<DeviceListItem[]> {
    enforce(this.policy.decide({ principal, action: 'session.read_own', resource: { ownerUserId: principal.userId }, now: this.clock.now() }));
    return this.uow.runAsUser(principal.userId, (tx) => tx.listDevices(principal.userId));
  }

  async revokeDevice(principal: Principal, deviceId: string, meta: RequestMeta = {}): Promise<void> {
    const now = this.clock.now();
    enforce(this.policy.decide({ principal, action: 'device.revoke_own', resource: { type: 'device', id: deviceId, ownerUserId: principal.userId }, now }));
    const revoked = await this.uow.runAsUser(principal.userId, async (tx) => {
      const ok = await tx.revokeDevice(principal.userId, deviceId, now); // scoped by user in SQL + RLS
      if (ok) await tx.appendAudit({ ...this.principalAudit(principal, 'auth.device.revoke', 'success', meta, {}), resourceType: 'device', resourceId: deviceId });
      return ok;
    });
    if (!revoked) throw new AppError('not_found', 'DEVICE_NOT_FOUND', 'Device not found.');
  }

  // ───────────────────────── helpers ─────────────────────────
  private audit(action: string, outcome: 'success' | 'denied' | 'failure', meta: RequestMeta, ipHash: string | null, metadata: Record<string, unknown>) {
    return {
      organizationId: null,
      actorType: 'user' as const,
      actorUserId: null,
      actorSessionId: null,
      action,
      outcome,
      ...(meta.requestId ? { requestId: meta.requestId } : {}),
      ...(ipHash ? { ipHash } : {}),
      metadata,
    };
  }
  private principalAudit(p: Principal, action: string, outcome: 'success' | 'denied', meta: RequestMeta, metadata: Record<string, unknown>) {
    return { ...this.audit(action, outcome, meta, null, metadata), organizationId: p.organizationId, actorUserId: p.userId, actorSessionId: p.sessionId };
  }
}
