import { createHash } from 'node:crypto';
import { AppError, uuidv7, type Clock } from '@rahyar/domain-kernel';
import { SYSTEM_ROLES } from '../../authorization/domain/system-roles.ts';
import { enforce, type PolicyEngine, type Principal } from '../../authorization/domain/policy-engine.ts';
import type { AuditLogView, TenantUnitOfWork } from './ports.ts';

export type CreateOrganizationResult = { organizationId: string; name: string; role: 'owner' };

/** Persian-aware normalization: Arabic Yeh/Kaf → Persian, collapse spaces, strip control/bidi chars. */
export function normalizeOrganizationName(raw: string): string {
  return raw
    .normalize('NFKC')
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/[\u0000-\u001f\u007f\u200e\u200f\u202a-\u202e\u2066-\u2069]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

export class OrganizationService {
  private readonly uow: TenantUnitOfWork;
  private readonly clock: Clock;
  private readonly policy: PolicyEngine;

  constructor(deps: { uow: TenantUnitOfWork; clock: Clock; policy: PolicyEngine }) {
    this.uow = deps.uow;
    this.clock = deps.clock;
    this.policy = deps.policy;
  }

  async createOrganization(
    principal: Principal,
    input: { name: string; idempotencyKey: string },
    meta: { requestId?: string | undefined } = {},
  ): Promise<CreateOrganizationResult> {
    const now = this.clock.now();
    enforce(this.policy.decide({ principal, action: 'organization.create', now }));
    const name = normalizeOrganizationName(input.name);
    if (name.length < 2 || name.length > 120) throw new AppError('validation', 'ORGANIZATION_NAME_INVALID', 'Organization name must be 2–120 characters.');
    if (typeof input.idempotencyKey !== 'string' || input.idempotencyKey.length < 8 || input.idempotencyKey.length > 128) {
      throw new AppError('validation', 'IDEMPOTENCY_KEY_REQUIRED', 'A valid Idempotency-Key header is required.');
    }
    const requestHash = createHash('sha256').update(JSON.stringify({ name })).digest('hex');
    const organizationId = uuidv7(now.getTime());

    // The transaction's tenant context is the NEW organization id; RLS then lets us create exactly that tenant.
    return this.uow.bootstrap({ userId: principal.userId, sessionId: principal.sessionId, newOrganizationId: organizationId }, async (tx) => {
      const claim = await tx.claimIdempotency({ key: input.idempotencyKey, method: 'POST', path: '/v1/organizations', requestHash, ttlSeconds: 24 * 3600, now });
      if (claim.state === 'replay') return claim.responseBody as CreateOrganizationResult;
      if (claim.state === 'mismatch') throw new AppError('conflict', 'IDEMPOTENCY_KEY_REUSED', 'This Idempotency-Key was used with a different request.');

      await tx.insertOrganization({ id: organizationId, name });
      let ownerRoleId = '';
      for (const role of SYSTEM_ROLES) {
        const id = uuidv7(now.getTime());
        if (role.key === 'owner') ownerRoleId = id;
        await tx.insertRole({ id, organizationId, key: role.key, name: role.name, permissions: role.permissions, isSystem: true });
      }
      await tx.insertMembership({ id: uuidv7(now.getTime()), organizationId, userId: principal.userId, roleId: ownerRoleId });
      await tx.setSessionOrganization(principal.sessionId, organizationId);
      await tx.appendAudit({
        organizationId,
        actorType: 'user',
        actorUserId: principal.userId,
        actorSessionId: principal.sessionId,
        action: 'organization.create',
        resourceType: 'organization',
        resourceId: organizationId,
        outcome: 'success',
        ...(meta.requestId ? { requestId: meta.requestId } : {}),
        metadata: { name },
      });
      await tx.appendOutbox({ organizationId, aggregateType: 'organization', aggregateId: organizationId, eventType: 'organization.created', payload: { organizationId } });
      const result: CreateOrganizationResult = { organizationId, name, role: 'owner' };
      await tx.completeIdempotency(input.idempotencyKey, 201, result, now);
      return result;
    });
  }

  async getCurrentOrganization(principal: Principal): Promise<{ id: string; name: string; status: string; createdAt: Date }> {
    enforce(this.policy.decide({ principal, action: 'organization.read', resource: { organizationId: principal.organizationId }, now: this.clock.now() }));
    const org = await this.uow.run({ userId: principal.userId, organizationId: principal.organizationId, sessionId: principal.sessionId }, (tx) =>
      tx.getOrganization(principal.organizationId as string),
    );
    if (!org) throw new AppError('not_found', 'ORGANIZATION_NOT_FOUND', 'Organization not found.');
    return org;
  }

  async listAuditLogs(principal: Principal, q: { limit?: number; before?: Date | null } = {}): Promise<AuditLogView[]> {
    enforce(this.policy.decide({ principal, action: 'audit.read', resource: { organizationId: principal.organizationId }, now: this.clock.now() }));
    const limit = Math.min(Math.max(Math.trunc(q.limit ?? 50), 1), 100);
    return this.uow.run({ userId: principal.userId, organizationId: principal.organizationId, sessionId: principal.sessionId }, (tx) =>
      tx.listAuditLogs({ limit, before: q.before ?? null }),
    );
  }
}
