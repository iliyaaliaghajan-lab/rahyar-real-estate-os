-- Transactional outbox: events are written in the same transaction as the state change.
-- A relay (future phase) will publish them; it needs its own role and policy.
CREATE TABLE outbox_events (
  id              uuid PRIMARY KEY,
  organization_id uuid REFERENCES organizations (id),
  aggregate_type  text NOT NULL,
  aggregate_id    text NOT NULL,
  event_type      text NOT NULL,
  payload         jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(payload) = 'object'),
  status          text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'published', 'failed')),
  attempts        integer NOT NULL DEFAULT 0,
  available_at    timestamptz NOT NULL DEFAULT now(),
  published_at    timestamptz,
  last_error      text,
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX outbox_events_pending_idx ON outbox_events (status, available_at) WHERE status = 'pending';

ALTER TABLE outbox_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE outbox_events FORCE ROW LEVEL SECURITY;
CREATE POLICY outbox_events_insert ON outbox_events FOR INSERT TO rahyar_app
  WITH CHECK (
    organization_id = app.current_org_id()
    OR (organization_id IS NULL AND (app.is_auth_scope() OR app.current_user_id() IS NOT NULL))
  );
CREATE POLICY outbox_events_select ON outbox_events FOR SELECT TO rahyar_app
  USING (organization_id = app.current_org_id());

GRANT SELECT, INSERT ON outbox_events TO rahyar_app;
