// Source-level guard for "sensitive routes default to deny": the set of @Public routes is pinned,
// and the global AuthGuard must be registered as APP_GUARD. Runs without Nest installed.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const walk = (d: string): string[] => readdirSync(d).flatMap((f) => (statSync(join(d, f)).isDirectory() ? walk(join(d, f)) : [join(d, f)]));
const controllers = walk(root).filter((f) => f.endsWith('.controller.ts'));

test('http: global AuthGuard is registered (default deny)', () => {
  const mod = readFileSync(join(root, 'app.module.ts'), 'utf8');
  assert.match(mod, /provide:\s*APP_GUARD,\s*useClass:\s*AuthGuard/);
});

test('http: only the pinned allowlist of routes is @Public', () => {
  const found: string[] = [];
  for (const f of controllers) {
    const src = readFileSync(f, 'utf8');
    const prefix = /@Controller\('([^']*)'\)/.exec(src)?.[1] ?? '';
    for (const m of src.matchAll(/@Public\(\)\s*@(Get|Post|Delete)\('([^']*)'\)/g)) found.push(`${(m[1] ?? "").toUpperCase()} /${[prefix, m[2]].filter(Boolean).join('/')}`);
    for (const m of src.matchAll(/@Public\(\)\s*@(Get|Post|Delete)\(\)/g)) found.push(`${(m[1] ?? "").toUpperCase()} /${prefix}`);
    assert.ok(!/@Public\(\)\s*\n?\s*(export\s+)?class/.test(src), `${f}: class-level @Public is not allowed`);
  }
  assert.deepEqual(found.sort(), ['GET /health', 'GET /health/ready', 'POST /auth/otp/request', 'POST /auth/otp/verify', 'POST /auth/refresh'].sort());
});

test('http: tenant never read from headers/query/body in controllers', () => {
  for (const f of controllers) {
    const src = readFileSync(f, 'utf8');
    assert.doesNotMatch(src, /x-(tenant|organization|org)[-\w]*/i, `${f} must not read a tenant header`);
    assert.doesNotMatch(src, /organizationId\s*[:=]\s*(body|query|headers)/i);
  }
});

test('config: env schema forbids console OTP, privileged DB roles and placeholder secrets in production', () => {
  const s = readFileSync(join(root, 'platform/config/env.schema.ts'), 'utf8');
  assert.match(s, /console OTP delivery is forbidden in production/);
  assert.match(s, /must not connect as a privileged role/);
  assert.match(s, /OTP_PEPPER: z\.string\(\)\.min\(32/);
});
