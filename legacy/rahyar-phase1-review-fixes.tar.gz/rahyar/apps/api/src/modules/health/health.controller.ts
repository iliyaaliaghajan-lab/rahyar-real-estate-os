import { Controller, Get, Inject } from '@nestjs/common';
import { sql } from 'kysely';
import { Public } from '../../platform/http/http.ts';
import { DB } from '../../platform/database/database.tokens.ts';
import type { Db } from '../../platform/database/tenant-context.ts';

@Controller('health')
export class HealthController {
  constructor(@Inject(DB) private readonly db: Db) {}

  @Public() @Get()
  live() {
    return { status: 'ok' };
  }

  @Public() @Get('ready')
  async ready() {
    await sql`select 1`.execute(this.db);
    return { status: 'ready' };
  }
}
