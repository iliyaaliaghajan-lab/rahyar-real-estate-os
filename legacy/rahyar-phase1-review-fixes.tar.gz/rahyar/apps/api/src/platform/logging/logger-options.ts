/** Pure pino options (no framework imports) so redaction policy is unit-testable. */
export const REDACT_PATHS: readonly string[] = [
  'req.headers.authorization',
  'req.headers.cookie',
  'res.headers["set-cookie"]',
  '*.accessToken',
  '*.refreshToken',
  '*.code',
  '*.otp',
  '*.password',
  '*.pepper',
  '*.phone',
];

export function createLoggerOptions(level: string, _production: boolean) {
  return {
    level,
    redact: { paths: [...REDACT_PATHS], censor: '[redacted]' },
  };
}
