import { test } from 'node:test';
import assert from 'node:assert/strict';
import { AppError } from '@rahyar/domain-kernel';
import { ACTIONS, isKnownAction } from './actions.ts';
import { DefaultDenyPolicyEngine, enforce, type Principal } from './policy-engine.ts';
import { PERMISSIONS, SYSTEM_ROLES } from './system-roles.ts';

const NOW = new Date('2026-10-02T10:00:00Z');
const ORG_A = '0192f0a0-0000-7000-8000-00000000000a';
const ORG_B = '0192f0a0-0000-7000-8000-00000000000b';
const USER = '0192f0a0-0000-7000-8000-0000000000u1'.replace('u', 'a');

const principal = (over: Partial<Principal> = {}, perms: readonly string[] = ['organization:read']): Principal => ({
  userId: USER,
  sessionId: 's1',
  organizationId: ORG_A,
  permissions: new Set(perms),
  stepUpAt: null,
  ...over,
});
const engine = new DefaultDenyPolicyEngine();
const decide = (p: Principal | null, action: string, extra: object = {}) => engine.decide({ principal: p, action, now: NOW, ...extra });

test('default deny: unauthenticated and unknown actions', () => {
  assert.deepEqual(decide(null, 'organization.read'), { effect: 'deny', reason: 'UNAUTHENTICATED' });
  assert.deepEqual(decide(principal(), 'property.delete'), { effect: 'deny', reason: 'UNKNOWN_ACTION' });
  assert.deepEqual(decide(principal(), '__proto__'), { effect: 'deny', reason: 'UNKNOWN_ACTION' });
  assert.deepEqual(decide(principal(), 'toString'), { effect: 'deny', reason: 'UNKNOWN_ACTION' });
  assert.equal(isKnownAction('constructor'), false);
});

test('tenant isolation: forged / mismatched organization is denied before permissions', () => {
  const owner = principal({}, PERMISSIONS);
  assert.equal(decide(owner, 'organization.read', { resource: { organizationId: ORG_A } }).effect, 'allow');
  assert.deepEqual(decide(owner, 'organization.read', { resource: { organizationId: ORG_B } }), {
    effect: 'deny',
    reason: 'TENANT_MISMATCH',
  });
  assert.deepEqual(decide(owner, 'organization.read', { resource: { organizationId: null } }), {
    effect: 'deny',
    reason: 'TENANT_MISMATCH',
  });
  assert.deepEqual(decide(principal({ organizationId: null }, PERMISSIONS), 'organization.read'), {
    effect: 'deny',
    reason: 'NO_ACTIVE_ORGANIZATION',
  });
});

test('permissions: missing permission denied; held permission allowed', () => {
  assert.deepEqual(decide(principal(), 'audit.read'), { effect: 'deny', reason: 'PERMISSION_MISSING' });
  assert.equal(decide(principal({}, ['audit:read']), 'audit.read').effect, 'allow');
});

test('ownership: *_own actions require the resource to belong to the principal', () => {
  const p = principal({ organizationId: null });
  assert.deepEqual(decide(p, 'session.revoke_own', { resource: { ownerUserId: 'someone-else' } }), {
    effect: 'deny',
    reason: 'OWNERSHIP_REQUIRED',
  });
  assert.deepEqual(decide(p, 'session.revoke_own'), { effect: 'deny', reason: 'OWNERSHIP_REQUIRED' });
  assert.equal(decide(p, 'session.revoke_own', { resource: { ownerUserId: USER } }).effect, 'allow');
});

test('organization.create needs only authentication and works without an active organization', () => {
  assert.equal(decide(principal({ organizationId: null }, []), 'organization.create').effect, 'allow');
  assert.equal(decide(null, 'organization.create').effect, 'deny');
});

test('rules can restrict but never grant', () => {
  const restrictive = new DefaultDenyPolicyEngine({ rules: [() => ({ effect: 'deny', reason: 'POLICY_RULE_DENIED' })] });
  assert.deepEqual(restrictive.decide({ principal: principal(), action: 'organization.read', now: NOW }), {
    effect: 'deny',
    reason: 'POLICY_RULE_DENIED',
  });
  const permissive = new DefaultDenyPolicyEngine({ rules: [() => ({ effect: 'allow', risk: 'low' })] });
  assert.deepEqual(permissive.decide({ principal: principal(), action: 'audit.read', now: NOW }), {
    effect: 'deny',
    reason: 'PERMISSION_MISSING',
  });
});

test('risk obligations: step-up freshness and explicit confirmation', () => {
  // Phase 1 registry has no step-up/confirm actions; verify the mechanism with an injected rule.
  const needsStepUp = new DefaultDenyPolicyEngine({
    rules: [(req) => (req.action === 'organization.update' && !req.confirmed ? { effect: 'confirmation_required', risk: 'high' } : null)],
  });
  const p = principal({}, ['organization:update']);
  assert.equal(needsStepUp.decide({ principal: p, action: 'organization.update', now: NOW }).effect, 'confirmation_required');
  assert.equal(needsStepUp.decide({ principal: p, action: 'organization.update', now: NOW, confirmed: true }).effect, 'allow');
});

test('enforce: maps decisions to framework-neutral errors', () => {
  assert.throws(() => enforce({ effect: 'deny', reason: 'UNAUTHENTICATED' }), (e: unknown) => e instanceof AppError && e.kind === 'unauthenticated');
  assert.throws(() => enforce({ effect: 'deny', reason: 'TENANT_MISMATCH' }), (e: unknown) => e instanceof AppError && e.kind === 'forbidden');
  assert.throws(() => enforce({ effect: 'step_up_required', risk: 'high' }), (e: unknown) => e instanceof AppError && e.code === 'STEP_UP_REQUIRED');
  assert.throws(() => enforce({ effect: 'confirmation_required', risk: 'high' }), (e: unknown) => e instanceof AppError && e.code === 'CONFIRMATION_REQUIRED');
  assert.doesNotThrow(() => enforce({ effect: 'allow', risk: 'low' }));
});

test('registry consistency: every required permission is a real permission granted to some role', () => {
  const granted = new Set(SYSTEM_ROLES.flatMap((r) => r.permissions));
  for (const d of Object.values(ACTIONS)) {
    if (d.permission !== null) {
      assert.ok((PERMISSIONS as readonly string[]).includes(d.permission), `${d.action} -> unknown permission`);
      assert.ok(granted.has(d.permission as never), `${d.action} -> no role grants ${d.permission}`);
    }
  }
  const owner = SYSTEM_ROLES.find((r) => r.key === 'owner');
  assert.deepEqual([...(owner?.permissions ?? [])].sort(), [...PERMISSIONS].sort());
  const viewer = SYSTEM_ROLES.find((r) => r.key === 'viewer');
  assert.ok(!viewer?.permissions.includes('audit:read'));
});
