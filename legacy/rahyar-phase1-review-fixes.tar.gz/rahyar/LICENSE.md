# Proprietary Notice

Copyright (c) RAHYAR. All rights reserved.

This repository and its contents are proprietary and confidential. No license is
granted to use, copy, modify, distribute or disclose any part of this software
without prior written permission. Third-party dependencies remain under their own
licenses (see docs/licenses.md).
