import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  DEFAULT_OTP_POLICY,
  evaluateOtpAttempt,
  evaluateOtpRequestRate,
  generateOtpCode,
  hashOtp,
  type ChallengeState,
} from './otp.ts';
import { generateToken, hasTokenShape, hashToken, keyedHash } from './tokens.ts';
import { DEFAULT_SESSION_POLICY, evaluateRefresh, refreshExpiry } from './refresh.ts';

const PEPPER = 'p'.repeat(40);
const T0 = new Date('2026-10-02T10:00:00Z');
const at = (s: number): Date => new Date(T0.getTime() + s * 1000);

function challenge(code: string, over: Partial<ChallengeState> = {}): ChallengeState {
  const id = '0192f0a0-0000-7000-8000-000000000001';
  const phone = '+989123456789';
  return {
    id,
    phoneE164: phone,
    codeHash: hashOtp(PEPPER, id, phone, code),
    attempts: 0,
    maxAttempts: 5,
    expiresAt: at(120),
    consumedAt: null,
    lockedAt: null,
    ...over,
  };
}

test('otp: codes are fixed-length digits; hash is keyed and bound to challenge and phone', () => {
  for (let i = 0; i < 200; i++) assert.match(generateOtpCode(6), /^\d{6}$/);
  const h = hashOtp(PEPPER, 'a', '+989123456789', '123456');
  assert.match(h, /^[0-9a-f]{64}$/);
  assert.ok(!h.includes('123456'));
  assert.notEqual(h, hashOtp('q'.repeat(40), 'a', '+989123456789', '123456'));
  assert.notEqual(h, hashOtp(PEPPER, 'b', '+989123456789', '123456'));
  assert.notEqual(h, hashOtp(PEPPER, 'a', '+989123456780', '123456'));
});

test('otp: correct code verifies (Persian digits accepted)', () => {
  assert.equal(evaluateOtpAttempt(challenge('123456'), '123456', at(5), PEPPER).outcome, 'verified');
  assert.equal(evaluateOtpAttempt(challenge('123456'), '۱۲۳۴۵۶', at(5), PEPPER).outcome, 'verified');
});

test('otp: wrong code increments attempts and locks at the limit', () => {
  let s = challenge('123456');
  for (let n = 1; n <= 5; n++) {
    const r = evaluateOtpAttempt(s, '000000', at(5), PEPPER);
    assert.equal(r.outcome, 'invalid');
    if (r.outcome !== 'invalid') return;
    assert.equal(r.attempts, n);
    assert.equal(r.remaining, 5 - n);
    s = { ...s, attempts: r.attempts, lockedAt: r.lockedAt };
    assert.equal(r.lockedAt !== null, n === 5);
  }
  // Even the CORRECT code is rejected once locked.
  assert.equal(evaluateOtpAttempt(s, '123456', at(6), PEPPER).outcome, 'locked');
});

test('otp: expiry boundary, replay (consumed) and malformed input', () => {
  assert.equal(evaluateOtpAttempt(challenge('123456'), '123456', at(119), PEPPER).outcome, 'verified');
  assert.equal(evaluateOtpAttempt(challenge('123456'), '123456', at(120), PEPPER).outcome, 'expired');
  assert.equal(evaluateOtpAttempt(challenge('123456', { consumedAt: at(10) }), '123456', at(20), PEPPER).outcome, 'consumed');
  assert.equal(evaluateOtpAttempt(challenge('123456'), '12345', at(5), PEPPER).outcome, 'invalid');
  assert.equal(evaluateOtpAttempt(challenge('123456'), "123456' OR 1=1", at(5), PEPPER).outcome, 'invalid');
});

test('otp rate limit: cooldown, per-phone window, per-ip window', () => {
  const p = DEFAULT_OTP_POLICY;
  assert.deepEqual(evaluateOtpRequestRate({ phoneRequests: [], ipRequests: [], now: T0, policy: p }), { allowed: true });
  const cd = evaluateOtpRequestRate({ phoneRequests: [at(-10)], ipRequests: [], now: T0, policy: p });
  assert.deepEqual(cd, { allowed: false, reason: 'cooldown', retryAfterSeconds: 50 });
  const many = [-3000, -2500, -2000, -1500, -1000].map(at);
  const pl = evaluateOtpRequestRate({ phoneRequests: many, ipRequests: [], now: T0, policy: p });
  assert.equal(pl.allowed, false);
  if (!pl.allowed) {
    assert.equal(pl.reason, 'phone_limit');
    assert.equal(pl.retryAfterSeconds, 600);
  }
  const ips = Array.from({ length: 30 }, (_, i) => at(-3000 + i));
  const il = evaluateOtpRequestRate({ phoneRequests: [], ipRequests: ips, now: T0, policy: p });
  assert.equal(il.allowed === false && il.reason, 'ip_limit');
  const old = evaluateOtpRequestRate({ phoneRequests: [at(-4000)], ipRequests: [], now: T0, policy: p });
  assert.equal(old.allowed, true);
});

test('tokens: opaque, prefixed, high-entropy, stored only as digest', () => {
  const a = generateToken('access');
  const r = generateToken('refresh');
  assert.ok(hasTokenShape('access', a) && hasTokenShape('refresh', r));
  assert.ok(!hasTokenShape('access', r));
  assert.ok(!hasTokenShape('access', a + 'x') && !hasTokenShape('access', 'rhy_at_short'));
  assert.notEqual(a, generateToken('access'));
  assert.match(hashToken(a), /^[0-9a-f]{64}$/);
  assert.notEqual(hashToken(a), a);
  assert.notEqual(keyedHash(PEPPER, 'ip', '1.2.3.4'), keyedHash(PEPPER, 'device', '1.2.3.4'));
});

test('refresh: rotate / reuse detection / revoked / expired decisions', () => {
  const session = { id: 's', revokedAt: null, absoluteExpiresAt: at(100_000) };
  const rec = { id: 'r', sessionId: 's', generation: 1, expiresAt: at(1000), usedAt: null, revokedAt: null };
  assert.deepEqual(evaluateRefresh(rec, session, at(10)), { decision: 'rotate' });
  assert.deepEqual(evaluateRefresh({ ...rec, usedAt: at(5) }, session, at(10)), { decision: 'reuse_detected' });
  assert.deepEqual(evaluateRefresh(rec, session, at(1000)), { decision: 'reject', reason: 'expired' });
  assert.deepEqual(evaluateRefresh({ ...rec, revokedAt: at(1) }, session, at(10)), { decision: 'reject', reason: 'revoked' });
  assert.deepEqual(evaluateRefresh(rec, { ...session, revokedAt: at(1) }, at(10)), { decision: 'reject', reason: 'session_revoked' });
  assert.deepEqual(evaluateRefresh({ ...rec, usedAt: at(5) }, { ...session, revokedAt: at(6) }, at(10)), {
    decision: 'reject',
    reason: 'session_revoked',
  });
  assert.deepEqual(evaluateRefresh(rec, { ...session, absoluteExpiresAt: at(10) }, at(10)), { decision: 'reject', reason: 'session_expired' });
});

test('refresh: expiry is capped by the absolute session lifetime', () => {
  const abs = at(3600);
  assert.equal(refreshExpiry(T0, abs, DEFAULT_SESSION_POLICY).getTime(), abs.getTime());
  const far = at(10 * 365 * 24 * 3600);
  assert.equal(refreshExpiry(T0, far, DEFAULT_SESSION_POLICY).getTime(), at(DEFAULT_SESSION_POLICY.refreshTtlSeconds).getTime());
});
