import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const schema = readFileSync(join(here, 'env.schema.ts'), 'utf8');
const example = readFileSync(join(here, '../../../../../.env.example'), 'utf8');

test('.env.example documents every variable in the validated env schema', () => {
  const body = /z\s*\.object\(\{([\s\S]*?)\n  \}\)/.exec(schema)?.[1] ?? '';
  const keys = [...body.matchAll(/^\s{4}([A-Z][A-Z0-9_]+):/gm)].map((m) => m[1] as string);
  assert.ok(keys.length >= 15, `parsed ${keys.length} keys`);
  for (const k of keys) assert.match(example, new RegExp(`^${k}=`, 'm'), `${k} missing from .env.example`);
});

test('.env.example contains placeholders only (no real-looking secrets)', () => {
  for (const line of example.split('\n')) {
    if (/(PASSWORD|PEPPER|API_KEY)/.test(line.split('=')[0] ?? '') && line.split('=')[1]) assert.match(line, /change-me/, line);
  }
});
