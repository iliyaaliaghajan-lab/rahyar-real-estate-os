// Source-level BFF/web security guards. Run without Next installed.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const walk = (d: string): string[] => readdirSync(d).flatMap((f) => (statSync(join(d, f)).isDirectory() ? walk(join(d, f)) : [join(d, f)]));
const files = walk(root).filter((f) => /\.(ts|tsx)$/.test(f) && !f.endsWith('.test.ts'));
const read = (f: string): string => readFileSync(f, 'utf8');
const routes = files.filter((f) => f.endsWith('route.ts'));

test('bff: tokens are httpOnly + SameSite=strict + secure in production; refresh cookie is path-scoped', () => {
  const s = read(join(root, 'lib/bff.ts'));
  assert.match(s, /httpOnly: true, secure: SECURE, sameSite: 'strict'/);
  assert.match(s, /const SECURE = process\.env\.NODE_ENV === 'production'/);
  assert.match(s, /COOKIE\.refresh, t\.refreshToken, \{ \.\.\.base, path: '\/api\/auth'/);
  assert.equal([...s.matchAll(/httpOnly: true/g)].length, 2, 'every cookie we set is httpOnly');
  assert.doesNotMatch(s, /httpOnly: false/);
});

test('bff: server-only secrets/config never reach browser bundles', () => {
  assert.match(read(join(root, 'lib/bff.ts')), /^import 'server-only';/m);
  for (const f of files) {
    const s = read(f);
    assert.doesNotMatch(s, /NEXT_PUBLIC_/, `${f}: no public env`);
    if (!f.endsWith(join('lib', 'bff.ts'))) assert.doesNotMatch(s, /API_BASE_URL|APP_ORIGIN/, `${f}: server env only in lib/bff.ts`);
    if (s.startsWith("'use client'")) {
      assert.doesNotMatch(s, /@\/lib\/bff|server-only/, `${f}: client component must not import server code`);
      assert.doesNotMatch(s, /from '@rahyar\/domain-kernel'/, `${f}: use the browser-safe subpath (root index imports node:crypto)`);
      assert.doesNotMatch(s, /localStorage|sessionStorage|document\.cookie/, `${f}: tokens never touch JS-accessible storage`);
    }
  }
});

test('bff: every state-changing route checks same-origin (CSRF) before doing anything', () => {
  for (const f of routes) {
    const s = read(f);
    if (/export async function POST/.test(s)) {
      assert.match(s, /if \(!isSameOrigin\(req\)\)/, `${f} POST must check origin`);
      assert.ok(s.indexOf('isSameOrigin') < s.indexOf('await req.json') || !s.includes('await req.json'), `${f}: origin check precedes body parsing`);
    }
  }
  const me = read(join(root, 'app/api/auth/me/route.ts'));
  assert.match(me, /isNotCrossSite\(req\)/, 'GET /me can rotate cookies, so it rejects cross-site fetches');
});

test('bff: tokens are never returned to browser JavaScript', () => {
  for (const f of routes) {
    const s = read(f);
    for (const m of s.matchAll(/NextResponse\.json\(([^;]*?)\)(?:;|\n)/g)) {
      const arg = m[1] ?? '';
      if (f.includes('/request/')) continue; // returns {challengeId, resendAfterSeconds} only
      // Forbid forwarding a whole upstream payload (which would contain tokens) or naming token fields; named safe fields are fine.
      assert.doesNotMatch(arg, /(?:^|[\s,:{(])(?:r|t|me)\.data\s*(?:,|$)|accessToken|refreshToken/, `${f}: response must not carry tokens: ${arg}`);
    }
  }
  assert.match(read(join(root, 'app/api/auth/verify/route.ts')), /Tokens are NOT returned to the browser/);
});

test('bff: forwards the real client IP and has no other cookie writers', () => {
  const s = read(join(root, 'lib/bff.ts'));
  assert.match(s, /x-forwarded-for/);
  for (const f of files) if (!f.endsWith(join('lib', 'bff.ts'))) assert.doesNotMatch(read(f), /\.cookies?\.set\(|jar\.set\(|Set-Cookie/i, `${f}: cookies are written only in lib/bff.ts`);
});
