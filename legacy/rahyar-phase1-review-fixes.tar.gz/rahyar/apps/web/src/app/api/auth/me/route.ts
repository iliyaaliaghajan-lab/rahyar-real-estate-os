import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { api, clearSession, clientIp, COOKIE, isNotCrossSite, setSession } from '@/lib/bff';

type Me = { userId: string; organizationId: string | null; permissions: string[] };
type Tokens = { accessToken: string; accessExpiresAt: string; refreshToken: string; refreshExpiresAt: string };

export async function GET(req: Request) {
  if (!isNotCrossSite(req)) return NextResponse.json({ authenticated: false }, { status: 403 });
  const jar = await cookies();
  let access = jar.get(COOKIE.access)?.value;
  let me = access ? await api<Me>('/auth/me', { token: access }) : null;
  if (!me?.ok) {
    const refresh = jar.get(COOKIE.refresh)?.value;
    if (refresh) {
      const t = await api<Tokens>('/auth/refresh', { method: 'POST', body: { refreshToken: refresh }, ip: clientIp(req) });
      if (t.ok) {
        await setSession(t.data);
        access = t.data.accessToken;
        me = await api<Me>('/auth/me', { token: access });
      }
    }
  }
  if (!me?.ok) {
    await clearSession();
    return NextResponse.json({ authenticated: false }, { status: 401 });
  }
  return NextResponse.json({ authenticated: true, organizationId: me.data.organizationId, permissions: me.data.permissions });
}
