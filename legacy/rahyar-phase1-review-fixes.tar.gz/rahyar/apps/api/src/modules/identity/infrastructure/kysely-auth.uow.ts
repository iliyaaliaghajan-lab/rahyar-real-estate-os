import { sql } from 'kysely';
import { uuidv7 } from '@rahyar/domain-kernel';
import { sanitizeAuditMetadata, type AuditEntry } from '../../audit/audit.types.ts';
import { bindUserAndOrg, setLocalConfig, withAuthScope, withTenantContext, type Db, type Trx } from '../../../platform/database/tenant-context.ts';
import type {
  AuthTx,
  AuthUnitOfWork,
  ChallengeRecord,
  SessionRecord,
  SessionWithContext,
} from '../application/ports.ts';

export class KyselyAuthUnitOfWork implements AuthUnitOfWork {
  private readonly db: Db;
  constructor(db: Db) {
    this.db = db;
  }
  run<T>(fn: (tx: AuthTx) => Promise<T>): Promise<T> {
    return withAuthScope(this.db, (trx) => fn(new KyselyAuthTx(trx)));
  }
  runAsUser<T>(userId: string, fn: (tx: AuthTx) => Promise<T>): Promise<T> {
    // NOT auth scope: RLS confines devices/sessions/refresh_tokens/memberships to this user.
    return withTenantContext(this.db, { userId, organizationId: null }, (trx) => fn(new KyselyAuthTx(trx)));
  }
}

const sessionCols = [
  'sessions.id as id',
  'sessions.userId as userId',
  'sessions.deviceId as deviceId',
  'sessions.organizationId as organizationId',
  'sessions.accessExpiresAt as accessExpiresAt',
  'sessions.absoluteExpiresAt as absoluteExpiresAt',
  'sessions.stepUpAt as stepUpAt',
  'sessions.lastSeenAt as lastSeenAt',
  'sessions.revokedAt as revokedAt',
] as const;

class KyselyAuthTx implements AuthTx {
  private readonly trx: Trx;
  constructor(trx: Trx) {
    this.trx = trx;
  }

  async recentChallengeTimes(by: { phoneE164: string } | { ipHash: string }, since: Date): Promise<Date[]> {
    let q = this.trx.selectFrom('otpChallenges').select('createdAt').where('createdAt', '>=', since);
    q = 'phoneE164' in by ? q.where('phoneE164', '=', by.phoneE164) : q.where('ipHash', '=', by.ipHash);
    return (await q.execute()).map((r) => r.createdAt);
  }

  async insertChallenge(c: Parameters<AuthTx['insertChallenge']>[0]): Promise<void> {
    await this.trx.insertInto('otpChallenges').values({
      id: c.id, phoneE164: c.phoneE164, purpose: c.purpose, codeHash: c.codeHash, maxAttempts: c.maxAttempts,
      ipHash: c.ipHash, createdAt: c.createdAt, expiresAt: c.expiresAt,
    }).execute();
  }

  async invalidateOpenChallenges(phoneE164: string, purpose: 'login' | 'step_up', now: Date): Promise<void> {
    await this.trx.updateTable('otpChallenges').set({ consumedAt: now }).where('phoneE164', '=', phoneE164).where('purpose', '=', purpose).where('consumedAt', 'is', null).execute();
  }

  async getChallengeForUpdate(id: string): Promise<ChallengeRecord | null> {
    const r = await this.trx.selectFrom('otpChallenges').selectAll().where('id', '=', id).forUpdate().executeTakeFirst();
    return r ? { id: r.id, phoneE164: r.phoneE164, purpose: r.purpose, codeHash: r.codeHash, attempts: r.attempts, maxAttempts: r.maxAttempts, expiresAt: r.expiresAt, consumedAt: r.consumedAt, lockedAt: r.lockedAt } : null;
  }

  async updateChallengeAttempts(id: string, attempts: number, lockedAt: Date | null): Promise<void> {
    await this.trx.updateTable('otpChallenges').set({ attempts, lockedAt }).where('id', '=', id).execute();
  }

  async consumeChallenge(id: string, now: Date): Promise<boolean> {
    const r = await this.trx.updateTable('otpChallenges').set({ consumedAt: now }).where('id', '=', id).where('consumedAt', 'is', null).executeTakeFirst();
    return Number(r.numUpdatedRows) === 1;
  }

  async expireChallenge(id: string, now: Date): Promise<void> {
    await this.trx.updateTable('otpChallenges').set({ expiresAt: now, consumedAt: now }).where('id', '=', id).execute();
  }

  async findUserByPhone(phoneE164: string) {
    const u = await this.trx.selectFrom('users').select(['id', 'phoneE164', 'status', 'displayName']).where('phoneE164', '=', phoneE164).executeTakeFirst();
    return u ?? null;
  }

  async createUser(u: { id: string; phoneE164: string; now: Date }) {
    return this.trx.insertInto('users').values({ id: u.id, phoneE164: u.phoneE164, displayName: null, phoneVerifiedAt: u.now })
      .returning(['id', 'phoneE164', 'status', 'displayName']).executeTakeFirstOrThrow();
  }

  async markLogin(userId: string, now: Date): Promise<void> {
    await this.trx.updateTable('users').set({ lastLoginAt: now }).where('id', '=', userId).execute();
  }

  async upsertDevice(d: Parameters<AuthTx['upsertDevice']>[0]) {
    return this.trx.insertInto('devices')
      .values({ id: d.id, userId: d.userId, fingerprintHash: d.fingerprintHash, label: d.label, platform: d.platform, firstSeenAt: d.now, lastSeenAt: d.now })
      .onConflict((oc) => oc.columns(['userId', 'fingerprintHash']).doUpdateSet({ lastSeenAt: d.now }))
      .returning(['id', 'userId', 'revokedAt']).executeTakeFirstOrThrow();
  }

  async listActiveOrganizationIds(userId: string): Promise<string[]> {
    await bindUserAndOrg(this.trx, userId, null);
    const rows = await this.trx.selectFrom('organizationMemberships').select('organizationId').where('userId', '=', userId).where('status', '=', 'active').execute();
    return rows.map((r) => r.organizationId);
  }

  async createSession(s: Parameters<AuthTx['createSession']>[0]): Promise<void> {
    await this.trx.insertInto('sessions').values({
      id: s.id, userId: s.userId, deviceId: s.deviceId, organizationId: s.organizationId, accessTokenHash: s.accessTokenHash,
      accessExpiresAt: s.accessExpiresAt, absoluteExpiresAt: s.absoluteExpiresAt, createdAt: s.now, lastSeenAt: s.now,
      stepUpAt: null, revokedAt: null, revokedReason: null,
    }).execute();
  }

  async insertRefreshToken(r: Parameters<AuthTx['insertRefreshToken']>[0]): Promise<void> {
    await this.trx.insertInto('refreshTokens').values({
      id: r.id, sessionId: r.sessionId, userId: r.userId, tokenHash: r.tokenHash, generation: r.generation, expiresAt: r.expiresAt, usedAt: null, revokedAt: null,
    }).execute();
  }

  private sessionWithContext() {
    return this.trx.selectFrom('sessions')
      .innerJoin('users', 'users.id', 'sessions.userId')
      .innerJoin('devices', 'devices.id', 'sessions.deviceId')
      .select([...sessionCols, 'users.status as userStatus', 'devices.revokedAt as deviceRevokedAt']);
  }

  async findSessionByAccessHash(hash: string): Promise<SessionWithContext | null> {
    return (await this.sessionWithContext().where('sessions.accessTokenHash', '=', hash).executeTakeFirst()) ?? null;
  }

  async touchSession(id: string, now: Date): Promise<void> {
    await this.trx.updateTable('sessions').set({ lastSeenAt: now }).where('id', '=', id).execute();
  }

  async loadPermissions(userId: string, organizationId: string): Promise<string[] | null> {
    await bindUserAndOrg(this.trx, userId, organizationId);
    const row = await this.trx.selectFrom('organizationMemberships')
      .innerJoin('roles', (j) => j.onRef('roles.id', '=', 'organizationMemberships.roleId').onRef('roles.organizationId', '=', 'organizationMemberships.organizationId'))
      .select('roles.permissions as permissions')
      .where('organizationMemberships.userId', '=', userId)
      .where('organizationMemberships.organizationId', '=', organizationId)
      .where('organizationMemberships.status', '=', 'active')
      .executeTakeFirst();
    return row ? row.permissions : null;
  }

  async getRefreshForUpdate(tokenHash: string) {
    const r = await this.trx.selectFrom('refreshTokens').selectAll().where('tokenHash', '=', tokenHash).forUpdate().executeTakeFirst();
    if (!r) return null;
    const session = await this.sessionWithContext().where('sessions.id', '=', r.sessionId).executeTakeFirst();
    if (!session) return null;
    return {
      record: { id: r.id, sessionId: r.sessionId, userId: r.userId, generation: r.generation, expiresAt: r.expiresAt, usedAt: r.usedAt, revokedAt: r.revokedAt },
      session,
    };
  }

  async markRefreshUsed(id: string, now: Date): Promise<boolean> {
    const r = await this.trx.updateTable('refreshTokens').set({ usedAt: now }).where('id', '=', id).where('usedAt', 'is', null).executeTakeFirst();
    return Number(r.numUpdatedRows) === 1;
  }

  async rotateAccess(sessionId: string, accessTokenHash: string, accessExpiresAt: Date, now: Date): Promise<void> {
    await this.trx.updateTable('sessions').set({ accessTokenHash, accessExpiresAt, lastSeenAt: now }).where('id', '=', sessionId).execute();
  }

  async setSessionOrganization(sessionId: string, organizationId: string): Promise<void> {
    await this.trx.updateTable('sessions').set({ organizationId }).where('id', '=', sessionId).execute();
  }

  async revokeSession(id: string, reason: string, now: Date): Promise<void> {
    await this.trx.updateTable('sessions').set({ revokedAt: now, revokedReason: reason }).where('id', '=', id).where('revokedAt', 'is', null).execute();
    await this.trx.updateTable('refreshTokens').set({ revokedAt: now }).where('sessionId', '=', id).where('revokedAt', 'is', null).execute();
  }

  async revokeDevice(userId: string, deviceId: string, now: Date): Promise<boolean> {
    const d = await this.trx.updateTable('devices').set({ revokedAt: sql`coalesce(revoked_at, ${now})` }).where('id', '=', deviceId).where('userId', '=', userId).executeTakeFirst();
    if (Number(d.numUpdatedRows) !== 1) return false;
    const sessions = await this.trx.selectFrom('sessions').select('id').where('deviceId', '=', deviceId).where('revokedAt', 'is', null).execute();
    for (const s of sessions) await this.revokeSession(s.id, 'device_revoked', now);
    return true;
  }

  async getSession(id: string): Promise<SessionRecord | null> {
    return (await this.trx.selectFrom('sessions').select(sessionCols).where('sessions.id', '=', id).executeTakeFirst()) ?? null;
  }

  async listSessions(userId: string) {
    return this.trx.selectFrom('sessions').innerJoin('devices', 'devices.id', 'sessions.deviceId')
      .select(['sessions.id as id', 'sessions.deviceId as deviceId', 'devices.label as deviceLabel', 'devices.platform as platform', 'sessions.organizationId as organizationId', 'sessions.createdAt as createdAt', 'sessions.lastSeenAt as lastSeenAt'])
      .where('sessions.userId', '=', userId).where('sessions.revokedAt', 'is', null).orderBy('sessions.createdAt', 'desc').execute();
  }

  async listDevices(userId: string) {
    return this.trx.selectFrom('devices').select(['id', 'label', 'platform', 'trustedAt', 'revokedAt', 'lastSeenAt']).where('userId', '=', userId).orderBy('lastSeenAt', 'desc').execute();
  }

  async appendAudit(e: AuditEntry): Promise<void> {
    // The org id comes from server-side logic; bind it so the audit RLS policy can verify it.
    if (e.organizationId) await setLocalConfig(this.trx, 'app.org_id', e.organizationId);
    await this.trx.insertInto('auditLogs').values({
      id: uuidv7(), organizationId: e.organizationId, actorType: e.actorType, actorUserId: e.actorUserId, actorSessionId: e.actorSessionId,
      action: e.action, resourceType: e.resourceType ?? null, resourceId: e.resourceId ?? null, outcome: e.outcome,
      requestId: e.requestId ?? null, ipHash: e.ipHash ?? null, metadata: JSON.stringify(sanitizeAuditMetadata(e.metadata ?? {})),
    }).execute();
  }
}
