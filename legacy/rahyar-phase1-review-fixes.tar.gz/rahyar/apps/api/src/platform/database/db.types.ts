import type { ColumnType, Generated } from 'kysely';

// With CamelCasePlugin: TS camelCase <-> SQL snake_case. Types mirror db/migrations.
type Ts = ColumnType<Date, Date | string | undefined, Date | string>;
type TsNullable = ColumnType<Date | null, Date | string | null | undefined, Date | string | null>;
type Json = ColumnType<Record<string, unknown>, string, string>;
type JsonNullable = ColumnType<unknown, string | null | undefined, string | null>;

export interface OrganizationsTable { id: string; name: string; status: Generated<'active' | 'suspended' | 'closed'>; createdAt: Generated<Date>; updatedAt: Generated<Date>; version: Generated<number> }
export interface UsersTable { id: string; phoneE164: string; displayName: string | null; locale: Generated<string>; status: Generated<'active' | 'disabled'>; phoneVerifiedAt: TsNullable; lastLoginAt: TsNullable; createdAt: Generated<Date>; updatedAt: Generated<Date>; version: Generated<number> }
export interface RolesTable { id: string; organizationId: string; key: string; name: string; permissions: string[]; isSystem: boolean; createdAt: Generated<Date>; updatedAt: Generated<Date>; version: Generated<number> }
export interface MembershipsTable { id: string; organizationId: string; userId: string; roleId: string; status: Generated<'active' | 'invited' | 'suspended' | 'removed'>; createdAt: Generated<Date>; updatedAt: Generated<Date>; version: Generated<number> }
export interface DevicesTable { id: string; userId: string; fingerprintHash: string; label: string | null; platform: 'web' | 'ios' | 'android' | 'desktop' | 'unknown'; trustedAt: TsNullable; revokedAt: TsNullable; firstSeenAt: Ts; lastSeenAt: Ts }
export interface SessionsTable { id: string; userId: string; deviceId: string; organizationId: string | null; authMethod: Generated<string>; accessTokenHash: string; accessExpiresAt: Ts; absoluteExpiresAt: Ts; stepUpAt: TsNullable; createdAt: Ts; lastSeenAt: Ts; revokedAt: TsNullable; revokedReason: string | null }
export interface RefreshTokensTable { id: string; sessionId: string; userId: string; tokenHash: string; generation: number; createdAt: Generated<Date>; expiresAt: Ts; usedAt: TsNullable; revokedAt: TsNullable }
export interface OtpChallengesTable { id: string; phoneE164: string; purpose: 'login' | 'step_up'; codeHash: string; attempts: Generated<number>; maxAttempts: number; ipHash: string | null; createdAt: Ts; expiresAt: Ts; consumedAt: TsNullable; lockedAt: TsNullable }
export interface AuditLogsTable { id: string; organizationId: string | null; actorType: 'user' | 'system' | 'ai'; actorUserId: string | null; actorSessionId: string | null; action: string; resourceType: string | null; resourceId: string | null; outcome: 'success' | 'denied' | 'failure'; requestId: string | null; ipHash: string | null; metadata: Json; occurredAt: Generated<Date> }
export interface IdempotencyKeysTable { id: string; userId: string; organizationId: string | null; key: string; method: string; path: string; requestHash: string; status: Generated<'in_progress' | 'completed'>; responseStatus: number | null; responseBody: JsonNullable; createdAt: Generated<Date>; completedAt: TsNullable; expiresAt: Ts }
export interface OutboxEventsTable { id: string; organizationId: string | null; aggregateType: string; aggregateId: string; eventType: string; payload: Json; status: Generated<'pending' | 'published' | 'failed'>; attempts: Generated<number>; availableAt: Generated<Date>; publishedAt: TsNullable; lastError: string | null; createdAt: Generated<Date> }

export interface Database {
  organizations: OrganizationsTable;
  users: UsersTable;
  roles: RolesTable;
  organizationMemberships: MembershipsTable;
  devices: DevicesTable;
  sessions: SessionsTable;
  refreshTokens: RefreshTokensTable;
  otpChallenges: OtpChallengesTable;
  auditLogs: AuditLogsTable;
  idempotencyKeys: IdempotencyKeysTable;
  outboxEvents: OutboxEventsTable;
}
