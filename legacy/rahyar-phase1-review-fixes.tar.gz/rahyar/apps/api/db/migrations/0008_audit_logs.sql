-- Append-only. Enforced three ways: no UPDATE/DELETE/TRUNCATE grants for the app role,
-- BEFORE UPDATE/DELETE row triggers, and a BEFORE TRUNCATE statement trigger.
CREATE TABLE audit_logs (
  id               uuid PRIMARY KEY,
  organization_id  uuid,
  actor_type       text NOT NULL CHECK (actor_type IN ('user', 'system', 'ai')),
  actor_user_id    uuid,
  actor_session_id uuid,
  action           text NOT NULL CHECK (char_length(action) BETWEEN 3 AND 120),
  resource_type    text,
  resource_id      text,
  outcome          text NOT NULL CHECK (outcome IN ('success', 'denied', 'failure')),
  request_id       text,
  ip_hash          text,
  metadata         jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(metadata) = 'object'),
  occurred_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_logs_org_time_idx ON audit_logs (organization_id, occurred_at DESC);
CREATE INDEX audit_logs_actor_time_idx ON audit_logs (actor_user_id, occurred_at DESC);

CREATE TRIGGER audit_logs_no_update BEFORE UPDATE OR DELETE ON audit_logs
  FOR EACH ROW EXECUTE FUNCTION app.forbid_mutation();
CREATE TRIGGER audit_logs_no_truncate BEFORE TRUNCATE ON audit_logs
  FOR EACH STATEMENT EXECUTE FUNCTION app.forbid_mutation();

ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs FORCE ROW LEVEL SECURITY;
CREATE POLICY audit_logs_select ON audit_logs FOR SELECT TO rahyar_app
  USING (
    organization_id = app.current_org_id()
    OR (organization_id IS NULL AND actor_user_id = app.current_user_id())
  );
CREATE POLICY audit_logs_insert ON audit_logs FOR INSERT TO rahyar_app
  WITH CHECK (
    (
      organization_id = app.current_org_id()
      OR (organization_id IS NULL AND (app.is_auth_scope() OR app.current_user_id() IS NOT NULL))
    )
    -- an actor can only be the bound user (or the trusted auth flow, or a system/anonymous actor)
    AND (actor_user_id IS NULL OR actor_user_id = app.current_user_id() OR app.is_auth_scope())
  );

REVOKE ALL ON audit_logs FROM PUBLIC;
GRANT SELECT, INSERT ON audit_logs TO rahyar_app;
