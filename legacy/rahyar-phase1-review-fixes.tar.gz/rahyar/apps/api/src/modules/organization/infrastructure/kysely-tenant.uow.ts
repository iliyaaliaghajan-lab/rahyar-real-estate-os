import { AppError, uuidv7 } from '@rahyar/domain-kernel';
import { sanitizeAuditMetadata, type AuditEntry } from '../../audit/audit.types.ts';
import { withTenantContext, type Db, type Trx } from '../../../platform/database/tenant-context.ts';
import type { AuditLogView, BootstrapTx, IdempotencyClaim, OrganizationRecord, OutboxEventInput, TenantTx, TenantUnitOfWork } from '../application/ports.ts';

export class KyselyTenantUnitOfWork implements TenantUnitOfWork {
  private readonly db: Db;
  constructor(db: Db) {
    this.db = db;
  }
  run<T>(ctx: { userId: string; organizationId: string | null; sessionId: string }, fn: (tx: TenantTx) => Promise<T>): Promise<T> {
    return withTenantContext(this.db, { userId: ctx.userId, organizationId: ctx.organizationId }, (trx) => fn(new KyselyTenantTx(trx, ctx.userId)));
  }

  bootstrap<T>(ctx: { userId: string; sessionId: string; newOrganizationId: string }, fn: (tx: BootstrapTx) => Promise<T>): Promise<T> {
    return withTenantContext(this.db, { userId: ctx.userId, organizationId: ctx.newOrganizationId, bootstrapOrganization: true }, (trx) => {
      const t = new KyselyTenantTx(trx, ctx.userId);
      // Explicit write-only facade: no read method is reachable from a bootstrap transaction.
      return fn({
        claimIdempotency: (k) => t.claimIdempotency(k),
        completeIdempotency: (k, s, b, n) => t.completeIdempotency(k, s, b, n),
        insertOrganization: (o) => t.insertOrganization(o),
        insertRole: (r) => t.insertRole(r),
        insertMembership: (m) => t.insertMembership(m),
        setSessionOrganization: (sid, oid) => t.setSessionOrganization(sid, oid),
        appendAudit: (e) => t.appendAudit(e),
        appendOutbox: (e) => t.appendOutbox(e),
      });
    });
  }
}

class KyselyTenantTx implements TenantTx {
  private readonly trx: Trx;
  private readonly userId: string;
  constructor(trx: Trx, userId: string) {
    this.trx = trx;
    this.userId = userId;
  }

  async claimIdempotency(k: Parameters<TenantTx['claimIdempotency']>[0]): Promise<IdempotencyClaim> {
    const inserted = await this.trx.insertInto('idempotencyKeys')
      .values({ id: uuidv7(), userId: this.userId, organizationId: null, key: k.key, method: k.method, path: k.path, requestHash: k.requestHash, responseStatus: null, responseBody: null, completedAt: null, expiresAt: new Date(k.now.getTime() + k.ttlSeconds * 1000) })
      .onConflict((oc) => oc.columns(['userId', 'key']).doNothing()).returning('id').executeTakeFirst();
    if (inserted) return { state: 'claimed' };
    const ex = await this.trx.selectFrom('idempotencyKeys').selectAll().where('userId', '=', this.userId).where('key', '=', k.key).executeTakeFirstOrThrow();
    if (ex.requestHash !== k.requestHash) return { state: 'mismatch' };
    if (ex.status !== 'completed') throw new AppError('conflict', 'IDEMPOTENCY_IN_PROGRESS', 'A request with this key is still in progress.');
    return { state: 'replay', responseStatus: ex.responseStatus ?? 200, responseBody: ex.responseBody };
  }

  async completeIdempotency(key: string, responseStatus: number, responseBody: unknown, now: Date): Promise<void> {
    await this.trx.updateTable('idempotencyKeys').set({ status: 'completed', responseStatus, responseBody: JSON.stringify(responseBody), completedAt: now }).where('userId', '=', this.userId).where('key', '=', key).execute();
  }

  async insertOrganization(o: { id: string; name: string }): Promise<void> {
    await this.trx.insertInto('organizations').values({ id: o.id, name: o.name }).execute();
  }
  async insertRole(r: Parameters<TenantTx['insertRole']>[0]): Promise<void> {
    await this.trx.insertInto('roles').values({ id: r.id, organizationId: r.organizationId, key: r.key, name: r.name, permissions: [...r.permissions], isSystem: r.isSystem }).execute();
  }
  async insertMembership(m: Parameters<TenantTx['insertMembership']>[0]): Promise<void> {
    await this.trx.insertInto('organizationMemberships').values({ id: m.id, organizationId: m.organizationId, userId: m.userId, roleId: m.roleId }).execute();
  }
  async setSessionOrganization(sessionId: string, organizationId: string): Promise<void> {
    await this.trx.updateTable('sessions').set({ organizationId }).where('id', '=', sessionId).where('userId', '=', this.userId).execute();
  }
  async getOrganization(id: string): Promise<OrganizationRecord | null> {
    return (await this.trx.selectFrom('organizations').select(['id', 'name', 'status', 'createdAt']).where('id', '=', id).executeTakeFirst()) ?? null;
  }
  async appendAudit(e: AuditEntry): Promise<void> {
    await this.trx.insertInto('auditLogs').values({
      id: uuidv7(), organizationId: e.organizationId, actorType: e.actorType, actorUserId: e.actorUserId, actorSessionId: e.actorSessionId, action: e.action,
      resourceType: e.resourceType ?? null, resourceId: e.resourceId ?? null, outcome: e.outcome, requestId: e.requestId ?? null, ipHash: e.ipHash ?? null,
      metadata: JSON.stringify(sanitizeAuditMetadata(e.metadata ?? {})),
    }).execute();
  }
  async appendOutbox(e: OutboxEventInput): Promise<void> {
    await this.trx.insertInto('outboxEvents').values({ id: uuidv7(), organizationId: e.organizationId, aggregateType: e.aggregateType, aggregateId: e.aggregateId, eventType: e.eventType, payload: JSON.stringify(e.payload), lastError: null, publishedAt: null }).execute();
  }
  async listAuditLogs(q: { limit: number; before: Date | null }): Promise<AuditLogView[]> {
    let query = this.trx.selectFrom('auditLogs').select(['id', 'action', 'outcome', 'actorUserId', 'resourceType', 'resourceId', 'occurredAt']).orderBy('occurredAt', 'desc').limit(q.limit);
    if (q.before) query = query.where('occurredAt', '<', q.before);
    return query.execute(); // tenant filter is applied by RLS, not by a WHERE clause the app could forget
  }
}
