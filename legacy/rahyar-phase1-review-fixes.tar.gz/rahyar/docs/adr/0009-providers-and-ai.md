# ADR-0009 Provider-independent infrastructure & AI

Status: Accepted

Docker + PostgreSQL + Redis + S3-compatible behind interfaces. AI will go through AI Gateway → Provider Adapter → Model with no DB credentials; config validated now (AI_PROVIDER=none), no AI code in Phase 1.
