CREATE TABLE roles (
  id              uuid PRIMARY KEY,
  organization_id uuid NOT NULL REFERENCES organizations (id),
  key             text NOT NULL CHECK (key ~ '^[a-z][a-z0-9_]{1,40}$'),
  name            text NOT NULL,
  permissions     text[] NOT NULL DEFAULT '{}',
  is_system       boolean NOT NULL DEFAULT false,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  version         integer NOT NULL DEFAULT 1,
  UNIQUE (organization_id, key),
  UNIQUE (organization_id, id)
);

CREATE TABLE organization_memberships (
  id              uuid PRIMARY KEY,
  organization_id uuid NOT NULL REFERENCES organizations (id),
  user_id         uuid NOT NULL REFERENCES users (id),
  role_id         uuid NOT NULL,
  status          text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'invited', 'suspended', 'removed')),
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  version         integer NOT NULL DEFAULT 1,
  UNIQUE (organization_id, user_id),
  -- Composite FK: a membership can only reference a role of the SAME organization.
  FOREIGN KEY (organization_id, role_id) REFERENCES roles (organization_id, id)
);
CREATE INDEX organization_memberships_user_idx ON organization_memberships (user_id);

CREATE TRIGGER roles_touch BEFORE UPDATE ON roles
  FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();
CREATE TRIGGER organization_memberships_touch BEFORE UPDATE ON organization_memberships
  FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

ALTER TABLE roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE roles FORCE ROW LEVEL SECURITY;
CREATE POLICY roles_select ON roles FOR SELECT TO rahyar_app USING (organization_id = app.current_org_id());
CREATE POLICY roles_insert ON roles FOR INSERT TO rahyar_app WITH CHECK (organization_id = app.current_org_id());
CREATE POLICY roles_update ON roles FOR UPDATE TO rahyar_app
  USING (organization_id = app.current_org_id()) WITH CHECK (organization_id = app.current_org_id());

ALTER TABLE organization_memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE organization_memberships FORCE ROW LEVEL SECURITY;
-- Org-bound context: only that organization's rows. NO org context: only the user's OWN memberships
-- (org switcher / login). A user who belongs to several orgs therefore never sees sibling orgs while
-- operating inside one tenant.
CREATE POLICY memberships_select ON organization_memberships FOR SELECT TO rahyar_app
  USING (
    organization_id = app.current_org_id()
    OR (app.current_org_id() IS NULL AND user_id = app.current_user_id())
  );
CREATE POLICY memberships_insert ON organization_memberships FOR INSERT TO rahyar_app
  WITH CHECK (organization_id = app.current_org_id());
CREATE POLICY memberships_update ON organization_memberships FOR UPDATE TO rahyar_app
  USING (organization_id = app.current_org_id()) WITH CHECK (organization_id = app.current_org_id());

-- Members can list the organizations they belong to ONLY when no organization context is bound
-- (non-recursive: the memberships policy does not reference organizations).
CREATE POLICY organizations_select ON organizations FOR SELECT TO rahyar_app
  USING (
    id = app.current_org_id()
    OR (
      app.current_org_id() IS NULL
      AND id IN (
        SELECT organization_id FROM organization_memberships
        WHERE user_id = app.current_user_id() AND status = 'active'
      )
    )
  );

GRANT SELECT, INSERT, UPDATE ON roles, organization_memberships TO rahyar_app;
