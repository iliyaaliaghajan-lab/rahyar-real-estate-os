# ADR-0006 Default-deny authorization

Status: Accepted

Closed action registry; unknown actions denied; rules may only restrict; risk/step-up/confirmation are policy outcomes.
