// In-memory implementations of the application ports, used for unit tests of the services.
// They model transaction rollback (state restored when the callback throws) and the DB-level
// atomic single-use semantics (consumeChallenge / markRefreshUsed).
import { AppError } from '@rahyar/domain-kernel';
import type { AuditEntry } from '../../src/modules/audit/audit.types.ts';
import type {
  AuthTx,
  AuthUnitOfWork,
  ChallengeRecord,
  DeviceRecord,
  OtpSender,
  SessionRecord,
  SessionWithContext,
  UserRecord,
} from '../../src/modules/identity/application/ports.ts';
import type { RefreshRecord } from '../../src/modules/identity/domain/refresh.ts';
import type {
  AuditLogView,
  BootstrapTx,
  IdempotencyClaim,
  OrganizationRecord,
  OutboxEventInput,
  TenantTx,
  TenantUnitOfWork,
} from '../../src/modules/organization/application/ports.ts';

type Dev = DeviceRecord & { fingerprintHash: string; label: string | null; platform: 'web' | 'ios' | 'android' | 'desktop' | 'unknown'; lastSeenAt: Date; trustedAt: Date | null };
type Ses = SessionRecord & { accessTokenHash: string; revokedReason: string | null; createdAt: Date };
type Ref = RefreshRecord & { userId: string; tokenHash: string };
type Chal = ChallengeRecord & { createdAt: Date; ipHash: string | null };
type Role = { id: string; organizationId: string; key: string; permissions: readonly string[] };
type Mem = { id: string; organizationId: string; userId: string; roleId: string; status: 'active' };
type Audit = AuditEntry & { id: string; occurredAt: Date };
type Idem = { userId: string; key: string; requestHash: string; status: number | null; body: unknown };

export class MemoryDb {
  users = new Map<string, UserRecord & { phoneVerifiedAt: Date | null }>();
  challenges = new Map<string, Chal>();
  devices = new Map<string, Dev>();
  sessions = new Map<string, Ses>();
  refresh = new Map<string, Ref>();
  orgs = new Map<string, OrganizationRecord>();
  roles = new Map<string, Role>();
  memberships = new Map<string, Mem>();
  audit: Audit[] = [];
  outbox: OutboxEventInput[] = [];
  idem = new Map<string, Idem>();
  private snapshot() {
    return {
      users: new Map(this.users), challenges: new Map(this.challenges), devices: new Map(this.devices), sessions: new Map(this.sessions),
      refresh: new Map(this.refresh), orgs: new Map(this.orgs), roles: new Map(this.roles), memberships: new Map(this.memberships),
      audit: [...this.audit], outbox: [...this.outbox], idem: new Map(this.idem),
    };
  }
  private restore(s: ReturnType<MemoryDb['snapshot']>) { Object.assign(this, s); }
  async transaction<T>(fn: () => Promise<T>): Promise<T> {
    const snap = this.snapshot();
    try { return await fn(); } catch (e) { this.restore(snap); throw e; }
  }
}

let seq = 0;
const nextId = (): string => `00000000-0000-7000-8000-${String(++seq).padStart(12, '0')}`;

export class MemoryAuthUow implements AuthUnitOfWork {
  readonly db: MemoryDb;
  constructor(db: MemoryDb) { this.db = db; }
  run<T>(fn: (tx: AuthTx) => Promise<T>): Promise<T> { return this.db.transaction(() => fn(new MemoryAuthTx(this.db))); }
  /** NOTE: the fake cannot enforce RLS; user confinement of runAsUser is proven only by the PostgreSQL integration suite. */
  runAsUser<T>(_userId: string, fn: (tx: AuthTx) => Promise<T>): Promise<T> { return this.run(fn); }
}

class MemoryAuthTx implements AuthTx {
  private readonly db: MemoryDb;
  constructor(db: MemoryDb) { this.db = db; }
  async recentChallengeTimes(by: { phoneE164: string } | { ipHash: string }, since: Date) {
    return [...this.db.challenges.values()]
      .filter((c) => c.createdAt >= since && ('phoneE164' in by ? c.phoneE164 === by.phoneE164 : c.ipHash === by.ipHash))
      .map((c) => c.createdAt);
  }
  async insertChallenge(c: Parameters<AuthTx['insertChallenge']>[0]) {
    this.db.challenges.set(c.id, { id: c.id, phoneE164: c.phoneE164, purpose: c.purpose, codeHash: c.codeHash, attempts: 0, maxAttempts: c.maxAttempts, expiresAt: c.expiresAt, consumedAt: null, lockedAt: null, createdAt: c.createdAt, ipHash: c.ipHash });
  }
  async invalidateOpenChallenges(phone: string, purpose: 'login' | 'step_up', now: Date) {
    for (const [k, c] of this.db.challenges) if (c.phoneE164 === phone && c.purpose === purpose && !c.consumedAt) this.db.challenges.set(k, { ...c, consumedAt: now });
  }
  async getChallengeForUpdate(id: string) { return this.db.challenges.get(id) ?? null; }
  async updateChallengeAttempts(id: string, attempts: number, lockedAt: Date | null) {
    const c = this.db.challenges.get(id); if (c) this.db.challenges.set(id, { ...c, attempts, lockedAt });
  }
  async consumeChallenge(id: string, now: Date) {
    const c = this.db.challenges.get(id); if (!c || c.consumedAt) return false;
    this.db.challenges.set(id, { ...c, consumedAt: now }); return true;
  }
  async expireChallenge(id: string, now: Date) {
    const c = this.db.challenges.get(id); if (c) this.db.challenges.set(id, { ...c, expiresAt: now, consumedAt: now });
  }
  async findUserByPhone(phone: string) { return [...this.db.users.values()].find((u) => u.phoneE164 === phone) ?? null; }
  async createUser(u: { id: string; phoneE164: string; now: Date }) {
    const rec = { id: u.id, phoneE164: u.phoneE164, status: 'active' as const, displayName: null, phoneVerifiedAt: u.now };
    this.db.users.set(u.id, rec); return rec;
  }
  async markLogin() { /* no-op */ }
  async upsertDevice(d: Parameters<AuthTx['upsertDevice']>[0]) {
    const ex = [...this.db.devices.values()].find((x) => x.userId === d.userId && x.fingerprintHash === d.fingerprintHash);
    if (ex) { this.db.devices.set(ex.id, { ...ex, lastSeenAt: d.now }); return ex; }
    const rec: Dev = { id: d.id, userId: d.userId, revokedAt: null, fingerprintHash: d.fingerprintHash, label: d.label, platform: d.platform, lastSeenAt: d.now, trustedAt: null };
    this.db.devices.set(d.id, rec); return rec;
  }
  async listActiveOrganizationIds(userId: string) {
    return [...this.db.memberships.values()].filter((m) => m.userId === userId && m.status === 'active').map((m) => m.organizationId);
  }
  async createSession(s: Parameters<AuthTx['createSession']>[0]) {
    this.db.sessions.set(s.id, { id: s.id, userId: s.userId, deviceId: s.deviceId, organizationId: s.organizationId, accessExpiresAt: s.accessExpiresAt, absoluteExpiresAt: s.absoluteExpiresAt, stepUpAt: null, lastSeenAt: s.now, revokedAt: null, accessTokenHash: s.accessTokenHash, revokedReason: null, createdAt: s.now });
  }
  async insertRefreshToken(r: Parameters<AuthTx['insertRefreshToken']>[0]) {
    this.db.refresh.set(r.id, { id: r.id, sessionId: r.sessionId, userId: r.userId, tokenHash: r.tokenHash, generation: r.generation, expiresAt: r.expiresAt, usedAt: null, revokedAt: null });
  }
  private ctx(s: Ses): SessionWithContext {
    const u = this.db.users.get(s.userId); const d = this.db.devices.get(s.deviceId);
    return { ...s, userStatus: u?.status ?? 'disabled', deviceRevokedAt: d?.revokedAt ?? null };
  }
  async findSessionByAccessHash(hash: string) {
    const s = [...this.db.sessions.values()].find((x) => x.accessTokenHash === hash); return s ? this.ctx(s) : null;
  }
  async touchSession(id: string, now: Date) { const s = this.db.sessions.get(id); if (s) this.db.sessions.set(id, { ...s, lastSeenAt: now }); }
  async loadPermissions(userId: string, organizationId: string) {
    const m = [...this.db.memberships.values()].find((x) => x.userId === userId && x.organizationId === organizationId && x.status === 'active');
    if (!m) return null; return [...(this.db.roles.get(m.roleId)?.permissions ?? [])];
  }
  async getRefreshForUpdate(tokenHash: string) {
    const r = [...this.db.refresh.values()].find((x) => x.tokenHash === tokenHash); if (!r) return null;
    const s = this.db.sessions.get(r.sessionId); if (!s) return null;
    return { record: r, session: this.ctx(s) };
  }
  async markRefreshUsed(id: string, now: Date) { const r = this.db.refresh.get(id); if (!r || r.usedAt) return false; this.db.refresh.set(id, { ...r, usedAt: now }); return true; }
  async rotateAccess(sessionId: string, hash: string, exp: Date, now: Date) {
    const s = this.db.sessions.get(sessionId); if (s) this.db.sessions.set(sessionId, { ...s, accessTokenHash: hash, accessExpiresAt: exp, lastSeenAt: now });
  }
  async setSessionOrganization(sessionId: string, organizationId: string) { const s = this.db.sessions.get(sessionId); if (s) this.db.sessions.set(sessionId, { ...s, organizationId }); }
  async revokeSession(id: string, reason: string, now: Date) {
    const s = this.db.sessions.get(id); if (s && !s.revokedAt) this.db.sessions.set(id, { ...s, revokedAt: now, revokedReason: reason });
    for (const [k, r] of this.db.refresh) if (r.sessionId === id && !r.revokedAt) this.db.refresh.set(k, { ...r, revokedAt: now });
  }
  async revokeDevice(userId: string, deviceId: string, now: Date) {
    const d = this.db.devices.get(deviceId); if (!d || d.userId !== userId) return false;
    this.db.devices.set(deviceId, { ...d, revokedAt: d.revokedAt ?? now });
    for (const s of [...this.db.sessions.values()]) if (s.deviceId === deviceId) await this.revokeSession(s.id, 'device_revoked', now);
    return true;
  }
  async getSession(id: string) { return this.db.sessions.get(id) ?? null; }
  async listSessions(userId: string) {
    return [...this.db.sessions.values()].filter((s) => s.userId === userId && !s.revokedAt).map((s) => {
      const d = this.db.devices.get(s.deviceId);
      return { id: s.id, deviceId: s.deviceId, deviceLabel: d?.label ?? null, platform: d?.platform ?? 'unknown', organizationId: s.organizationId, createdAt: s.createdAt, lastSeenAt: s.lastSeenAt };
    });
  }
  async listDevices(userId: string) {
    return [...this.db.devices.values()].filter((d) => d.userId === userId).map((d) => ({ id: d.id, label: d.label, platform: d.platform, trustedAt: d.trustedAt, revokedAt: d.revokedAt, lastSeenAt: d.lastSeenAt }));
  }
  async appendAudit(e: AuditEntry) { this.db.audit.push({ ...e, id: nextId(), occurredAt: new Date() }); }
}

/** Tenant UoW fake that also enforces "tenant context" for audit listing like RLS would. */
export class MemoryTenantUow implements TenantUnitOfWork {
  readonly db: MemoryDb;
  constructor(db: MemoryDb) { this.db = db; }
  run<T>(ctx: { userId: string; organizationId: string | null; sessionId: string }, fn: (tx: TenantTx) => Promise<T>): Promise<T> {
    if (ctx.organizationId !== null) {
      const member = [...this.db.memberships.values()].some((m) => m.userId === ctx.userId && m.organizationId === ctx.organizationId && m.status === 'active');
      if (!member) return Promise.reject(new AppError('forbidden', 'TENANT_ACCESS_DENIED', 'Not a member of this organization.'));
    }
    return this.db.transaction(() => fn(new MemoryTenantTx(this.db, ctx)));
  }
  bootstrap<T>(ctx: { userId: string; sessionId: string; newOrganizationId: string }, fn: (tx: BootstrapTx) => Promise<T>): Promise<T> {
    return this.db.transaction(() => {
      const t = new MemoryTenantTx(this.db, { userId: ctx.userId, organizationId: ctx.newOrganizationId, sessionId: ctx.sessionId });
      return fn({
        claimIdempotency: (k) => t.claimIdempotency(k),
        completeIdempotency: (k, s, b) => t.completeIdempotency(k, s, b),
        insertOrganization: (o) => t.insertOrganization(o),
        insertRole: (r) => t.insertRole(r),
        insertMembership: (m) => t.insertMembership(m),
        setSessionOrganization: (sid, oid) => t.setSessionOrganization(sid, oid),
        appendAudit: (e) => t.appendAudit(e),
        appendOutbox: (e) => t.appendOutbox(e),
      });
    });
  }
}
class MemoryTenantTx implements TenantTx {
  private readonly db: MemoryDb;
  private readonly ctx: { userId: string; organizationId: string | null; sessionId: string };
  constructor(db: MemoryDb, ctx: { userId: string; organizationId: string | null; sessionId: string }) { this.db = db; this.ctx = ctx; }
  async claimIdempotency(k: Parameters<TenantTx['claimIdempotency']>[0]): Promise<IdempotencyClaim> {
    const id = `${this.ctx.userId}:${k.key}`; const ex = this.db.idem.get(id);
    if (!ex) { this.db.idem.set(id, { userId: this.ctx.userId, key: k.key, requestHash: k.requestHash, status: null, body: null }); return { state: 'claimed' }; }
    if (ex.requestHash !== k.requestHash) return { state: 'mismatch' };
    return { state: 'replay', responseStatus: ex.status ?? 0, responseBody: ex.body };
  }
  async completeIdempotency(key: string, status: number, body: unknown) { const id = `${this.ctx.userId}:${key}`; const ex = this.db.idem.get(id); if (ex) this.db.idem.set(id, { ...ex, status, body }); }
  private requireCtxOrg(orgId: string) { if (orgId !== this.ctx.organizationId) throw new Error('RLS: row violates tenant policy'); }
  async insertOrganization(o: { id: string; name: string }) { this.requireCtxOrg(o.id); if (this.db.orgs.has(o.id)) throw new Error('PK violation: organization exists'); this.db.orgs.set(o.id, { id: o.id, name: o.name, status: 'active', createdAt: new Date() }); }
  async insertRole(r: Parameters<TenantTx['insertRole']>[0]) { this.requireCtxOrg(r.organizationId); this.db.roles.set(r.id, { id: r.id, organizationId: r.organizationId, key: r.key, permissions: r.permissions }); }
  async insertMembership(m: Parameters<TenantTx['insertMembership']>[0]) {
    this.requireCtxOrg(m.organizationId);
    if (this.db.roles.get(m.roleId)?.organizationId !== m.organizationId) throw new Error('FK: role belongs to another organization');
    this.db.memberships.set(m.id, { ...m, status: 'active' });
  }
  async setSessionOrganization(sessionId: string, organizationId: string) { const s = this.db.sessions.get(sessionId); if (s) this.db.sessions.set(sessionId, { ...s, organizationId }); }
  async getOrganization(id: string) { return id === this.ctx.organizationId ? (this.db.orgs.get(id) ?? null) : null; }
  async appendAudit(e: AuditEntry) { if (e.organizationId !== null) this.requireCtxOrg(e.organizationId); this.db.audit.push({ ...e, id: nextId(), occurredAt: new Date() }); }
  async appendOutbox(e: OutboxEventInput) { if (e.organizationId !== null) this.requireCtxOrg(e.organizationId); this.db.outbox.push(e); }
  async listAuditLogs(q: { limit: number; before: Date | null }): Promise<AuditLogView[]> {
    return this.db.audit
      .filter((a) => a.organizationId === this.ctx.organizationId && (!q.before || a.occurredAt < q.before))
      .slice(-q.limit).reverse()
      .map((a) => ({ id: a.id, action: a.action, outcome: a.outcome, actorUserId: a.actorUserId, resourceType: a.resourceType ?? null, resourceId: a.resourceId ?? null, occurredAt: a.occurredAt }));
  }
}

export class CapturingOtpSender implements OtpSender {
  readonly sent: { phoneE164: string; code: string }[] = [];
  failNext = false;
  async send(a: { phoneE164: string; code: string }) {
    if (this.failNext) { this.failNext = false; throw new Error('provider down'); }
    this.sent.push({ phoneE164: a.phoneE164, code: a.code });
  }
  get last() { return this.sent[this.sent.length - 1]; }
}

export class FakeClock {
  private t: number;
  constructor(iso = '2026-10-02T10:00:00Z') { this.t = new Date(iso).getTime(); }
  now(): Date { return new Date(this.t); }
  advance(seconds: number): void { this.t += seconds * 1000; }
}
