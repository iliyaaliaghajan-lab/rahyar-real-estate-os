# ADR-0010 BFF for web auth

Status: Accepted

The Next.js server holds tokens in httpOnly SameSite=Strict cookies; browser scripts never see them.
