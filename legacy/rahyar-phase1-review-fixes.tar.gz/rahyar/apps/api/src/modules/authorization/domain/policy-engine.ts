import { AppError } from '@rahyar/domain-kernel';
import { ACTIONS, isKnownAction, type ActionDescriptor, type RiskLevel } from './actions.ts';

/** Established server-side from a verified session — NEVER from request headers/body. */
export type Principal = {
  readonly userId: string;
  readonly sessionId: string;
  readonly organizationId: string | null;
  readonly permissions: ReadonlySet<string>;
  readonly stepUpAt: Date | null;
};

export type ResourceRef = {
  readonly type?: string;
  readonly id?: string;
  /** Organization that owns the targeted resource (loaded from storage, not from the request). */
  readonly organizationId?: string | null;
  readonly ownerUserId?: string;
};

export type PolicyRequest = {
  readonly principal: Principal | null;
  readonly action: string;
  readonly resource?: ResourceRef;
  readonly confirmed?: boolean;
  readonly now: Date;
};

export type DenyReason =
  | 'UNAUTHENTICATED'
  | 'UNKNOWN_ACTION'
  | 'NO_ACTIVE_ORGANIZATION'
  | 'TENANT_MISMATCH'
  | 'PERMISSION_MISSING'
  | 'OWNERSHIP_REQUIRED'
  | 'POLICY_RULE_DENIED';

export type Decision =
  | { readonly effect: 'allow'; readonly risk: RiskLevel }
  | { readonly effect: 'deny'; readonly reason: DenyReason }
  | { readonly effect: 'step_up_required'; readonly risk: RiskLevel }
  | { readonly effect: 'confirmation_required'; readonly risk: RiskLevel };

/** Extension point for tenant policies / plugins / risk engines. A rule may only restrict, never grant. */
export type PolicyRule = (req: PolicyRequest, descriptor: ActionDescriptor) => Decision | null;

export interface PolicyEngine {
  decide(req: PolicyRequest): Decision;
}

export class DefaultDenyPolicyEngine implements PolicyEngine {
  private readonly rules: readonly PolicyRule[];
  private readonly stepUpMaxAgeSeconds: number;

  constructor(opts: { rules?: readonly PolicyRule[]; stepUpMaxAgeSeconds?: number } = {}) {
    this.rules = opts.rules ?? [];
    this.stepUpMaxAgeSeconds = opts.stepUpMaxAgeSeconds ?? 300;
  }

  decide(req: PolicyRequest): Decision {
    const { principal, resource } = req;
    if (!principal) return { effect: 'deny', reason: 'UNAUTHENTICATED' };
    if (!isKnownAction(req.action)) return { effect: 'deny', reason: 'UNKNOWN_ACTION' };
    const d: ActionDescriptor = ACTIONS[req.action];

    if (d.tenantScoped) {
      if (!principal.organizationId) return { effect: 'deny', reason: 'NO_ACTIVE_ORGANIZATION' };
      // A resource carrying a different tenant than the session's tenant is always a violation.
      if (resource?.organizationId !== undefined && resource.organizationId !== principal.organizationId) {
        return { effect: 'deny', reason: 'TENANT_MISMATCH' };
      }
    }
    if (d.permission !== null && !principal.permissions.has(d.permission)) {
      return { effect: 'deny', reason: 'PERMISSION_MISSING' };
    }
    if (d.ownerOnly && resource?.ownerUserId !== principal.userId) {
      return { effect: 'deny', reason: 'OWNERSHIP_REQUIRED' };
    }
    for (const rule of this.rules) {
      const r = rule(req, d);
      if (r && r.effect !== 'allow') return r; // rules can restrict only
    }
    if (d.requiresStepUp) {
      const fresh =
        principal.stepUpAt !== null && req.now.getTime() - principal.stepUpAt.getTime() <= this.stepUpMaxAgeSeconds * 1000;
      if (!fresh) return { effect: 'step_up_required', risk: d.risk };
    }
    if (d.requiresConfirmation && req.confirmed !== true) return { effect: 'confirmation_required', risk: d.risk };
    return { effect: 'allow', risk: d.risk };
  }
}

/** Throws a framework-neutral AppError unless the decision is `allow`. Call this at the service boundary. */
export function enforce(decision: Decision): asserts decision is Extract<Decision, { effect: 'allow' }> {
  switch (decision.effect) {
    case 'allow':
      return;
    case 'deny':
      // UNAUTHENTICATED → 401; everything else → 403. Reason is machine-readable but non-revealing.
      if (decision.reason === 'UNAUTHENTICATED') throw new AppError('unauthenticated', 'UNAUTHENTICATED', 'Authentication required.');
      throw new AppError('forbidden', 'FORBIDDEN', 'You are not allowed to perform this action.', { reason: decision.reason });
    case 'step_up_required':
      throw new AppError('forbidden', 'STEP_UP_REQUIRED', 'Additional verification is required.');
    case 'confirmation_required':
      throw new AppError('forbidden', 'CONFIRMATION_REQUIRED', 'Explicit confirmation is required.');
  }
}
