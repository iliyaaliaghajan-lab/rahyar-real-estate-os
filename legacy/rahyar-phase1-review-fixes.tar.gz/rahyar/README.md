# RAHYAR

AI-native, offline-first real-estate operating system for Iranian professionals. **Proprietary / private.**

Phase 1 (Foundation) contains: monorepo, Phone-OTP identity (sessions, devices, refresh rotation + reuse detection),
organizations/roles/memberships, PostgreSQL RLS tenant isolation, default-deny PolicyEngine, append-only audit,
idempotency + outbox foundations, NestJS API shell, Next.js RTL/Persian shell. No Property/CRM/Matching/AI features yet.

## Layout
```
apps/api      NestJS (Fastify) modular monolith, Kysely, SQL migrations (apps/api/db/migrations)
apps/web      Next.js PWA shell; BFF routes keep tokens in httpOnly cookies
packages/     domain-kernel (pure), contracts (zod wire schemas)
infra/        Dockerfile (PostGIS+pgvector), DB init (roles/extensions)
docs/         architecture, tenancy, security, testing, ADRs
```

## Status
Phase 1 code is written. **Not yet verified end-to-end**: no `pnpm-lock.yaml`, lint/full typecheck/build and the PostgreSQL integration
suite have never been run (the authoring sandbox had no registry, Docker or PostgreSQL). See `docs/setup.md` for exact steps and
`docs/testing.md` for what each suite proves.

## Quick start
See **docs/setup.md** (pnpm, lockfile generation, Docker, database, migrations, tests), **docs/environments.md**,
**docs/database-roles.md**, **docs/tenancy.md**, **docs/security.md**.
