# ADR-0001 Modular monolith

Status: Accepted

Single deployable with enforced context boundaries (ports + lint rules). Services are extracted only on proven need.
