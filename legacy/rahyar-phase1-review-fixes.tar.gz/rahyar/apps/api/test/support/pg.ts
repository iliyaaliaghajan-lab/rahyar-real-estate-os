import pg from 'pg';

export const MIGRATOR_URL = process.env['TEST_DATABASE_MIGRATOR_URL'];
export const APP_URL = process.env['TEST_DATABASE_URL'];
export const SKIP: string | false =
  MIGRATOR_URL && APP_URL ? false : 'NOT EXECUTED — REQUIRES EXTERNAL INFRASTRUCTURE (PostgreSQL: set TEST_DATABASE_MIGRATOR_URL and TEST_DATABASE_URL)';

/** Runs fn in a transaction on the APP role with the given request context (mirrors production set_config usage). */
export async function asApp<T>(
  pool: pg.Pool,
  ctx: { scope?: 'auth'; userId?: string; orgId?: string },
  fn: (c: pg.PoolClient) => Promise<T>,
): Promise<T> {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    if (ctx.scope) await c.query("select set_config('app.scope', $1, true)", [ctx.scope]);
    if (ctx.userId) await c.query("select set_config('app.user_id', $1, true)", [ctx.userId]);
    if (ctx.orgId) await c.query("select set_config('app.org_id', $1, true)", [ctx.orgId]);
    const r = await fn(c);
    await c.query('COMMIT');
    return r;
  } catch (e) {
    await c.query('ROLLBACK').catch(() => undefined);
    throw e;
  } finally {
    c.release();
  }
}
