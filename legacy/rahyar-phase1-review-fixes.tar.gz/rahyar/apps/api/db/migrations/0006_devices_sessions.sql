-- Devices and sessions are user-scoped (a session may have no active organization yet).
CREATE TABLE devices (
  id               uuid PRIMARY KEY,
  user_id          uuid NOT NULL REFERENCES users (id),
  fingerprint_hash text NOT NULL,
  label            text CHECK (label IS NULL OR char_length(label) <= 120),
  platform         text NOT NULL DEFAULT 'unknown' CHECK (platform IN ('web', 'ios', 'android', 'desktop', 'unknown')),
  trusted_at       timestamptz,
  revoked_at       timestamptz,
  first_seen_at    timestamptz NOT NULL DEFAULT now(),
  last_seen_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, fingerprint_hash)
);

CREATE TABLE sessions (
  id                  uuid PRIMARY KEY,
  user_id             uuid NOT NULL REFERENCES users (id),
  device_id           uuid NOT NULL REFERENCES devices (id),
  organization_id     uuid REFERENCES organizations (id),
  auth_method         text NOT NULL DEFAULT 'phone_otp',
  access_token_hash   text NOT NULL UNIQUE,
  access_expires_at   timestamptz NOT NULL,
  absolute_expires_at timestamptz NOT NULL,
  step_up_at          timestamptz,
  created_at          timestamptz NOT NULL DEFAULT now(),
  last_seen_at        timestamptz NOT NULL DEFAULT now(),
  revoked_at          timestamptz,
  revoked_reason      text
);
CREATE INDEX sessions_user_idx ON sessions (user_id);
CREATE INDEX sessions_device_idx ON sessions (device_id);

CREATE TABLE refresh_tokens (
  id         uuid PRIMARY KEY,
  session_id uuid NOT NULL REFERENCES sessions (id) ON DELETE CASCADE,
  user_id    uuid NOT NULL REFERENCES users (id),
  token_hash text NOT NULL UNIQUE,
  generation integer NOT NULL CHECK (generation >= 1),
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  used_at    timestamptz,
  revoked_at timestamptz,
  UNIQUE (session_id, generation)
);

ALTER TABLE devices ENABLE ROW LEVEL SECURITY;
ALTER TABLE devices FORCE ROW LEVEL SECURITY;
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE sessions FORCE ROW LEVEL SECURITY;
ALTER TABLE refresh_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE refresh_tokens FORCE ROW LEVEL SECURITY;

CREATE POLICY devices_all ON devices FOR ALL TO rahyar_app
  USING (user_id = app.current_user_id() OR app.is_auth_scope())
  WITH CHECK (user_id = app.current_user_id() OR app.is_auth_scope());
CREATE POLICY sessions_all ON sessions FOR ALL TO rahyar_app
  USING (user_id = app.current_user_id() OR app.is_auth_scope())
  WITH CHECK (user_id = app.current_user_id() OR app.is_auth_scope());
CREATE POLICY refresh_tokens_all ON refresh_tokens FOR ALL TO rahyar_app
  USING (user_id = app.current_user_id() OR app.is_auth_scope())
  WITH CHECK (user_id = app.current_user_id() OR app.is_auth_scope());

GRANT SELECT, INSERT, UPDATE ON devices, sessions TO rahyar_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON refresh_tokens TO rahyar_app;
