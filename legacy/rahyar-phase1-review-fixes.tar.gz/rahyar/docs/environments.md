# Environments

`NODE_ENV` selects build mode; `APP_ENV` selects the deployment tier. **staging and production are both strict.**

| | development | test (CI/integration) | staging | production |
|---|---|---|---|---|
| `NODE_ENV` / `APP_ENV` | development / development | test / test | production / staging | production / production |
| OTP delivery | `console` allowed | `console` allowed | `provider` only | `provider` only |
| DB role in `DATABASE_URL` | `rahyar_app` | `rahyar_app` | `rahyar_app` (privileged names rejected) | same |
| `DATABASE_MIGRATOR_URL` in API env | allowed (shared `.env`) | allowed | **rejected** | **rejected** |
| `TRUST_PROXY` | optional | optional | **must be `true`** | **must be `true`** |
| `OTP_PEPPER` | ≥ 32 chars | ≥ 32 chars | ≥ 32 chars, no placeholders | same |
| Web `APP_ORIGIN` | optional (falls back to Host) | optional | **required** (CSRF origin check fails closed) | **required** |
| Cookies | httpOnly, SameSite=Strict | same | + `Secure` | + `Secure` |
| Database | `rahyar` | `rahyar_test` (disposable) | dedicated | dedicated |
| Secrets | `.env` (untracked) | CI env/secret store | secret manager | secret manager |

Rules enforced by `apps/api/src/platform/config/env.schema.ts` (validated at boot; values are never echoed) and by
`apps/web/src/lib/bff.ts`. `.env.example` documents every variable and a static test keeps it in sync with the schema.
The API must not be reachable from the public internet: only the web BFF/edge may call it, and the edge must overwrite
`X-Forwarded-For` (per-client OTP/IP rate limits depend on it).
