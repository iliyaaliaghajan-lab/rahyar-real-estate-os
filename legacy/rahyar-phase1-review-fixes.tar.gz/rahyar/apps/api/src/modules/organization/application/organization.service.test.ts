import { test } from 'node:test';
import assert from 'node:assert/strict';
import { AppError } from '@rahyar/domain-kernel';
import { DefaultDenyPolicyEngine } from '../../authorization/domain/policy-engine.ts';
import { AuthService } from '../../identity/application/auth.service.ts';
import { CapturingOtpSender, FakeClock, MemoryAuthUow, MemoryDb, MemoryTenantUow } from '../../../../test/support/in-memory.ts';
import { normalizeOrganizationName, OrganizationService } from './organization.service.ts';

function setup() {
  const db = new MemoryDb();
  const sender = new CapturingOtpSender();
  const clock = new FakeClock();
  const policy = new DefaultDenyPolicyEngine();
  const auth = new AuthService({ uow: new MemoryAuthUow(db), sender, clock, policy, config: { pepper: 'y'.repeat(48) } });
  const orgs = new OrganizationService({ uow: new MemoryTenantUow(db), clock, policy });
  const principalFor = async (phone: string, deviceId: string) => {
    const r = await auth.requestOtp({ phone });
    const s = await auth.verifyOtp({ challengeId: r.challengeId, code: sender.last?.code ?? '', device: { deviceId } });
    clock.advance(61);
    return { session: s, principal: await auth.authenticate(s.accessToken) };
  };
  return { db, auth, orgs, clock, principalFor };
}
const rejects = (p: Promise<unknown>, code: string, kind?: string) =>
  assert.rejects(p, (e: unknown) => e instanceof AppError && e.code === code && (kind === undefined || e.kind === kind));

test('create organization: seeds roles, owner membership, session org, audit and outbox atomically', async () => {
  const { db, auth, orgs, principalFor } = setup();
  const { session, principal } = await principalFor('09120000001', 'device-aaaaaaaaaaaaaaaa');
  const res = await orgs.createOrganization(principal, { name: ' \u0634\u0631\u0643\u062a   \u0631\u0627\u0647\u064a\u0627\u0631 ', idempotencyKey: 'key-0000000001' }, { requestId: 'r1' });
  assert.equal(res.name, 'شرکت راهیار'); // Arabic kaf/yeh normalized, spaces collapsed
  assert.equal(db.orgs.size, 1);
  const roles = [...db.roles.values()].filter((r) => r.organizationId === res.organizationId);
  assert.deepEqual(roles.map((r) => r.key).sort(), ['admin', 'agent', 'owner', 'viewer']);
  assert.equal(db.memberships.size, 1);
  assert.ok(db.audit.some((a) => a.action === 'organization.create' && a.organizationId === res.organizationId && a.requestId === 'r1'));
  assert.equal(db.outbox.length, 1);
  assert.equal(db.outbox[0]?.eventType, 'organization.created');
  // The existing session now operates inside the new tenant with owner permissions.
  const p2 = await auth.authenticate(session.accessToken);
  assert.equal(p2.organizationId, res.organizationId);
  assert.ok(p2.permissions.has('audit:read') && p2.permissions.has('organization:update'));
  const logs = await orgs.listAuditLogs(p2);
  assert.ok(logs.some((l) => l.action === 'organization.create'));
});

test('idempotency: same key+body replays the same organization; different body conflicts; no duplicates', async () => {
  const { db, orgs, principalFor } = setup();
  const { principal } = await principalFor('09120000001', 'device-aaaaaaaaaaaaaaaa');
  const a = await orgs.createOrganization(principal, { name: 'راهیار', idempotencyKey: 'key-0000000001' });
  const b = await orgs.createOrganization(principal, { name: 'راهیار', idempotencyKey: 'key-0000000001' });
  assert.equal(a.organizationId, b.organizationId);
  assert.equal(db.orgs.size, 1);
  assert.equal(db.outbox.length, 1);
  await rejects(orgs.createOrganization(principal, { name: 'دیگر', idempotencyKey: 'key-0000000001' }), 'IDEMPOTENCY_KEY_REUSED', 'conflict');
  assert.equal(db.orgs.size, 1);
  // A different key creates a second organization.
  await orgs.createOrganization(principal, { name: 'دیگر', idempotencyKey: 'key-0000000002' });
  assert.equal(db.orgs.size, 2);
});

test('validation: idempotency key required, name bounds, unauthenticated denied', async () => {
  const { orgs, principalFor } = setup();
  const { principal } = await principalFor('09120000001', 'device-aaaaaaaaaaaaaaaa');
  await rejects(orgs.createOrganization(principal, { name: 'راهیار', idempotencyKey: '' }), 'IDEMPOTENCY_KEY_REQUIRED', 'validation');
  await rejects(orgs.createOrganization(principal, { name: 'ا', idempotencyKey: 'key-0000000001' }), 'ORGANIZATION_NAME_INVALID', 'validation');
  await rejects(orgs.createOrganization(principal, { name: 'x'.repeat(121), idempotencyKey: 'key-0000000001' }), 'ORGANIZATION_NAME_INVALID');
  assert.equal(normalizeOrganizationName('a\u202eb\u0000c'), 'abc');
});

test('tenant isolation: users only ever see their own organization data and audit trail', async () => {
  const { db, auth, orgs, principalFor } = setup();
  const a = await principalFor('09120000001', 'device-aaaaaaaaaaaaaaaa');
  const b = await principalFor('09120000002', 'device-bbbbbbbbbbbbbbbb');
  const orgA = await orgs.createOrganization(a.principal, { name: 'الف الف', idempotencyKey: 'key-aaaaaaaaaa' });
  const orgB = await orgs.createOrganization(b.principal, { name: 'ب ب', idempotencyKey: 'key-bbbbbbbbbb' });
  const pa = await auth.authenticate(a.session.accessToken);
  const pb = await auth.authenticate(b.session.accessToken);
  assert.equal((await orgs.getCurrentOrganization(pa)).id, orgA.organizationId);
  assert.equal((await orgs.getCurrentOrganization(pb)).id, orgB.organizationId);
  const logsA = await orgs.listAuditLogs(pa);
  assert.ok(logsA.length > 0 && logsA.every((l) => !db.audit.some((x) => x.id === l.id && x.organizationId !== orgA.organizationId)));
  // Defense in depth: even if a session row were tampered to point at a foreign tenant,
  // authenticate() derives the organization from an ACTIVE MEMBERSHIP, so the org is dropped.
  const tampered = db.sessions.get(b.session.sessionId);
  assert.ok(tampered);
  db.sessions.set(tampered.id, { ...tampered, organizationId: orgA.organizationId });
  const pForeign = await auth.authenticate(b.session.accessToken);
  assert.equal(pForeign.organizationId, null);
  assert.equal(pForeign.permissions.size, 0);
  await rejects(orgs.getCurrentOrganization(pForeign), 'FORBIDDEN', 'forbidden');
  await rejects(auth.switchOrganization(pb, orgA.organizationId), 'ORGANIZATION_NOT_FOUND', 'not_found');
  await rejects(auth.switchOrganization(pb, '0192f0a0-0000-7000-8000-ffffffffffff'), 'ORGANIZATION_NOT_FOUND', 'not_found');
});

test('authorization: a member without audit:read is denied; policy resource tenant mismatch is denied', async () => {
  const { db, auth, orgs, principalFor } = setup();
  const a = await principalFor('09120000001', 'device-aaaaaaaaaaaaaaaa');
  const org = await orgs.createOrganization(a.principal, { name: 'راهیار', idempotencyKey: 'key-0000000001' });
  // Add a viewer member directly.
  const viewerRole = [...db.roles.values()].find((r) => r.organizationId === org.organizationId && r.key === 'viewer');
  const v = await principalFor('09120000003', 'device-cccccccccccccccc');
  db.memberships.set('m-viewer', { id: 'm-viewer', organizationId: org.organizationId, userId: v.principal.userId, roleId: viewerRole?.id ?? '', status: 'active' });
  await auth.switchOrganization(v.principal, org.organizationId);
  const pv = await auth.authenticate(v.session.accessToken);
  assert.deepEqual([...pv.permissions], ['organization:read']);
  await rejects(orgs.listAuditLogs(pv), 'FORBIDDEN', 'forbidden');
  assert.equal((await orgs.getCurrentOrganization(pv)).id, org.organizationId);
});

test('a revoked membership removes tenant access on the next request', async () => {
  const { db, auth, orgs, principalFor } = setup();
  const a = await principalFor('09120000001', 'device-aaaaaaaaaaaaaaaa');
  await orgs.createOrganization(a.principal, { name: 'راهیار', idempotencyKey: 'key-0000000001' });
  const [m] = [...db.memberships.values()];
  assert.ok(m);
  db.memberships.set(m.id, { ...m, status: 'active' });
  db.memberships.delete(m.id);
  const p = await auth.authenticate(a.session.accessToken);
  assert.equal(p.organizationId, null);
  await rejects(orgs.getCurrentOrganization(p), 'FORBIDDEN', 'forbidden');
});
