# ADR-0003 Phone-OTP authentication

Status: Accepted

Primary auth is phone→OTP→session→device. Email/password intentionally absent. The identity domain depends on ports (OtpSender, AuthTx) so new methods (passkeys, TOTP, SSO) are added as new flows without changing session/device/refresh logic.
