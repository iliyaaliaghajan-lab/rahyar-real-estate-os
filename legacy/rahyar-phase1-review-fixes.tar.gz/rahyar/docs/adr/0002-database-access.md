# ADR-0002 PostgreSQL + Kysely + SQL migrations

Status: Accepted

PostgreSQL is the source of truth. Kysely (typed query builder), forward-only checksummed SQL migrations; no Prisma. PostGIS/pgvector enabled in migrations. Kysely types stay in infrastructure.
