# Testing

| Suite | Command | Needs |
|---|---|---|
| Kernel/domain/service unit tests (node:test, in-memory ports) | `pnpm test` | Node only |
| Static SQL invariants (RLS enabled+forced, grant⇒policy, audit append-only, role safety) | `pnpm test` | Node only |
| Static HTTP surface (pinned `@Public` allowlist, global guard) | `pnpm test` | Node only |
| Tenant-isolation harness (in-memory) | `pnpm test` | Node only |
| PostgreSQL integration (migrations, RLS, audit, OTP, refresh reuse, tenancy harness on real DB) | `pnpm test:integration` | PostgreSQL+PostGIS+pgvector |
| Secret scan | `pnpm check:secrets` | Node only |

Both unit and integration layers are kept: in-memory fakes prove application logic fast; only real PostgreSQL proves RLS, FORCE RLS,
grants, triggers, FK behaviour, locking and concurrency. The in-memory fakes explicitly do **not** claim to prove those.

Additional static suites: `scripts/check-repo.mjs` (manifest/workspace/undeclared-import/CI-determinism checks) and
`apps/web/src/web-security.static.test.ts` (BFF cookie/CSRF/token-leak/bundle guards).

Integration tests **skip with an explicit "NOT EXECUTED" reason** when `TEST_DATABASE_*` is unset; they never pass vacuously.
The tenant harness (`test/support/tenant-harness.ts`) is shared by in-memory and real-DB suites. Later phases must add every new
tenant-owned endpoint to it.
