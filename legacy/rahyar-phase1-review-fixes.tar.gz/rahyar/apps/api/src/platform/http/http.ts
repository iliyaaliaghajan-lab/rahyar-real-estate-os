import { SetMetadata, createParamDecorator, type ExecutionContext } from '@nestjs/common';
import type { FastifyRequest } from 'fastify';
import type { ZodType } from 'zod';
import { AppError } from '@rahyar/domain-kernel';
import type { Principal } from '../../modules/authorization/domain/policy-engine.ts';

export const IS_PUBLIC = 'rahyar:isPublic';
/** Opt-OUT of the global authentication guard. Every use is reviewed by test/static (allowlist). */
export const Public = () => SetMetadata(IS_PUBLIC, true);

export type AuthedRequest = FastifyRequest & { principal?: Principal & { deviceId: string } };

export const CurrentPrincipal = createParamDecorator((_: unknown, ctx: ExecutionContext) => {
  const p = ctx.switchToHttp().getRequest<AuthedRequest>().principal;
  if (!p) throw new AppError('unauthenticated', 'UNAUTHENTICATED', 'Authentication required.');
  return p;
});

export const RequestMeta = createParamDecorator((_: unknown, ctx: ExecutionContext) => {
  const r = ctx.switchToHttp().getRequest<FastifyRequest>();
  return { ip: r.ip, requestId: r.id };
});

export function parseBody<T>(schema: ZodType<T>, body: unknown): T {
  const r = schema.safeParse(body);
  if (r.success) return r.data;
  // Report field paths only; never echo submitted values.
  throw new AppError('validation', 'VALIDATION_FAILED', 'Request validation failed.', { fields: r.error.issues.map((i) => i.path.join('.')) });
}
