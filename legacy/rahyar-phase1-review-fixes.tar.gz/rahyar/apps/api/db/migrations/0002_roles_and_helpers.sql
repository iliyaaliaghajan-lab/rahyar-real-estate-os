-- ROLE LIFECYCLE (see docs/database-roles.md)
--   * The application role `rahyar_app` is provisioned OUT-OF-BAND by an administrator (infra/db/provision.sh),
--     which sets LOGIN and the password from a secret. Migrations never contain credentials.
--   * If the role does not exist yet, this migration creates it NOLOGIN (unusable until provisioned).
--   * If it already exists, this migration REFUSES to continue unless it is unprivileged. Migrations never
--     alter the role's attributes, so a migration can never make the application role privileged.
DO $$
DECLARE
  r record;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'rahyar_app') THEN
    CREATE ROLE rahyar_app NOLOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE NOREPLICATION;
  END IF;
  SELECT rolsuper, rolbypassrls, rolcreaterole, rolcreatedb, rolreplication INTO r FROM pg_roles WHERE rolname = 'rahyar_app';
  IF r.rolsuper OR r.rolbypassrls OR r.rolcreaterole OR r.rolcreatedb OR r.rolreplication THEN
    RAISE EXCEPTION 'role rahyar_app has privileged attributes; it must be NOSUPERUSER NOBYPASSRLS NOCREATEROLE NOCREATEDB NOREPLICATION';
  END IF;
END
$$;

CREATE SCHEMA IF NOT EXISTS app;
GRANT USAGE ON SCHEMA app TO rahyar_app;
GRANT USAGE ON SCHEMA public TO rahyar_app;
REVOKE CREATE ON SCHEMA public FROM rahyar_app;
REVOKE CREATE ON SCHEMA app FROM rahyar_app;

-- Request context is transaction-scoped: set via set_config(name, value, true) by the DB layer only.
-- Malformed values raise (fail closed) instead of silently matching nothing/everything.
CREATE FUNCTION app.current_org_id() RETURNS uuid
  LANGUAGE sql STABLE
  AS $$ SELECT NULLIF(current_setting('app.org_id', true), '')::uuid $$;

CREATE FUNCTION app.current_user_id() RETURNS uuid
  LANGUAGE sql STABLE
  AS $$ SELECT NULLIF(current_setting('app.user_id', true), '')::uuid $$;

-- 'auth' scope is used only by the pre-authentication flows (OTP, token lookup, refresh).
CREATE FUNCTION app.is_auth_scope() RETURNS boolean
  LANGUAGE sql STABLE
  AS $$ SELECT COALESCE(current_setting('app.scope', true), '') = 'auth' $$;

CREATE FUNCTION app.touch_updated_at() RETURNS trigger
  LANGUAGE plpgsql
  AS $$
BEGIN
  NEW.updated_at = now();
  NEW.version = OLD.version + 1;
  RETURN NEW;
END
$$;

CREATE FUNCTION app.forbid_mutation() RETURNS trigger
  LANGUAGE plpgsql
  AS $$
BEGIN
  RAISE EXCEPTION 'table % is append-only (% blocked)', TG_TABLE_NAME, TG_OP
    USING ERRCODE = 'insufficient_privilege';
END
$$;

-- Single source of truth for "is this role safe to run the application as?". Used by the migration runner
-- (for rahyar_app) and by the API at startup (for current_user). Invoker rights; reads catalogs only.
CREATE FUNCTION app.assert_role_safe(role_name name) RETURNS void
  LANGUAGE plpgsql STABLE
  AS $$
DECLARE
  r record;
BEGIN
  SELECT oid, rolsuper, rolbypassrls, rolcreaterole, rolcreatedb, rolreplication INTO r
    FROM pg_roles WHERE rolname = role_name;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'role % does not exist', role_name;
  END IF;
  IF r.rolsuper OR r.rolbypassrls OR r.rolcreaterole OR r.rolcreatedb OR r.rolreplication THEN
    RAISE EXCEPTION 'role % has privileged attributes', role_name;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_class c WHERE c.relowner = r.oid AND c.relnamespace IN ('public'::regnamespace, 'app'::regnamespace))
     OR EXISTS (SELECT 1 FROM pg_proc p WHERE p.proowner = r.oid AND p.pronamespace IN ('public'::regnamespace, 'app'::regnamespace)) THEN
    RAISE EXCEPTION 'role % owns database objects', role_name;
  END IF;
  IF EXISTS (
    SELECT 1 FROM pg_auth_members m JOIN pg_roles g ON g.oid = m.roleid
    WHERE m.member = r.oid AND (g.rolsuper OR g.rolbypassrls OR g.rolcreaterole)
  ) THEN
    RAISE EXCEPTION 'role % is a member of a privileged role', role_name;
  END IF;
END
$$;

GRANT EXECUTE ON FUNCTION app.current_org_id(), app.current_user_id(), app.is_auth_scope(), app.assert_role_safe(name) TO rahyar_app;
