-- Only a keyed hash of the OTP is stored (HMAC-SHA256 with a server-side pepper).
CREATE TABLE otp_challenges (
  id           uuid PRIMARY KEY,
  phone_e164   text NOT NULL CHECK (phone_e164 ~ '^\+989[0-9]{9}$'),
  purpose      text NOT NULL CHECK (purpose IN ('login', 'step_up')),
  code_hash    text NOT NULL,
  attempts     integer NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  max_attempts integer NOT NULL CHECK (max_attempts BETWEEN 1 AND 10),
  ip_hash      text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  expires_at   timestamptz NOT NULL,
  consumed_at  timestamptz,
  locked_at    timestamptz
);
CREATE INDEX otp_challenges_phone_idx ON otp_challenges (phone_e164, created_at DESC);
CREATE INDEX otp_challenges_ip_idx ON otp_challenges (ip_hash, created_at DESC);

ALTER TABLE otp_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE otp_challenges FORCE ROW LEVEL SECURITY;
CREATE POLICY otp_challenges_all ON otp_challenges FOR ALL TO rahyar_app
  USING (app.is_auth_scope()) WITH CHECK (app.is_auth_scope());

GRANT SELECT, INSERT, UPDATE, DELETE ON otp_challenges TO rahyar_app;
