import { CamelCasePlugin, Kysely, PostgresDialect, sql, type Transaction } from 'kysely';
import pg from 'pg';
import { AppError, isUuid } from '@rahyar/domain-kernel';
import type { Database } from './db.types.ts';

export type Db = Kysely<Database>;
export type Trx = Transaction<Database>;

export function createDb(connectionString: string, poolMax: number): Db {
  return new Kysely<Database>({
    dialect: new PostgresDialect({ pool: new pg.Pool({ connectionString, max: poolMax, statement_timeout: 15_000 }) }),
    plugins: [new CamelCasePlugin()],
  });
}

// set_config(name, value, is_local = true): the setting dies with the transaction, so a pooled
// connection can never carry one request's tenant into another. Values are bound parameters.
export const setLocalConfig = (trx: Trx, name: string, value: string) => sql`select set_config(${name}, ${value}, true)`.execute(trx);

/** Pre-authentication flows only (OTP, token lookup, refresh). Everything else MUST use withTenantContext. */
export function withAuthScope<T>(db: Db, fn: (trx: Trx) => Promise<T>): Promise<T> {
  return db.transaction().execute(async (trx) => {
    await setLocalConfig(trx, 'app.scope', 'auth');
    return fn(trx);
  });
}

/** Binds user + organization to the transaction; PostgreSQL RLS then enforces tenancy regardless of app bugs. */
export function withTenantContext<T>(
  db: Db,
  ctx: {
    userId: string;
    organizationId: string | null;
    /** INTERNAL: only `KyselyTenantUnitOfWork.bootstrap` may set this (new, server-generated org id; write-only tx). */
    bootstrapOrganization?: boolean;
  },
  fn: (trx: Trx) => Promise<T>,
): Promise<T> {
  if (!isUuid(ctx.userId) || (ctx.organizationId !== null && !isUuid(ctx.organizationId))) {
    throw new AppError('internal', 'INVALID_TENANT_CONTEXT', 'Invalid tenant context.');
  }
  return db.transaction().execute(async (trx) => {
    await setLocalConfig(trx, 'app.user_id', ctx.userId);
    await setLocalConfig(trx, 'app.org_id', ctx.organizationId ?? '');
    if (ctx.organizationId !== null && ctx.bootstrapOrganization !== true) {
      // RLS isolates by app.org_id, so the id itself must be trusted: verify an ACTIVE membership here,
      // at the single choke point, rather than relying on every caller to have done so.
      const m = await trx
        .selectFrom('organizationMemberships')
        .select('id')
        .where('userId', '=', ctx.userId)
        .where('organizationId', '=', ctx.organizationId)
        .where('status', '=', 'active')
        .executeTakeFirst();
      if (!m) throw new AppError('forbidden', 'TENANT_ACCESS_DENIED', 'Not a member of this organization.');
    }
    return fn(trx);
  });
}

/** Within an auth-scope transaction, bind user/org so membership+role policies can be evaluated. */
export async function bindUserAndOrg(trx: Trx, userId: string, organizationId: string | null): Promise<void> {
  if (!isUuid(userId) || (organizationId !== null && !isUuid(organizationId))) {
    throw new AppError('internal', 'INVALID_TENANT_CONTEXT', 'Invalid tenant context.');
  }
  await setLocalConfig(trx, 'app.user_id', userId);
  await setLocalConfig(trx, 'app.org_id', organizationId ?? '');
}

/**
 * Startup self-check: refuse to run as a role that could bypass RLS. Delegates to the same SQL function the
 * migration runner uses (single source of truth) and additionally rejects a superuser session.
 */
export async function assertSafeApplicationRole(db: Db): Promise<void> {
  const su = await sql<{ is_superuser: string }>`select current_setting('is_superuser') as is_superuser`.execute(db);
  if (su.rows[0]?.is_superuser === 'on') throw new Error('Unsafe database role: the application is connected as a superuser.');
  try {
    await sql`select app.assert_role_safe(current_user)`.execute(db);
  } catch (e) {
    throw new Error(`Unsafe database role: ${e instanceof Error ? e.message : 'check failed'}`);
  }
}
