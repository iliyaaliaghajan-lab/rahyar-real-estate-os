-- Keys are scoped per user; organization_id is NULL for pre-organization operations
-- (e.g. creating the organization itself).
CREATE TABLE idempotency_keys (
  id              uuid PRIMARY KEY,
  user_id         uuid NOT NULL REFERENCES users (id),
  organization_id uuid REFERENCES organizations (id),
  key             text NOT NULL CHECK (char_length(key) BETWEEN 8 AND 128),
  method          text NOT NULL,
  path            text NOT NULL,
  request_hash    text NOT NULL,
  status          text NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress', 'completed')),
  response_status integer,
  response_body   jsonb,
  created_at      timestamptz NOT NULL DEFAULT now(),
  completed_at    timestamptz,
  expires_at      timestamptz NOT NULL,
  UNIQUE (user_id, key)
);
CREATE INDEX idempotency_keys_expiry_idx ON idempotency_keys (expires_at);

ALTER TABLE idempotency_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE idempotency_keys FORCE ROW LEVEL SECURITY;
CREATE POLICY idempotency_keys_all ON idempotency_keys FOR ALL TO rahyar_app
  USING (
    user_id = app.current_user_id()
    AND (organization_id IS NULL OR organization_id = app.current_org_id())
  )
  WITH CHECK (
    user_id = app.current_user_id()
    AND (organization_id IS NULL OR organization_id = app.current_org_id())
  );

GRANT SELECT, INSERT, UPDATE, DELETE ON idempotency_keys TO rahyar_app;
