#!/usr/bin/env node
// Lightweight local secret scan (CI additionally runs gitleaks). Exits non-zero on findings.
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, relative } from 'node:path';

const root = new URL('..', import.meta.url).pathname;
const SKIP_DIRS = new Set(['node_modules', '.git', 'dist', '.next', '.turbo', 'coverage']);
const PATTERNS = [
  ['private key', /-----BEGIN (?:RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----/],
  ['aws access key', /\bAKIA[0-9A-Z]{16}\b/],
  ['anthropic key', /\bsk-ant-[A-Za-z0-9_-]{20,}/],
  ['github token', /\bgh[pousr]_[A-Za-z0-9]{36,}\b/],
  ['slack token', /\bxox[baprs]-[A-Za-z0-9-]{10,}/],
  ['url with inline password', /\b[a-z]+:\/\/[^\s:@/]+:(?!change-me|ci-[a-z]+-password-not-a-secret)[^\s:@/]{6,}@(?!\$)/i],
  ['quoted credential literal', /\b(?:password|secret|pepper|api[_-]?key)\w*\s*[:=]\s*['"](?!change-me)[A-Za-z0-9+/_\-]{16,}['"]/i],
];
const findings = [];
const walk = (dir) => {
  for (const name of readdirSync(dir)) {
    if (SKIP_DIRS.has(name)) continue;
    const full = join(dir, name);
    const st = statSync(full);
    if (st.isDirectory()) walk(full);
    else if (st.size < 1_000_000 && !/\.(png|jpg|ico|woff2?|lock)$/.test(name) && !full.endsWith('check-secrets.mjs')) {
      const text = readFileSync(full, 'utf8');
      text.split('\n').forEach((line, i) => {
        for (const [label, re] of PATTERNS) if (re.test(line)) findings.push(`${relative(root, full)}:${i + 1}  ${label}`);
      });
    }
  }
};
walk(root);
for (const f of ['.env', '.env.local', '.env.production']) if (existsSync(join(root, f))) findings.push(`${f} exists in the working tree (must be untracked)`);
if (findings.length) {
  console.error(`Secret scan FAILED:\n${findings.map((f) => `  ${f}`).join('\n')}`);
  process.exit(1);
}
console.log('Secret scan passed (no findings).');
