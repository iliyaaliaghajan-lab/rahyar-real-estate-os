import type { AuditEntry } from '../../audit/audit.types.ts';

export type OrganizationRecord = { readonly id: string; readonly name: string; readonly status: 'active' | 'suspended' | 'closed'; readonly createdAt: Date };
export type AuditLogView = {
  readonly id: string;
  readonly action: string;
  readonly outcome: 'success' | 'denied' | 'failure';
  readonly actorUserId: string | null;
  readonly resourceType: string | null;
  readonly resourceId: string | null;
  readonly occurredAt: Date;
};
export type OutboxEventInput = {
  readonly organizationId: string | null;
  readonly aggregateType: string;
  readonly aggregateId: string;
  readonly eventType: string;
  readonly payload: Readonly<Record<string, unknown>>;
};
export type IdempotencyClaim =
  | { readonly state: 'claimed' }
  | { readonly state: 'replay'; readonly responseStatus: number; readonly responseBody: unknown }
  | { readonly state: 'mismatch' };

/** One transaction with tenant context (app.org_id / app.user_id) already bound by the implementation. */
export interface TenantTx {
  claimIdempotency(k: { key: string; method: string; path: string; requestHash: string; ttlSeconds: number; now: Date }): Promise<IdempotencyClaim>;
  completeIdempotency(key: string, responseStatus: number, responseBody: unknown, now: Date): Promise<void>;
  insertOrganization(o: { id: string; name: string }): Promise<void>;
  insertRole(r: { id: string; organizationId: string; key: string; name: string; permissions: readonly string[]; isSystem: boolean }): Promise<void>;
  insertMembership(m: { id: string; organizationId: string; userId: string; roleId: string }): Promise<void>;
  setSessionOrganization(sessionId: string, organizationId: string): Promise<void>;
  getOrganization(id: string): Promise<OrganizationRecord | null>;
  appendAudit(entry: AuditEntry): Promise<void>;
  appendOutbox(event: OutboxEventInput): Promise<void>;
  listAuditLogs(q: { limit: number; before: Date | null }): Promise<AuditLogView[]>;
}

/**
 * The ONLY operations available while a brand-new tenant is being created. Deliberately no read methods:
 * the bootstrap context is not membership-verified, so it must not be able to read anything.
 */
export type BootstrapTx = Pick<
  TenantTx,
  | 'claimIdempotency'
  | 'completeIdempotency'
  | 'insertOrganization'
  | 'insertRole'
  | 'insertMembership'
  | 'setSessionOrganization'
  | 'appendAudit'
  | 'appendOutbox'
>;

export interface TenantUnitOfWork {
  /**
   * Tenant-bound transaction. `organizationId` is honoured ONLY if the user holds an ACTIVE membership in it
   * (verified at this single persistence choke point). There is no flag to skip that check.
   */
  run<T>(ctx: { userId: string; organizationId: string | null; sessionId: string }, fn: (tx: TenantTx) => Promise<T>): Promise<T>;
  /**
   * Creates a NEW tenant. `newOrganizationId` must be server-generated; PostgreSQL RLS only admits rows for exactly
   * that id, the primary key rejects an id that already exists, and the transaction exposes write-only operations.
   */
  bootstrap<T>(ctx: { userId: string; sessionId: string; newOrganizationId: string }, fn: (tx: BootstrapTx) => Promise<T>): Promise<T>;
}
