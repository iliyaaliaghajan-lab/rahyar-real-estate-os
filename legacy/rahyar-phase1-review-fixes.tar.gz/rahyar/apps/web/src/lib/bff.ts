import 'server-only';
import { cookies } from 'next/headers';

/**
 * Backend-for-frontend helpers. Tokens live ONLY in httpOnly cookies set by the server, so page scripts
 * (and therefore XSS) can never read them. API_BASE_URL is server-side and never shipped to the browser.
 */
const API = process.env['API_BASE_URL'] ?? 'http://127.0.0.1:3001';
const SECURE = process.env.NODE_ENV === 'production';
export const COOKIE = { access: 'rhy_at', refresh: 'rhy_rt', device: 'rhy_did' } as const;

export type ApiResult<T> = { ok: true; status: number; data: T } | { ok: false; status: number; error: { code: string; message: string; details?: Record<string, unknown> } };

/** Real client address for API-side per-client rate limits (otherwise every user shares the BFF's IP). The edge MUST overwrite X-Forwarded-For. */
export function clientIp(req: Request): string | undefined {
  const xff = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim();
  return xff || req.headers.get('x-real-ip') || undefined;
}

export async function api<T>(path: string, init: { method?: string; body?: unknown; token?: string; ip?: string | undefined } = {}): Promise<ApiResult<T>> {
  const res = await fetch(`${API}/v1${path}`, {
    method: init.method ?? 'GET',
    headers: { 'content-type': 'application/json', ...(init.token ? { authorization: `Bearer ${init.token}` } : {}), ...(init.ip ? { 'x-forwarded-for': init.ip } : {}) },
    ...(init.body === undefined ? {} : { body: JSON.stringify(init.body) }),
    cache: 'no-store',
  });
  const text = await res.text();
  let json: unknown = null;
  try {
    json = text ? (JSON.parse(text) as unknown) : null;
  } catch {
    json = null; // non-JSON upstream body (e.g. a proxy error page): never surface it
  }
  if (res.ok) return { ok: true, status: res.status, data: json as T };
  const err = (json as { error?: { code: string; message: string; details?: Record<string, unknown> } } | null)?.error;
  return { ok: false, status: res.status, error: err ?? { code: 'UPSTREAM_ERROR', message: 'Request failed.' } };
}

/** CSRF defense in depth (cookies are also SameSite=Strict): state-changing requests must be same-origin. */
export function isSameOrigin(req: Request): boolean {
  const origin = req.headers.get('origin');
  if (!origin) return false;
  const configured = process.env['APP_ORIGIN'];
  if (SECURE && !configured) return false; // production without APP_ORIGIN fails closed
  try {
    // Behind a reverse proxy the Host header is not reliable; compare against the configured public origin.
    if (configured) return new URL(origin).origin === new URL(configured).origin;
    const host = req.headers.get('host');
    return host !== null && new URL(origin).host === host;
  } catch {
    return false;
  }
}

/** Reject browser requests that Fetch Metadata says are cross-site (used on the GET that can rotate tokens). */
export function isNotCrossSite(req: Request): boolean {
  const site = req.headers.get('sec-fetch-site');
  return site === null || site === 'same-origin' || site === 'none';
}

export async function setSession(t: { accessToken: string; accessExpiresAt: string; refreshToken: string; refreshExpiresAt: string }): Promise<void> {
  const jar = await cookies();
  const base = { httpOnly: true, secure: SECURE, sameSite: 'strict' as const };
  jar.set(COOKIE.access, t.accessToken, { ...base, path: '/', expires: new Date(t.accessExpiresAt) });
  jar.set(COOKIE.refresh, t.refreshToken, { ...base, path: '/api/auth', expires: new Date(t.refreshExpiresAt) });
}

export async function clearSession(): Promise<void> {
  const jar = await cookies();
  jar.delete(COOKIE.access);
  jar.delete({ name: COOKIE.refresh, path: '/api/auth' });
}

export async function deviceId(): Promise<string> {
  const jar = await cookies();
  const existing = jar.get(COOKIE.device)?.value;
  if (existing && existing.length >= 16) return existing;
  const id = crypto.randomUUID() + crypto.randomUUID().replaceAll('-', '');
  jar.set(COOKIE.device, id, { httpOnly: true, secure: SECURE, sameSite: 'strict', path: '/', maxAge: 60 * 60 * 24 * 400 });
  return id;
}
