import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { FastifyAdapter, type NestFastifyApplication } from '@nestjs/platform-fastify';
import helmet from '@fastify/helmet';
import cors from '@fastify/cors';
import rateLimit from '@fastify/rate-limit';
import { uuidv7 } from '@rahyar/domain-kernel';
import { AppModule } from './app.module.ts';
import { loadEnv } from './platform/config/env.schema.ts';
import { createLoggerOptions } from './platform/logging/logger-options.ts';

async function bootstrap(): Promise<void> {
  const env = loadEnv(); // fail fast on invalid/unsafe config
  const adapter = new FastifyAdapter({
    logger: createLoggerOptions(env.LOG_LEVEL, env.NODE_ENV === 'production'),
    trustProxy: env.TRUST_PROXY,
    genReqId: () => uuidv7(), // never trust a client-supplied request id
    bodyLimit: 1_048_576,
  });
  const app = await NestFactory.create<NestFastifyApplication>(AppModule, adapter, { bufferLogs: false });
  app.setGlobalPrefix('v1');
  await app.register(helmet, { contentSecurityPolicy: { directives: { defaultSrc: ["'none'"], frameAncestors: ["'none'"] } } });
  const origins = env.CORS_ORIGINS.split(',').map((s) => s.trim()).filter(Boolean);
  await app.register(cors, { origin: origins, credentials: false, methods: ['GET', 'POST', 'DELETE', 'OPTIONS'] });
  await app.register(rateLimit, { max: env.RATE_LIMIT_MAX, timeWindow: '1 minute' });
  app.enableShutdownHooks();
  await app.listen(env.PORT, env.HOST);
}

bootstrap().catch((e: unknown) => {
  process.stderr.write(`${e instanceof Error ? e.message : String(e)}\n`);
  process.exit(1);
});
