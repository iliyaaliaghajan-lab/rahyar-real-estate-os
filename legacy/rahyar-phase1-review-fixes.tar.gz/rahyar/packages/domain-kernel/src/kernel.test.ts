import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  AppError,
  addMoney,
  canonicalDigits,
  formatDate,
  formatMoney,
  fromDto,
  httpStatusFor,
  irr,
  isUuid,
  maskPhone,
  normalizeIranMobile,
  toDto,
  unknownValue,
  uuidv7,
} from './index.ts';

test('phone: accepts every common Iranian mobile format', () => {
  const inputs = [
    '09123456789',
    '9123456789',
    '989123456789',
    '+989123456789',
    '00989123456789',
    '۰۹۱۲۳۴۵۶۷۸۹',
    '٠٩١٢٣٤٥٦٧٨٩',
    '0912 345-6789',
    '+98 (912) 345 6789',
    '۰۹۱۲\u200c۳۴۵\u200f۶۷۸۹',
  ];
  for (const i of inputs) {
    const r = normalizeIranMobile(i);
    assert.equal(r.ok, true, i);
    if (r.ok) {
      assert.equal(r.value.e164, '+989123456789');
      assert.equal(r.value.national, '09123456789');
    }
  }
});

test('phone: rejects invalid and unsupported input explicitly', () => {
  for (const bad of ['', '0912345', '021 12345678', '0812345678', 'abc', '09123456789012', '+9891234567890']) {
    const r = normalizeIranMobile(bad);
    assert.equal(r.ok, false, bad);
  }
  const foreign = normalizeIranMobile('+14155550123');
  assert.deepEqual(foreign, { ok: false, error: 'PHONE_UNSUPPORTED_REGION' });
  assert.equal(normalizeIranMobile('x'.repeat(100)).ok, false);
});

test('phone: mask hides middle digits', () => {
  assert.equal(maskPhone('+989123456789'), '+9891*****89');
});

test('money: integer-only, explicit currency, DTO round-trips beyond 2^53', () => {
  assert.throws(() => irr(1.5), AppError);
  assert.throws(() => irr('1.5'), AppError);
  const big = irr('90071992547409930000');
  assert.equal(fromDto(toDto(big)).amountMinor, 90071992547409930000n);
  assert.equal(addMoney(irr(5), irr(7)).amountMinor, 12n);
  assert.throws(() => fromDto({ amount: '1', currency: 'USD' as 'IRR' }), AppError);
});

test('money: toman display is exact and labelled, never silent', () => {
  assert.match(formatMoney(irr(10_000_000n), 'IRT'), /تومان$/);
  assert.match(formatMoney(irr(10_000_000n), 'IRR'), /ریال$/);
  assert.match(formatMoney(irr(15n), 'IRT'), /۱.۵ تومان$/u);
  assert.equal(formatMoney(irr(0n), 'IRT'), '۰ تومان');
});

test('ids: uuidv7 is valid, version 7 and time-ordered', () => {
  const a = uuidv7(1_700_000_000_000);
  const b = uuidv7(1_700_000_000_001);
  assert.equal(isUuid(a), true);
  assert.equal(a[14], '7');
  assert.ok(a < b);
  assert.equal(isUuid('not-a-uuid'), false);
});

test('localization: Jalali date at presentation boundary, UTC input unchanged', () => {
  const d = new Date('2026-10-02T00:00:00Z');
  assert.equal(formatDate(d), '۱۰ مهر ۱۴۰۵');
  assert.equal(d.toISOString(), '2026-10-02T00:00:00.000Z');
  assert.equal(canonicalDigits(' ۱۲۳٤ '), '1234');
});

test('epistemic: unknown never carries a value', () => {
  const u = unknownValue('listing price');
  assert.equal(u.status, 'UNKNOWN');
  assert.equal(u.value, null);
});

test('errors: kind maps to HTTP status', () => {
  assert.equal(httpStatusFor('unauthenticated'), 401);
  assert.equal(httpStatusFor('forbidden'), 403);
  assert.equal(httpStatusFor('rate_limited'), 429);
});
