import { test } from 'node:test';
import assert from 'node:assert/strict';
import { sanitizeAuditMetadata } from './audit.types.ts';

test('audit metadata: credentials are redacted recursively, benign fields kept', () => {
  const out = sanitizeAuditMetadata({
    reason: 'x',
    otpCode: '123456',
    nested: { refreshToken: 'rhy_rt_abc', ok: 1, list: [{ password: 'p', keep: true }] },
  }) as Record<string, any>;
  assert.equal(out['reason'], 'x');
  assert.equal(out['otpCode'], '[redacted]');
  assert.equal(out['nested'].refreshToken, '[redacted]');
  assert.equal(out['nested'].ok, 1);
  assert.equal(out['nested'].list[0].password, '[redacted]');
  assert.equal(out['nested'].list[0].keep, true);
});

test('audit metadata: token-shaped VALUES are redacted even under benign keys', () => {
  const t = 'rhy_rt_' + 'A'.repeat(43);
  const out = sanitizeAuditMetadata({ note: `seen ${t} in log`, list: [t] }) as Record<string, any>;
  assert.equal(out['note'], 'seen [redacted] in log');
  assert.equal(out['list'][0], '[redacted]');
});
