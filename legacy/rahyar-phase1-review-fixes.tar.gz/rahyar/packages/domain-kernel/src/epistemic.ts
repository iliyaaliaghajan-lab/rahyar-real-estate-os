/**
 * How a piece of information is known. AI output is never OBSERVED.
 * UNKNOWN must never be silently coerced into a value or a match.
 */
export type EpistemicStatus =
  | 'OBSERVED'
  | 'DERIVED'
  | 'INFERRED'
  | 'FORECAST'
  | 'SIMULATED'
  | 'UNKNOWN';

export type Labeled<T> =
  | { readonly status: 'UNKNOWN'; readonly value: null; readonly missing?: string }
  | { readonly status: Exclude<EpistemicStatus, 'UNKNOWN'>; readonly value: T; readonly source?: string };

export const unknownValue = (missing?: string): Labeled<never> =>
  missing === undefined
    ? { status: 'UNKNOWN', value: null }
    : { status: 'UNKNOWN', value: null, missing };

export const observed = <T>(value: T, source?: string): Labeled<T> =>
  source === undefined ? { status: 'OBSERVED', value } : { status: 'OBSERVED', value, source };
