/** Framework-independent application error. Mapped to HTTP at the edge only. */
export type ErrorKind =
  | 'validation'
  | 'unauthenticated'
  | 'forbidden'
  | 'not_found'
  | 'conflict'
  | 'rate_limited'
  | 'precondition'
  | 'internal';

export class AppError extends Error {
  readonly kind: ErrorKind;
  readonly code: string;
  readonly details: Readonly<Record<string, unknown>> | undefined;

  constructor(kind: ErrorKind, code: string, message: string, details?: Record<string, unknown>) {
    super(message);
    this.name = 'AppError';
    this.kind = kind;
    this.code = code;
    this.details = details;
  }
}

export const httpStatusFor = (kind: ErrorKind): number => {
  switch (kind) {
    case 'validation':
      return 400;
    case 'unauthenticated':
      return 401;
    case 'forbidden':
      return 403;
    case 'not_found':
      return 404;
    case 'conflict':
      return 409;
    case 'precondition':
      return 412;
    case 'rate_limited':
      return 429;
    case 'internal':
      return 500;
  }
};
