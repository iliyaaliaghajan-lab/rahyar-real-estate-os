# ADR-0008 Money and time

Status: Accepted

Canonical IRR as bigint, explicit currency, Toman only for display. UTC storage; Jalali via Intl at the presentation boundary.
