#!/usr/bin/env bash
# Docker first-start hook (development/CI only). Runs as the container superuser and delegates to the same
# provisioning script used for staging/production, for both the dev and the test database.
set -euo pipefail
export PGUSER="$POSTGRES_USER" PGPASSWORD="${POSTGRES_PASSWORD:-}"
psql -v ON_ERROR_STOP=1 --no-psqlrc -X -d postgres -c "CREATE DATABASE rahyar_test OWNER ${POSTGRES_USER}"
for db in "$POSTGRES_DB" rahyar_test; do
  PGDATABASE="$db" bash /opt/rahyar-db/provision.sh
done
