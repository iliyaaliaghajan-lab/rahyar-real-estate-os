'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

type Me = { authenticated: boolean; organizationId: string | null };

export default function AppHome() {
  const router = useRouter();
  const [me, setMe] = useState<Me | null>(null);

  useEffect(() => {
    fetch('/api/auth/me').then(async (r) => {
      if (r.status === 401) return router.replace('/login');
      setMe((await r.json()) as Me);
    }).catch(() => router.replace('/login'));
  }, [router]);

  async function logout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.replace('/login');
  }

  return (
    <main>
      <section className="card">
        <h1>خوش آمدید</h1>
        <p className="muted">{me === null ? 'در حال بررسی نشست…' : me.organizationId ? 'سازمان شما فعال است.' : 'هنوز سازمانی ندارید. ایجاد سازمان در فاز بعدی رابط کاربری ارائه می‌شود (API آماده است).'}</p>
        <button type="button" className="secondary" onClick={logout}>خروج</button>
      </section>
    </main>
  );
}
