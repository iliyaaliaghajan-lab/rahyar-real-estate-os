// End-to-end identity + tenancy against real PostgreSQL through the production Kysely adapters.
import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import pg from 'pg';
import { AppError, systemClock, uuidv7 } from '@rahyar/domain-kernel';
import { DefaultDenyPolicyEngine } from '../../src/modules/authorization/domain/policy-engine.ts';
import { AuthService } from '../../src/modules/identity/application/auth.service.ts';
import { KyselyAuthUnitOfWork } from '../../src/modules/identity/infrastructure/kysely-auth.uow.ts';
import { OrganizationService } from '../../src/modules/organization/application/organization.service.ts';
import { KyselyTenantUnitOfWork } from '../../src/modules/organization/infrastructure/kysely-tenant.uow.ts';
import { createDb, assertSafeApplicationRole, type Db } from '../../src/platform/database/tenant-context.ts';
import { migrate } from '../../db/migrate.ts';
import { APP_URL, MIGRATOR_URL, SKIP, asApp } from '../support/pg.ts';
import { CapturingOtpSender } from '../support/in-memory.ts';
import { assertTenantIsolation, seedTenant, type HarnessDeps } from '../support/tenant-harness.ts';

describe('identity + tenancy (PostgreSQL, production adapters)', { skip: SKIP }, () => {
  let db: Db;
  let raw: pg.Pool;
  const sender = new CapturingOtpSender();
  let auth: AuthService;
  let deps: HarnessDeps;
  const suffix = String(Date.now()).slice(-6);
  const phone = (n: number) => `0912${suffix}${n}`.slice(0, 11);
  const rejects = (p: Promise<unknown>, code: string) => assert.rejects(p, (e: unknown) => e instanceof AppError && e.code === code);

  before(async () => {
    await migrate(MIGRATOR_URL as string);
    db = createDb(APP_URL as string, 5);
    await assertSafeApplicationRole(db);
    raw = new pg.Pool({ connectionString: APP_URL as string, max: 3 });
    const policy = new DefaultDenyPolicyEngine();
    auth = new AuthService({ uow: new KyselyAuthUnitOfWork(db), sender, clock: systemClock, policy, config: { pepper: 'i'.repeat(48), otp: { length: 6, ttlSeconds: 120, maxAttempts: 5, resendCooldownSeconds: 0, phoneWindow: { maxRequests: 100, windowSeconds: 3600 }, ipWindow: { maxRequests: 1000, windowSeconds: 3600 } } } });
    const tenantUow = new KyselyTenantUnitOfWork(db);
    const orgs = new OrganizationService({ uow: tenantUow, clock: systemClock, policy });
    deps = {
      auth, orgs, tenantUow,
      login: async (p, deviceId) => {
        const r = await auth.requestOtp({ phone: p });
        const s = await auth.verifyOtp({ challengeId: r.challengeId, code: sender.last?.code ?? '', device: { deviceId } });
        return { accessToken: s.accessToken, sessionId: s.sessionId };
      },
    };
  });
  after(async () => {
    await db.destroy();
    await raw.end();
  });

  it('OTP is stored only as a keyed hash; verify creates user, device, session', async () => {
    const r = await auth.requestOtp({ phone: phone(1) });
    const code = sender.last?.code ?? '';
    const row = await asApp(raw, { scope: 'auth' }, (c) => c.query<{ code_hash: string }>('select code_hash from otp_challenges where id = $1', [r.challengeId]));
    assert.match(row.rows[0]?.code_hash ?? '', /^[0-9a-f]{64}$/);
    assert.notEqual(row.rows[0]?.code_hash, code);
    const s = await auth.verifyOtp({ challengeId: r.challengeId, code, device: { deviceId: 'device-integration-0001' } });
    assert.equal((await auth.authenticate(s.accessToken)).userId, s.userId);
    await rejects(auth.verifyOtp({ challengeId: r.challengeId, code, device: { deviceId: 'device-integration-0001' } }), 'OTP_ALREADY_USED');
  });

  it('OTP attempt limit persists across transactions and locks', async () => {
    const r = await auth.requestOtp({ phone: phone(2) });
    const good = sender.last?.code ?? '';
    const bad = good === '000000' ? '111111' : '000000';
    for (let i = 0; i < 5; i++) await rejects(auth.verifyOtp({ challengeId: r.challengeId, code: bad, device: { deviceId: 'device-integration-0002' } }), 'OTP_INVALID');
    await rejects(auth.verifyOtp({ challengeId: r.challengeId, code: good, device: { deviceId: 'device-integration-0002' } }), 'OTP_LOCKED');
  });

  it('refresh rotation and reuse detection revoke the whole session', async () => {
    const s = await deps.login(phone(3), 'device-integration-0003');
    const r = await auth.requestOtp({ phone: phone(3) });
    const full = await auth.verifyOtp({ challengeId: r.challengeId, code: sender.last?.code ?? '', device: { deviceId: 'device-integration-0003' } });
    const gen2 = await auth.refresh({ refreshToken: full.refreshToken });
    await rejects(auth.refresh({ refreshToken: full.refreshToken }), 'REFRESH_REUSED');
    await rejects(auth.refresh({ refreshToken: gen2.refreshToken }), 'REFRESH_INVALID');
    await rejects(auth.authenticate(gen2.accessToken), 'UNAUTHENTICATED');
    assert.ok(s.accessToken);
  });

  it('concurrent use of one refresh token: exactly one rotation wins, session is then revoked', async () => {
    const r = await auth.requestOtp({ phone: phone(4) });
    const s = await auth.verifyOtp({ challengeId: r.challengeId, code: sender.last?.code ?? '', device: { deviceId: 'device-integration-0004' } });
    const results = await Promise.allSettled([auth.refresh({ refreshToken: s.refreshToken }), auth.refresh({ refreshToken: s.refreshToken })]);
    assert.equal(results.filter((x) => x.status === 'fulfilled').length, 1);
  });

  it('tenant isolation harness against real RLS: forged principal/context cannot cross tenants', async () => {
    const a = await seedTenant(deps, phone(5), 'device-integration-000a', 'الف', uuidv7());
    const b = await seedTenant(deps, phone(6), 'device-integration-000b', 'ب', uuidv7());
    await assertTenantIsolation(deps, a, b);
    // Raw SQL with a forged org id returns only rows of that org, never mixes; and a foreign-org insert violates RLS.
    await assert.rejects(
      asApp(raw, { userId: a.principal.userId, orgId: a.organizationId }, (c) =>
        c.query("insert into roles (id, organization_id, key, name) values ($1, $2, 'evil', 'evil')", [uuidv7(), b.organizationId]),
      ),
      /row-level security/,
    );
    // Composite FK: a membership cannot point at another organization's role.
    const roleB = await asApp(raw, { userId: b.principal.userId, orgId: b.organizationId }, (c) => c.query<{ id: string }>("select id from roles where key='viewer'"));
    await assert.rejects(
      asApp(raw, { userId: a.principal.userId, orgId: a.organizationId }, (c) =>
        c.query('insert into organization_memberships (id, organization_id, user_id, role_id) values ($1,$2,$3,$4)', [uuidv7(), a.organizationId, a.principal.userId, roleB.rows[0]?.id]),
      ),
      /foreign key|violates/,
    );
  });

  it('organization creation is idempotent and atomic (one org, one outbox event, audit present)', async () => {
    const s = await deps.login(phone(7), 'device-integration-0007');
    const p = await auth.authenticate(s.accessToken);
    const key = uuidv7();
    const [x, y] = [await deps.orgs.createOrganization(p, { name: 'راهیار', idempotencyKey: key }), await deps.orgs.createOrganization(p, { name: 'راهیار', idempotencyKey: key })];
    assert.equal(x.organizationId, y.organizationId);
    const outbox = await asApp(raw, { userId: p.userId, orgId: x.organizationId }, (c) => c.query('select count(*)::int as n from outbox_events'));
    assert.equal(outbox.rows[0]?.n, 1);
  });

  it('device revoke blocks sessions immediately', async () => {
    const r = await auth.requestOtp({ phone: phone(8) });
    const s = await auth.verifyOtp({ challengeId: r.challengeId, code: sender.last?.code ?? '', device: { deviceId: 'device-integration-0008' } });
    const p = await auth.authenticate(s.accessToken);
    const [dev] = await auth.listDevices(p);
    assert.ok(dev);
    await auth.revokeDevice(p, dev.id);
    await rejects(auth.authenticate(s.accessToken), 'UNAUTHENTICATED');
  });

  it('user-bound scope: RLS (not application code) confines a user to their own sessions/devices', async () => {
    const sa = await deps.login(phone(9), 'device-integration-0009');
    const sb = await deps.login(phone(10), 'device-integration-0010');
    const pa = await auth.authenticate(sa.accessToken);
    const pb = await auth.authenticate(sb.accessToken);
    for (const table of ['sessions', 'devices', 'refresh_tokens']) {
      const own = await asApp(raw, { userId: pa.userId }, (c) => c.query(`select count(*)::int as n from ${table} where user_id = $1`, [pa.userId]));
      const foreign = await asApp(raw, { userId: pa.userId }, (c) => c.query(`select count(*)::int as n from ${table} where user_id = $1`, [pb.userId]));
      assert.ok((own.rows[0]?.n ?? 0) >= 1, `${table}: own rows visible`);
      assert.equal(foreign.rows[0]?.n, 0, `${table}: foreign rows invisible`);
    }
    // And the service-level self-service operations are confined the same way.
    await rejects(auth.revokeSession(pb, pa.sessionId), 'SESSION_NOT_FOUND');
    await rejects(auth.revokeDevice(pb, pa.deviceId), 'DEVICE_NOT_FOUND');
  });

  it('org-bound context sees ONLY its organization even for a user who belongs to several', async () => {
    const s = await deps.login(phone(11), 'device-integration-0011');
    const p = await auth.authenticate(s.accessToken);
    const o1 = await deps.orgs.createOrganization(p, { name: 'سازمان یک', idempotencyKey: uuidv7() });
    const o2 = await deps.orgs.createOrganization(p, { name: 'سازمان دو', idempotencyKey: uuidv7() });
    const inOrg1 = await asApp(raw, { userId: p.userId, orgId: o1.organizationId }, async (c) => ({
      orgs: (await c.query<{ id: string }>('select id from organizations')).rows.map((r) => r.id),
      memberships: (await c.query<{ organization_id: string }>('select organization_id from organization_memberships')).rows.map((r) => r.organization_id),
    }));
    assert.deepEqual(inOrg1.orgs, [o1.organizationId]);
    assert.deepEqual(inOrg1.memberships, [o1.organizationId]);
    const noOrg = await asApp(raw, { userId: p.userId }, (c) => c.query<{ id: string }>('select id from organizations'));
    assert.deepEqual(noOrg.rows.map((r) => r.id).sort(), [o1.organizationId, o2.organizationId].sort());
  });

  it('cross-tenant writes fail: foreign update affects 0 rows; foreign membership insert violates RLS', async () => {
    const a = await seedTenant(deps, phone(12), 'device-integration-0012', 'الف۱', uuidv7());
    const b = await seedTenant(deps, phone(13), 'device-integration-0013', 'ب۱', uuidv7());
    const upd = await asApp(raw, { userId: a.principal.userId, orgId: a.organizationId }, (c) => c.query("update organizations set name = 'pwned' where id = $1", [b.organizationId]));
    assert.equal(upd.rowCount, 0);
    await assert.rejects(
      asApp(raw, { userId: a.principal.userId, orgId: a.organizationId }, (c) =>
        c.query('insert into organization_memberships (id, organization_id, user_id, role_id) values ($1,$2,$3,gen_random_uuid())', [uuidv7(), b.organizationId, a.principal.userId]),
      ),
      /row-level security/,
    );
    const still = await asApp(raw, { userId: b.principal.userId, orgId: b.organizationId }, (c) => c.query<{ name: string }>('select name from organizations'));
    assert.notEqual(still.rows[0]?.name, 'pwned');
  });

  it('bootstrap transaction is write-only and cannot adopt an existing organization id', async () => {
    const a = await seedTenant(deps, phone(14), 'device-integration-0014', 'الف۲', uuidv7());
    const s = await deps.login(phone(15), 'device-integration-0015');
    const p = await auth.authenticate(s.accessToken);
    const uow = new KyselyTenantUnitOfWork(db);
    await uow.bootstrap({ userId: p.userId, sessionId: p.sessionId, newOrganizationId: uuidv7() }, async (tx) => {
      assert.equal('getOrganization' in tx, false);
      assert.equal('listAuditLogs' in tx, false);
    });
    await assert.rejects(uow.bootstrap({ userId: p.userId, sessionId: p.sessionId, newOrganizationId: a.organizationId }, (tx) => tx.insertOrganization({ id: a.organizationId, name: 'hijack' })));
    assert.equal((await deps.orgs.getCurrentOrganization(a.principal)).name, 'الف۲');
  });

  it('concurrent refresh with one token: exactly one wins, and the loser revokes the session (strict reuse policy)', async () => {
    const r = await auth.requestOtp({ phone: phone(16) });
    const s = await auth.verifyOtp({ challengeId: r.challengeId, code: sender.last?.code ?? '', device: { deviceId: 'device-integration-0016' } });
    const [x, y] = await Promise.allSettled([auth.refresh({ refreshToken: s.refreshToken }), auth.refresh({ refreshToken: s.refreshToken })]);
    const winners = [x, y].filter((v): v is PromiseFulfilledResult<Awaited<ReturnType<AuthService['refresh']>>> => v.status === 'fulfilled');
    assert.equal(winners.length, 1);
    await rejects(auth.authenticate(winners[0]?.value.accessToken), 'UNAUTHENTICATED'); // loser's reuse detection revoked the session
  });
});
