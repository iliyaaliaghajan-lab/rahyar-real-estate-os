/* eslint-disable no-console */
// Forward-only migration runner. Requires the migrator role (DATABASE_MIGRATOR_URL), never the app role.
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import pg from 'pg';
import { loadMigrations } from './migration-files.ts';

const ADVISORY_LOCK_KEY = 727_001; // arbitrary, stable

export async function migrate(connectionString: string): Promise<{ applied: string[] }> {
  const dir = join(dirname(fileURLToPath(import.meta.url)), 'migrations');
  const migrations = loadMigrations(dir);
  const client = new pg.Client({ connectionString });
  await client.connect();
  const applied: string[] = [];
  try {
    // The migrator must never be the application role (it would then own the tables and defeat RLS).
    const who = await client.query<{ u: string }>('select current_user as u');
    if (who.rows[0]?.u === 'rahyar_app') throw new Error('Refusing to migrate as the application role rahyar_app.');
    await client.query('SELECT pg_advisory_lock($1)', [ADVISORY_LOCK_KEY]);
    await client.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
      version integer PRIMARY KEY, name text NOT NULL, checksum text NOT NULL,
      applied_at timestamptz NOT NULL DEFAULT now())`);
    const res = await client.query<{ version: number; checksum: string }>(
      'SELECT version, checksum FROM schema_migrations ORDER BY version',
    );
    const done = new Map(res.rows.map((r) => [r.version, r.checksum]));
    for (const m of migrations) {
      const existing = done.get(m.version);
      if (existing !== undefined) {
        if (existing !== m.checksum) {
          throw new Error(`Checksum mismatch for applied migration ${m.filename}; migrations are immutable.`);
        }
        continue;
      }
      await client.query('BEGIN');
      try {
        await client.query(m.sql);
        await client.query('INSERT INTO schema_migrations (version, name, checksum) VALUES ($1,$2,$3)', [
          m.version,
          m.name,
          m.checksum,
        ]);
        await client.query('COMMIT');
        applied.push(m.filename);
      } catch (e) {
        await client.query('ROLLBACK');
        throw e;
      }
    }
    // Post-condition: after ALL migrations the application role is still unprivileged and owns nothing.
    await client.query("select app.assert_role_safe('rahyar_app')");
  } finally {
    await client.query('SELECT pg_advisory_unlock($1)', [ADVISORY_LOCK_KEY]).catch(() => undefined);
    await client.end();
  }
  return { applied };
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const url = process.env['DATABASE_MIGRATOR_URL'];
  if (!url) {
    console.error('DATABASE_MIGRATOR_URL is required');
    process.exit(1);
  }
  migrate(url)
    .then((r) => console.log(r.applied.length ? `Applied: ${r.applied.join(', ')}` : 'Up to date'))
    .catch((e: unknown) => {
      console.error(e);
      process.exit(1);
    });
}
