import { ArgumentsHost, Catch, HttpException, type ExceptionFilter } from '@nestjs/common';
import type { FastifyReply, FastifyRequest } from 'fastify';
import { AppError, httpStatusFor } from '@rahyar/domain-kernel';
import type { ApiErrorBody } from '@rahyar/contracts';

/** Single place where domain errors become HTTP. Unknown errors never leak internals. */
@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  catch(exception: unknown, host: ArgumentsHost): void {
    const http = host.switchToHttp();
    const req = http.getRequest<FastifyRequest>();
    const reply = http.getResponse<FastifyReply>();
    const requestId = req.id;

    let status = 500;
    let body: ApiErrorBody;

    if (exception instanceof AppError) {
      status = httpStatusFor(exception.kind);
      body = { error: { code: exception.code, message: exception.message, requestId, ...(exception.details ? { details: exception.details } : {}) } };
      const retry = exception.details?.['retryAfterSeconds'];
      if (exception.kind === 'rate_limited' && typeof retry === 'number') void reply.header('Retry-After', String(retry));
    } else if (exception instanceof HttpException) {
      status = exception.getStatus();
      body = { error: { code: status === 404 ? 'NOT_FOUND' : 'HTTP_ERROR', message: status === 404 ? 'Not found.' : 'Request failed.', requestId } };
    } else {
      req.log.error({ err: exception }, 'unhandled exception');
      body = { error: { code: 'INTERNAL', message: 'Internal server error.', requestId } };
    }
    void reply.status(status).header('Cache-Control', 'no-store').send(body);
  }
}
