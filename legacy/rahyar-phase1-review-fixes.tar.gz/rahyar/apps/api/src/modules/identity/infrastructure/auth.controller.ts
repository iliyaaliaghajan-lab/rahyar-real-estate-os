import { Body, Controller, Delete, Get, HttpCode, Inject, Param, Post } from '@nestjs/common';
import { RefreshBody, RequestOtpBody, SwitchOrganizationBody, VerifyOtpBody } from '@rahyar/contracts';
import { AppError, isUuid } from '@rahyar/domain-kernel';
import { CurrentPrincipal, Public, RequestMeta, parseBody } from '../../../platform/http/http.ts';
import type { Principal } from '../../authorization/domain/policy-engine.ts';
import { AuthService } from '../application/auth.service.ts';

type Meta = { ip: string; requestId: string };

@Controller('auth')
export class AuthController {
  constructor(@Inject(AuthService) private readonly auth: AuthService) {}

  @Public() @Post('otp/request') @HttpCode(200)
  async requestOtp(@Body() body: unknown, @RequestMeta() meta: Meta) {
    const b = parseBody(RequestOtpBody, body);
    const r = await this.auth.requestOtp(b, meta);
    return { challengeId: r.challengeId, expiresAt: r.expiresAt.toISOString(), resendAfterSeconds: r.resendAfterSeconds };
  }

  @Public() @Post('otp/verify') @HttpCode(200)
  async verifyOtp(@Body() body: unknown, @RequestMeta() meta: Meta) {
    const b = parseBody(VerifyOtpBody, body);
    const r = await this.auth.verifyOtp({ challengeId: b.challengeId, code: b.code, device: { deviceId: b.device.deviceId, label: b.device.label, platform: b.device.platform } }, meta);
    return {
      accessToken: r.accessToken, accessExpiresAt: r.accessExpiresAt.toISOString(),
      refreshToken: r.refreshToken, refreshExpiresAt: r.refreshExpiresAt.toISOString(),
      userId: r.userId, organizationId: r.organizationId, isNewUser: r.isNewUser,
    };
  }

  @Public() @Post('refresh') @HttpCode(200)
  async refresh(@Body() body: unknown, @RequestMeta() meta: Meta) {
    const t = await this.auth.refresh(parseBody(RefreshBody, body), meta);
    return { accessToken: t.accessToken, accessExpiresAt: t.accessExpiresAt.toISOString(), refreshToken: t.refreshToken, refreshExpiresAt: t.refreshExpiresAt.toISOString() };
  }

  @Post('logout') @HttpCode(204)
  async logout(@CurrentPrincipal() p: Principal, @RequestMeta() meta: Meta): Promise<void> {
    await this.auth.logout(p, meta);
  }

  @Get('me')
  me(@CurrentPrincipal() p: Principal) {
    return { userId: p.userId, sessionId: p.sessionId, organizationId: p.organizationId, permissions: [...p.permissions].sort() };
  }

  @Post('session/organization') @HttpCode(204)
  async switchOrg(@Body() body: unknown, @CurrentPrincipal() p: Principal, @RequestMeta() meta: Meta): Promise<void> {
    await this.auth.switchOrganization(p, parseBody(SwitchOrganizationBody, body).organizationId, meta);
  }

  @Get('sessions')
  async sessions(@CurrentPrincipal() p: Principal) {
    return { items: await this.auth.listSessions(p) };
  }

  @Delete('sessions/:id') @HttpCode(204)
  async revokeSession(@Param('id') id: string, @CurrentPrincipal() p: Principal, @RequestMeta() meta: Meta): Promise<void> {
    if (!isUuid(id)) throw new AppError('not_found', 'SESSION_NOT_FOUND', 'Session not found.');
    await this.auth.revokeSession(p, id, meta);
  }

  @Get('devices')
  async devices(@CurrentPrincipal() p: Principal) {
    return { items: await this.auth.listDevices(p) };
  }

  @Delete('devices/:id') @HttpCode(204)
  async revokeDevice(@Param('id') id: string, @CurrentPrincipal() p: Principal, @RequestMeta() meta: Meta): Promise<void> {
    if (!isUuid(id)) throw new AppError('not_found', 'DEVICE_NOT_FOUND', 'Device not found.');
    await this.auth.revokeDevice(p, id, meta);
  }
}
