# Dependency licenses
Generated in CI (`pnpm licenses list --prod` → artifact `licenses`). Product code is proprietary (LICENSE.md). Review copyleft findings before release.
