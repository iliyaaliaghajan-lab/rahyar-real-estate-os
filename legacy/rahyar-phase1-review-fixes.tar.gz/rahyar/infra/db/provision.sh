#!/usr/bin/env bash
# Provision the unprivileged APPLICATION role and extensions in ONE database. Idempotent. Run by an ADMINISTRATOR
# (never by the application, never from a migration). Works for local Docker and for managed PostgreSQL.
#
#   PGHOST PGPORT PGUSER PGPASSWORD PGDATABASE  -> admin connection (standard libpq variables)
#   RAHYAR_APP_PASSWORD                         -> password for rahyar_app (from your secret manager)
#
# The role is always normalised to: LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE NOREPLICATION.
# The password is read from the environment inside psql (never placed on a command line or in SQL files).
set -euo pipefail
: "${RAHYAR_APP_PASSWORD:?RAHYAR_APP_PASSWORD is required}"
: "${PGDATABASE:?PGDATABASE is required}"

psql -v ON_ERROR_STOP=1 --no-psqlrc -X <<'SQL'
\set app_password `printenv RAHYAR_APP_PASSWORD`
SELECT CASE WHEN EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'rahyar_app')
  THEN format('ALTER ROLE rahyar_app LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE NOREPLICATION PASSWORD %L', :'app_password')
  ELSE format('CREATE ROLE rahyar_app LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE NOREPLICATION PASSWORD %L', :'app_password')
END \gexec
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS unaccent;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
SELECT format('GRANT CONNECT ON DATABASE %I TO rahyar_app', current_database()) \gexec
SQL
echo "provisioned rahyar_app + extensions in database '${PGDATABASE}'"
