# Database role lifecycle

| Role | Purpose | Attributes | Owns objects | Used by |
|---|---|---|---|---|
| admin / migrator (e.g. `rahyar_admin`) | create schema, run migrations, provision | privileged | **yes** (tables, functions) | `pnpm db:migrate`, operators — **never the running API** |
| `rahyar_app` | the application | `LOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE NOREPLICATION` | **no** | API process only |

Lifecycle (deterministic, in this order):
1. **Provision** (administrator, out-of-band, idempotent): `infra/db/provision.sh` creates or *normalises* `rahyar_app`
   to the attributes above, sets its password from `RAHYAR_APP_PASSWORD` (read inside psql, never on a command line or in SQL),
   installs extensions, grants `CONNECT`. Docker runs it automatically on first start; staging/production operators run it
   with their own admin connection.
2. **Migrate** (migrator role): migration 0002 creates `rahyar_app` as `NOLOGIN` only if absent, and **raises an error if it
   exists with any privileged attribute**. No migration contains a password or an `ALTER ROLE`. All table access is granted
   explicitly, and a static test requires every granted privilege to have a matching RLS policy.
3. **Post-condition**: the runner refuses to run as `rahyar_app` and finishes by calling `app.assert_role_safe('rahyar_app')`
   (not superuser / BYPASSRLS / CREATEROLE / CREATEDB / REPLICATION, owns no tables or functions, no privileged role membership).
4. **Startup**: the API calls the same function for `current_user` and also rejects a superuser session — it will not boot
   unsafe. `FORCE ROW LEVEL SECURITY` additionally subjects table owners to policies (superusers and BYPASSRLS roles are
   outside PostgreSQL's control, which is why the application must never use them).

Known limit: a superuser/BYPASSRLS *migrator* bypasses RLS by design; keep its credentials out of the API environment
(`DATABASE_MIGRATOR_URL` is rejected by config validation in staging/production).
