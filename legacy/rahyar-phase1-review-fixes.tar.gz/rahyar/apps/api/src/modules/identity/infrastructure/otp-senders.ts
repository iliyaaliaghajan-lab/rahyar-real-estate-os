import { AppError } from '@rahyar/domain-kernel';
import type { OtpSender } from '../application/ports.ts';

/** Development only (config forbids it in production). Logs the code to stdout. */
export class ConsoleOtpSender implements OtpSender {
  private readonly log: (msg: string) => void;
  constructor(log: (msg: string) => void) {
    this.log = log;
  }
  send(a: { phoneE164: string; code: string; ttlSeconds: number }): Promise<void> {
    this.log(`[DEV OTP] ${a.phoneE164} -> ${a.code} (valid ${a.ttlSeconds}s)`);
    return Promise.resolve();
  }
}

/** Placeholder until an SMS provider is selected (open decision D8). Fails loudly; never pretends to send. */
export class UnconfiguredOtpSender implements OtpSender {
  send(): Promise<void> {
    return Promise.reject(new AppError('internal', 'SMS_PROVIDER_NOT_CONFIGURED', 'No SMS provider is configured.'));
  }
}
