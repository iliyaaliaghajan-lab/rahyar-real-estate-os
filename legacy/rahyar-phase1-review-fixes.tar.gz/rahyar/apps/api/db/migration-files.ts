import { createHash } from 'node:crypto';
import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';

export type MigrationFile = {
  readonly version: number;
  readonly name: string;
  readonly filename: string;
  readonly sql: string;
  readonly checksum: string;
};

const NAME_RE = /^(\d{4})_([a-z0-9_]+)\.sql$/;

/** Deterministic: lexical order == numeric order, versions must be contiguous from 1. */
export function loadMigrations(dir: string): MigrationFile[] {
  const files = readdirSync(dir)
    .filter((f) => f.endsWith('.sql'))
    .sort();
  const out: MigrationFile[] = [];
  files.forEach((filename, idx) => {
    const m = NAME_RE.exec(filename);
    if (!m) throw new Error(`Invalid migration filename: ${filename}`);
    const version = Number(m[1]);
    if (version !== idx + 1) {
      throw new Error(`Migration versions must be contiguous; expected ${idx + 1}, got ${version} (${filename})`);
    }
    const sql = readFileSync(join(dir, filename), 'utf8');
    out.push({
      version,
      name: m[2] ?? '',
      filename,
      sql,
      checksum: createHash('sha256').update(sql).digest('hex'),
    });
  });
  return out;
}
