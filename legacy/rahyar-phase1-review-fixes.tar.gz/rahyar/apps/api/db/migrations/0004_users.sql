-- Users are global identities (one person, many organizations); they are NOT tenant-owned.
CREATE TABLE users (
  id                uuid PRIMARY KEY,
  phone_e164        text NOT NULL UNIQUE CHECK (phone_e164 ~ '^\+989[0-9]{9}$'),
  display_name      text CHECK (display_name IS NULL OR char_length(display_name) BETWEEN 1 AND 120),
  locale            text NOT NULL DEFAULT 'fa-IR',
  status            text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'disabled')),
  phone_verified_at timestamptz,
  last_login_at     timestamptz,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  version           integer NOT NULL DEFAULT 1
);

CREATE TRIGGER users_touch BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION app.touch_updated_at();

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE users FORCE ROW LEVEL SECURITY;

CREATE POLICY users_select ON users FOR SELECT TO rahyar_app
  USING (id = app.current_user_id() OR app.is_auth_scope());
CREATE POLICY users_insert ON users FOR INSERT TO rahyar_app
  WITH CHECK (app.is_auth_scope());
CREATE POLICY users_update ON users FOR UPDATE TO rahyar_app
  USING (id = app.current_user_id() OR app.is_auth_scope())
  WITH CHECK (id = app.current_user_id() OR app.is_auth_scope());

GRANT SELECT, INSERT, UPDATE ON users TO rahyar_app;
