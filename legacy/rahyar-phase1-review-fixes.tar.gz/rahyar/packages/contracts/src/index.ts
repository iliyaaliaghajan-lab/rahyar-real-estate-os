import { z } from 'zod';

/** Wire contracts shared by API and web. Validation lives here once; servers never trust the client. */
export const DevicePlatform = z.enum(['web', 'ios', 'android', 'desktop', 'unknown']);

export const RequestOtpBody = z.object({ phone: z.string().min(1).max(40) }).strict();

export const VerifyOtpBody = z
  .object({
    challengeId: z.string().uuid(),
    code: z.string().min(4).max(12),
    device: z
      .object({
        deviceId: z.string().min(16).max(128),
        label: z.string().max(120).optional(),
        platform: DevicePlatform.optional(),
      })
      .strict(),
  })
  .strict();

export const RefreshBody = z.object({ refreshToken: z.string().min(10).max(200) }).strict();
export const SwitchOrganizationBody = z.object({ organizationId: z.string().uuid() }).strict();
export const CreateOrganizationBody = z.object({ name: z.string().min(1).max(200) }).strict();

export type RequestOtpBody = z.infer<typeof RequestOtpBody>;
export type VerifyOtpBody = z.infer<typeof VerifyOtpBody>;
export type RefreshBody = z.infer<typeof RefreshBody>;
export type CreateOrganizationBody = z.infer<typeof CreateOrganizationBody>;

export type ApiErrorBody = {
  error: { code: string; message: string; requestId?: string; details?: Record<string, unknown> };
};
