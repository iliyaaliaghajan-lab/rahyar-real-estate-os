# Architecture (Phase 1)

Modular monolith. Each module keeps `domain/` (pure) → `application/` (use cases against **ports**) → `infrastructure/`
(Kysely, Nest). Framework and ORM types never enter domain/application (enforced by ESLint `no-restricted-imports`).

| Module | Phase 1 content |
|---|---|
| identity | phone normalisation, OTP, opaque tokens, sessions, devices, refresh rotation |
| authorization | action registry, default-deny `PolicyEngine`, system roles |
| organization | create org (roles+owner membership), current org, audit read |
| audit | append-only writer + credential-redacting sanitizer |
| idempotency / outbox | key claim/replay; transactional outbox writer (relay is a later phase) |

Request flow: `AuthGuard` (global, default-deny) → verified session + **live membership** → `Principal` →
service calls `PolicyEngine.decide` → unit of work binds `app.user_id` / `app.org_id` per transaction → PostgreSQL RLS.
Domain errors (`AppError`) become HTTP only in one filter.
Currency: canonical IRR integer (bigint); Toman only at presentation. Time: UTC stored, Jalali at presentation (`Intl`, `Asia/Tehran`).
