import { test } from 'node:test';
import assert from 'node:assert/strict';
import { AppError } from '@rahyar/domain-kernel';
import { DefaultDenyPolicyEngine } from '../../authorization/domain/policy-engine.ts';
import { CapturingOtpSender, FakeClock, MemoryAuthUow, MemoryDb } from '../../../../test/support/in-memory.ts';
import { AuthService, type LoginResult } from './auth.service.ts';

const PEPPER = 'x'.repeat(48);
const DEVICE_A = 'device-aaaaaaaaaaaaaaaa';
const DEVICE_B = 'device-bbbbbbbbbbbbbbbb';

function setup() {
  const db = new MemoryDb();
  const sender = new CapturingOtpSender();
  const clock = new FakeClock();
  const service = new AuthService({
    uow: new MemoryAuthUow(db),
    sender,
    clock,
    policy: new DefaultDenyPolicyEngine(),
    config: { pepper: PEPPER },
  });
  const login = async (phone = '09123456789', deviceId = DEVICE_A): Promise<LoginResult> => {
    const r = await service.requestOtp({ phone }, { ip: '1.2.3.4' });
    return service.verifyOtp({ challengeId: r.challengeId, code: sender.last?.code ?? '', device: { deviceId, platform: 'web' } }, { ip: '1.2.3.4' });
  };
  return { db, sender, clock, service, login };
}
const rejects = async (p: Promise<unknown>, code: string, kind?: string) => {
  await assert.rejects(p, (e: unknown) => e instanceof AppError && e.code === code && (kind === undefined || e.kind === kind));
};

test('login: phone → OTP → verify → session; OTP never stored in plaintext', async () => {
  const { db, sender, service, login } = setup();
  const res = await login('۰۹۱۲۳۴۵۶۷۸۹');
  assert.equal(res.isNewUser, true);
  assert.equal(sender.sent.length, 1);
  const code = sender.sent[0]?.code ?? '';
  assert.match(code, /^\d{6}$/);
  for (const c of db.challenges.values()) {
    assert.notEqual(c.codeHash, code);
    assert.ok(!JSON.stringify(c).includes(code));
  }
  const p = await service.authenticate(res.accessToken);
  assert.equal(p.userId, res.userId);
  assert.equal(p.organizationId, null);
  // Secrets never reach the audit trail.
  const auditJson = JSON.stringify(db.audit);
  assert.ok(!auditJson.includes(code) && !auditJson.includes(res.accessToken) && !auditJson.includes(res.refreshToken));
  assert.ok(db.audit.some((a) => a.action === 'auth.login' && a.outcome === 'success'));
  // Raw tokens are not stored either.
  assert.ok(![...db.sessions.values()].some((s) => s.accessTokenHash === res.accessToken));
  assert.ok(![...db.refresh.values()].some((r) => r.tokenHash === res.refreshToken));
});

test('login: existing user logs in again (not new)', async () => {
  const { clock, login } = setup();
  const a = await login();
  clock.advance(61);
  const b = await login();
  assert.equal(a.userId, b.userId);
  assert.equal(b.isNewUser, false);
});

test('otp: replay of a consumed code is rejected', async () => {
  const { service, sender } = setup();
  const r = await service.requestOtp({ phone: '09123456789' });
  const code = sender.last?.code ?? '';
  await service.verifyOtp({ challengeId: r.challengeId, code, device: { deviceId: DEVICE_A } });
  await rejects(service.verifyOtp({ challengeId: r.challengeId, code, device: { deviceId: DEVICE_A } }), 'OTP_ALREADY_USED', 'unauthenticated');
});

test('otp: failed attempts are PERSISTED (not rolled back) and lock the challenge', async () => {
  const { db, service, sender } = setup();
  const r = await service.requestOtp({ phone: '09123456789' });
  const good = sender.last?.code ?? '';
  const bad = good === '000000' ? '111111' : '000000';
  for (let i = 1; i <= 5; i++) {
    await assert.rejects(
      service.verifyOtp({ challengeId: r.challengeId, code: bad, device: { deviceId: DEVICE_A } }),
      (e: unknown) => e instanceof AppError && e.code === 'OTP_INVALID' && e.details?.['remainingAttempts'] === 5 - i,
    );
    assert.equal(db.challenges.get(r.challengeId)?.attempts, i);
  }
  assert.ok(db.challenges.get(r.challengeId)?.lockedAt);
  await rejects(service.verifyOtp({ challengeId: r.challengeId, code: good, device: { deviceId: DEVICE_A } }), 'OTP_LOCKED', 'rate_limited');
  assert.equal(db.sessions.size, 0);
});

test('otp: expired challenge and unknown challenge are rejected', async () => {
  const { clock, service, sender } = setup();
  const r = await service.requestOtp({ phone: '09123456789' });
  clock.advance(121);
  await rejects(service.verifyOtp({ challengeId: r.challengeId, code: sender.last?.code ?? '', device: { deviceId: DEVICE_A } }), 'OTP_EXPIRED');
  await rejects(service.verifyOtp({ challengeId: '0192f0a0-0000-7000-8000-ffffffffffff', code: '123456', device: { deviceId: DEVICE_A } }), 'OTP_INVALID');
});

test('otp: request rate limiting (cooldown) with persisted denial audit', async () => {
  const { db, service, clock } = setup();
  await service.requestOtp({ phone: '09123456789' }, { ip: '9.9.9.9' });
  await assert.rejects(
    service.requestOtp({ phone: '09123456789' }, { ip: '9.9.9.9' }),
    (e: unknown) => e instanceof AppError && e.code === 'OTP_RATE_LIMITED' && e.kind === 'rate_limited' && typeof e.details?.['retryAfterSeconds'] === 'number',
  );
  assert.ok(db.audit.some((a) => a.action === 'auth.otp.request' && a.outcome === 'denied'));
  clock.advance(61);
  await service.requestOtp({ phone: '09123456789' }, { ip: '9.9.9.9' }); // allowed again
});

test('otp: per-phone hourly cap and invalid phone numbers', async () => {
  const { clock, service } = setup();
  for (let i = 0; i < 5; i++) {
    await service.requestOtp({ phone: '09120000001' });
    clock.advance(61);
  }
  await rejects(service.requestOtp({ phone: '09120000001' }), 'OTP_RATE_LIMITED');
  await rejects(service.requestOtp({ phone: '12345' }), 'PHONE_INVALID', 'validation');
  await rejects(service.requestOtp({ phone: '+14155550123' }), 'PHONE_UNSUPPORTED_REGION', 'validation');
});

test('otp: delivery failure invalidates the challenge', async () => {
  const { db, service, sender } = setup();
  sender.failNext = true;
  await rejects(service.requestOtp({ phone: '09123456789' }), 'OTP_DELIVERY_FAILED');
  const [c] = [...db.challenges.values()];
  assert.ok(c?.consumedAt);
});

test('device id must be present and long enough', async () => {
  const { service, sender } = setup();
  const r = await service.requestOtp({ phone: '09123456789' });
  await rejects(service.verifyOtp({ challengeId: r.challengeId, code: sender.last?.code ?? '', device: { deviceId: 'short' } }), 'DEVICE_ID_INVALID', 'validation');
});

test('refresh: rotation issues a new pair; old access token stops working', async () => {
  const { service, login } = setup();
  const s = await login();
  const next = await service.refresh({ refreshToken: s.refreshToken });
  assert.notEqual(next.refreshToken, s.refreshToken);
  await rejects(service.authenticate(s.accessToken), 'UNAUTHENTICATED');
  const p = await service.authenticate(next.accessToken);
  assert.equal(p.sessionId, s.sessionId);
});

test('refresh: REUSE of a rotated token revokes the whole session (including the newest token)', async () => {
  const { db, service, login } = setup();
  const s = await login();
  const gen2 = await service.refresh({ refreshToken: s.refreshToken });
  // Attacker (or buggy client) replays the already-used generation-1 token:
  await rejects(service.refresh({ refreshToken: s.refreshToken }), 'REFRESH_REUSED', 'unauthenticated');
  // Everything derived from that session is now dead:
  await rejects(service.refresh({ refreshToken: gen2.refreshToken }), 'REFRESH_INVALID');
  await rejects(service.authenticate(gen2.accessToken), 'UNAUTHENTICATED');
  assert.equal(db.sessions.get(s.sessionId)?.revokedReason, 'refresh_reuse_detected');
  assert.ok(db.audit.some((a) => a.action === 'auth.refresh.reuse_detected'));
});

test('refresh: expired / garbage tokens are rejected', async () => {
  const { clock, service, login } = setup();
  const s = await login();
  await rejects(service.refresh({ refreshToken: 'nonsense' }), 'REFRESH_INVALID');
  await rejects(service.refresh({ refreshToken: 'rhy_rt_' + 'A'.repeat(43) }), 'REFRESH_INVALID');
  clock.advance(31 * 24 * 3600);
  await rejects(service.refresh({ refreshToken: s.refreshToken }), 'REFRESH_INVALID');
});

test('authenticate: access token expires after its TTL; garbage rejected', async () => {
  const { clock, service, login } = setup();
  const s = await login();
  clock.advance(14 * 60);
  await service.authenticate(s.accessToken);
  clock.advance(2 * 60);
  await rejects(service.authenticate(s.accessToken), 'UNAUTHENTICATED');
  await rejects(service.authenticate(undefined), 'UNAUTHENTICATED');
  await rejects(service.authenticate('Bearer x'), 'UNAUTHENTICATED');
});

test('logout revokes the session', async () => {
  const { service, login } = setup();
  const s = await login();
  const p = await service.authenticate(s.accessToken);
  await service.logout(p);
  await rejects(service.authenticate(s.accessToken), 'UNAUTHENTICATED');
  await rejects(service.refresh({ refreshToken: s.refreshToken }), 'REFRESH_INVALID');
});

test('device revoke: kills its sessions and blocks new logins from that device', async () => {
  const { clock, service, login } = setup();
  const s1 = await login('09123456789', DEVICE_A);
  clock.advance(61);
  const s2 = await login('09123456789', DEVICE_B);
  const p2 = await service.authenticate(s2.accessToken);
  const devices = await service.listDevices(p2);
  assert.equal(devices.length, 2);
  const target = devices.find((d) => d.label === null && d.id !== p2.deviceId);
  assert.ok(target);
  await service.revokeDevice(p2, target.id);
  await rejects(service.authenticate(s1.accessToken), 'UNAUTHENTICATED');
  await service.authenticate(s2.accessToken); // other device unaffected
  clock.advance(61);
  await rejects(login('09123456789', DEVICE_A), 'DEVICE_REVOKED', 'forbidden');
});

test('sessions: a user cannot see or revoke another user\'s session or device', async () => {
  const { service, login, clock } = setup();
  const a = await login('09120000001', DEVICE_A);
  clock.advance(61);
  const b = await login('09120000002', DEVICE_B);
  const pa = await service.authenticate(a.accessToken);
  const pb = await service.authenticate(b.accessToken);
  await rejects(service.revokeSession(pb, pa.sessionId), 'SESSION_NOT_FOUND', 'not_found');
  await rejects(service.revokeSession(pb, '0192f0a0-0000-7000-8000-ffffffffffff'), 'SESSION_NOT_FOUND');
  await rejects(service.revokeDevice(pb, pa.deviceId), 'DEVICE_NOT_FOUND', 'not_found');
  assert.equal((await service.listSessions(pb)).every((s) => s.id === pb.sessionId), true);
  await service.authenticate(a.accessToken); // A untouched
  await service.revokeSession(pa, pa.sessionId);
  await rejects(service.authenticate(a.accessToken), 'UNAUTHENTICATED');
});

test('disabled accounts cannot log in and no session is created', async () => {
  const { db, service, sender, clock } = setup();
  const r1 = await service.requestOtp({ phone: '09123456789' });
  await service.verifyOtp({ challengeId: r1.challengeId, code: sender.last?.code ?? '', device: { deviceId: DEVICE_A } });
  const [u] = [...db.users.values()];
  assert.ok(u);
  db.users.set(u.id, { ...u, status: 'disabled' });
  const sessionsBefore = db.sessions.size;
  clock.advance(61);
  const r2 = await service.requestOtp({ phone: '09123456789' });
  await rejects(service.verifyOtp({ challengeId: r2.challengeId, code: sender.last?.code ?? '', device: { deviceId: DEVICE_A } }), 'ACCOUNT_DISABLED', 'forbidden');
  assert.equal(db.sessions.size, sessionsBefore);
});

test('otp: requesting a new code supersedes older open codes (only the newest is valid)', async () => {
  const { service, sender, clock } = setup();
  const r1 = await service.requestOtp({ phone: '09123456789' });
  const code1 = sender.last?.code ?? '';
  clock.advance(61);
  const r2 = await service.requestOtp({ phone: '09123456789' });
  await rejects(service.verifyOtp({ challengeId: r1.challengeId, code: code1, device: { deviceId: DEVICE_A } }), 'OTP_ALREADY_USED');
  await service.verifyOtp({ challengeId: r2.challengeId, code: sender.last?.code ?? '', device: { deviceId: DEVICE_A } });
});
