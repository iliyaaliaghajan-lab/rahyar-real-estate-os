import { CanActivate, ExecutionContext, Inject, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AppError } from '@rahyar/domain-kernel';
import { IS_PUBLIC, type AuthedRequest } from '../../../platform/http/http.ts';
import { AuthService } from '../application/auth.service.ts';

/** Global default-deny: every route requires a valid session unless explicitly marked @Public(). */
@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    @Inject(Reflector) private readonly reflector: Reflector,
    @Inject(AuthService) private readonly auth: AuthService,
  ) {}

  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    if (this.reflector.getAllAndOverride<boolean>(IS_PUBLIC, [ctx.getHandler(), ctx.getClass()])) return true;
    const req = ctx.switchToHttp().getRequest<AuthedRequest>();
    const header = req.headers.authorization;
    if (typeof header !== 'string' || !header.startsWith('Bearer ')) {
      throw new AppError('unauthenticated', 'UNAUTHENTICATED', 'Authentication required.');
    }
    // Tenant comes from the verified session + live membership, never from headers/body/query.
    req.principal = await this.auth.authenticate(header.slice(7));
    return true;
  }
}
