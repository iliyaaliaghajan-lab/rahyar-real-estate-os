import { AppError } from './errors.ts';

/**
 * Canonical monetary representation: integer Rials (IRR) as bigint. No floats, ever.
 * Toman exists only at the presentation boundary (1 Toman = 10 Rial).
 */
export type Currency = 'IRR';
export type Money = { readonly amountMinor: bigint; readonly currency: Currency };

export const irr = (amountMinor: bigint | number | string): Money => {
  if (typeof amountMinor === 'number' && !Number.isSafeInteger(amountMinor)) {
    throw new AppError('validation', 'MONEY_NOT_INTEGER', 'Monetary amounts must be safe integers.');
  }
  if (typeof amountMinor === 'string' && !/^-?\d+$/.test(amountMinor)) {
    throw new AppError('validation', 'MONEY_NOT_INTEGER', 'Monetary amounts must be integer strings.');
  }
  return { amountMinor: BigInt(amountMinor), currency: 'IRR' };
};

const same = (a: Money, b: Money): void => {
  if (a.currency !== b.currency) {
    throw new AppError('validation', 'MONEY_CURRENCY_MISMATCH', 'Currency mismatch.');
  }
};
export const addMoney = (a: Money, b: Money): Money => (same(a, b), irr(a.amountMinor + b.amountMinor));
export const subMoney = (a: Money, b: Money): Money => (same(a, b), irr(a.amountMinor - b.amountMinor));

/** Wire format: amount as a decimal string so JSON never loses precision. */
export type MoneyDto = { readonly amount: string; readonly currency: Currency };
export const toDto = (m: Money): MoneyDto => ({ amount: m.amountMinor.toString(), currency: m.currency });
export const fromDto = (d: MoneyDto): Money => {
  if (d.currency !== 'IRR') {
    throw new AppError('validation', 'MONEY_CURRENCY_UNSUPPORTED', 'Only IRR is supported.');
  }
  return irr(d.amount);
};

export type DisplayUnit = 'IRR' | 'IRT';

/** Presentation-only. Always states the unit explicitly; Toman is exact (never rounded silently). */
export function formatMoney(m: Money, unit: DisplayUnit, locale = 'fa-IR'): string {
  const nf = new Intl.NumberFormat(locale);
  const label = unit === 'IRT' ? 'تومان' : 'ریال';
  if (unit === 'IRR') return `${nf.format(m.amountMinor)} ${label}`;
  const neg = m.amountMinor < 0n;
  const abs = neg ? -m.amountMinor : m.amountMinor;
  const whole = abs / 10n;
  const rem = abs % 10n;
  let out = nf.format(neg ? -whole : whole);
  if (neg && whole === 0n) out = `-${out}`;
  if (rem !== 0n) {
    const dec = nf.formatToParts(1.1).find((p) => p.type === 'decimal')?.value ?? '.';
    out += `${dec}${nf.format(rem)}`;
  }
  return `${out} ${label}`;
}
