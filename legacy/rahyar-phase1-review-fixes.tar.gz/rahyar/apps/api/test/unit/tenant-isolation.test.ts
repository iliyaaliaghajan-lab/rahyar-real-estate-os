import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DefaultDenyPolicyEngine } from '../../src/modules/authorization/domain/policy-engine.ts';
import { AuthService } from '../../src/modules/identity/application/auth.service.ts';
import { OrganizationService } from '../../src/modules/organization/application/organization.service.ts';
import { CapturingOtpSender, FakeClock, MemoryAuthUow, MemoryDb, MemoryTenantUow } from '../support/in-memory.ts';
import { assertTenantIsolation, seedTenant, type HarnessDeps } from '../support/tenant-harness.ts';

test('tenant isolation harness (in-memory ports): forged principal/context cannot cross tenants', async () => {
  const db = new MemoryDb();
  const sender = new CapturingOtpSender();
  const clock = new FakeClock();
  const policy = new DefaultDenyPolicyEngine();
  const tenantUow = new MemoryTenantUow(db);
  const auth = new AuthService({ uow: new MemoryAuthUow(db), sender, clock, policy, config: { pepper: 'z'.repeat(48) } });
  const orgs = new OrganizationService({ uow: tenantUow, clock, policy });
  const deps: HarnessDeps = {
    auth, orgs, tenantUow,
    login: async (phone, deviceId) => {
      const r = await auth.requestOtp({ phone });
      const s = await auth.verifyOtp({ challengeId: r.challengeId, code: sender.last?.code ?? '', device: { deviceId } });
      clock.advance(61);
      return { accessToken: s.accessToken, sessionId: s.sessionId };
    },
  };
  const a = await seedTenant(deps, '09120000001', 'device-aaaaaaaaaaaaaaaa', 'الف', 'key-aaaaaaaaaa');
  const b = await seedTenant(deps, '09120000002', 'device-bbbbbbbbbbbbbbbb', 'ب‌ب', 'key-bbbbbbbbbb');
  await assertTenantIsolation(deps, a, b);
});

test('bootstrap isolation: write-only facade, no reads, cannot adopt an existing organization id', async () => {
  const db = new MemoryDb();
  const sender = new CapturingOtpSender();
  const clock = new FakeClock();
  const policy = new DefaultDenyPolicyEngine();
  const tenantUow = new MemoryTenantUow(db);
  const auth = new AuthService({ uow: new MemoryAuthUow(db), sender, clock, policy, config: { pepper: 'z'.repeat(48) } });
  const orgs = new OrganizationService({ uow: tenantUow, clock, policy });
  const login = async (phone: string, deviceId: string) => {
    const r = await auth.requestOtp({ phone });
    const s = await auth.verifyOtp({ challengeId: r.challengeId, code: sender.last?.code ?? '', device: { deviceId } });
    clock.advance(61);
    return s;
  };
  const a = await login('09120000001', 'device-aaaaaaaaaaaaaaaa');
  const b = await login('09120000002', 'device-bbbbbbbbbbbbbbbb');
  const pa = await auth.authenticate(a.accessToken);
  const orgA = await orgs.createOrganization(pa, { name: 'الف الف', idempotencyKey: 'key-aaaaaaaaaa' });
  const pb = await auth.authenticate(b.accessToken);
  await tenantUow.bootstrap({ userId: pb.userId, sessionId: pb.sessionId, newOrganizationId: '0192f0a0-0000-7000-8000-00000000beef' }, async (tx) => {
    for (const forbidden of ['getOrganization', 'listAuditLogs']) assert.equal(forbidden in tx, false, forbidden);
  });
  await assert.rejects(
    tenantUow.bootstrap({ userId: pb.userId, sessionId: pb.sessionId, newOrganizationId: orgA.organizationId }, (tx) => tx.insertOrganization({ id: orgA.organizationId, name: 'hijack' })),
  );
  assert.equal(db.orgs.get(orgA.organizationId)?.name, 'الف الف');
});
