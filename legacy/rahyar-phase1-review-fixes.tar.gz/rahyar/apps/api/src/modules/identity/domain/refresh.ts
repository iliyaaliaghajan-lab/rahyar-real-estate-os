export type RefreshRecord = {
  readonly id: string;
  readonly sessionId: string;
  readonly generation: number;
  readonly expiresAt: Date;
  readonly usedAt: Date | null;
  readonly revokedAt: Date | null;
};
export type SessionState = {
  readonly id: string;
  readonly revokedAt: Date | null;
  readonly absoluteExpiresAt: Date;
};

export type RefreshDecision =
  | { readonly decision: 'rotate' }
  | { readonly decision: 'reuse_detected' }
  | { readonly decision: 'reject'; readonly reason: 'session_revoked' | 'session_expired' | 'revoked' | 'expired' };

/**
 * Rotation with reuse detection: each refresh token is single-use. Presenting an already-used token
 * means it was copied (or replayed) — the whole session is revoked, not just the token.
 */
export function evaluateRefresh(record: RefreshRecord, session: SessionState, now: Date): RefreshDecision {
  if (session.revokedAt) return { decision: 'reject', reason: 'session_revoked' };
  if (now.getTime() >= session.absoluteExpiresAt.getTime()) return { decision: 'reject', reason: 'session_expired' };
  if (record.revokedAt) return { decision: 'reject', reason: 'revoked' };
  if (record.usedAt) return { decision: 'reuse_detected' };
  if (now.getTime() >= record.expiresAt.getTime()) return { decision: 'reject', reason: 'expired' };
  return { decision: 'rotate' };
}

export type SessionPolicy = {
  readonly accessTtlSeconds: number;
  readonly refreshTtlSeconds: number;
  readonly absoluteTtlSeconds: number;
  readonly stepUpMaxAgeSeconds: number;
};
export const DEFAULT_SESSION_POLICY: SessionPolicy = {
  accessTtlSeconds: 15 * 60,
  refreshTtlSeconds: 30 * 24 * 3600,
  absoluteTtlSeconds: 90 * 24 * 3600,
  stepUpMaxAgeSeconds: 5 * 60,
};

export const addSeconds = (d: Date, s: number): Date => new Date(d.getTime() + s * 1000);
/** Refresh expiry never extends beyond the session's absolute lifetime. */
export const refreshExpiry = (now: Date, absoluteExpiresAt: Date, p: SessionPolicy): Date =>
  new Date(Math.min(addSeconds(now, p.refreshTtlSeconds).getTime(), absoluteExpiresAt.getTime()));
