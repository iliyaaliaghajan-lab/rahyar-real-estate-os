import js from '@eslint/js';
import tseslint from 'typescript-eslint';

export default tseslint.config(
  { ignores: ['**/dist/**', '**/.next/**', '**/node_modules/**'] },
  js.configs.recommended,
  ...tseslint.configs.strictTypeChecked,
  {
    languageOptions: { parserOptions: { projectService: true, tsconfigRootDir: import.meta.dirname } },
    rules: {
      '@typescript-eslint/no-explicit-any': 'error',
      '@typescript-eslint/consistent-type-imports': 'error',
      'no-restricted-imports': [
        'error',
        {
          patterns: [
            {
              group: ['kysely', 'pg', '@nestjs/*'],
              message: 'Domain layers must not import infrastructure/framework packages.',
            },
          ],
        },
      ],
    },
  },
  {
    // Framework/infrastructure layers may import them.
    files: [
      '**/infrastructure/**',
      '**/platform/**',
      '**/*.module.ts',
      '**/*.controller.ts',
      '**/*.guard.ts',
      '**/main.ts',
      '**/db/**',
      '**/test/**',
    ],
    rules: { 'no-restricted-imports': 'off' },
  },
  { files: ['**/*.mjs', '**/*.js'], extends: [tseslint.configs.disableTypeChecked] },
);
