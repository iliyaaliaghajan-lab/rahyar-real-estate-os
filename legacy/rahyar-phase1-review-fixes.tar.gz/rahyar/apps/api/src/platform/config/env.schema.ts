import { z } from 'zod';

const bool = z.enum(['true', 'false']).transform((v) => v === 'true');

/** Validated at startup; the process refuses to boot on invalid or unsafe configuration. */
export const EnvSchema = z
  .object({
    NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
    // Deployment tier. staging and production are BOTH built with NODE_ENV=production and get the strict rules below.
    APP_ENV: z.enum(['development', 'test', 'staging', 'production']).default('development'),
    HOST: z.string().default('0.0.0.0'),
    PORT: z.coerce.number().int().min(1).max(65535).default(3001),
    LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),

    DATABASE_URL: z.string().url(), // MUST be the restricted rahyar_app role, never the migrator/superuser
    // Privileged migrator credentials: allowed in development/test only; rejected in staging/production.
    DATABASE_MIGRATOR_URL: z.string().url().optional(),
    DATABASE_POOL_MAX: z.coerce.number().int().min(1).max(100).default(10),

    OTP_PEPPER: z.string().min(32, 'OTP_PEPPER must be at least 32 characters'),
    OTP_DELIVERY: z.enum(['console', 'provider']).default('provider'),

    CORS_ORIGINS: z.string().default(''), // comma-separated allowlist; empty = no cross-origin access
    TRUST_PROXY: bool.default('false'),
    RATE_LIMIT_MAX: z.coerce.number().int().min(1).default(120),

    // Reserved for later phases; validated now so misconfiguration is caught early. Not used in Phase 1.
    REDIS_URL: z.string().url().optional(),
    S3_ENDPOINT: z.string().url().optional(),
    S3_BUCKET: z.string().optional(),
    AI_PROVIDER: z.enum(['none', 'anthropic']).default('none'),
    AI_API_KEY: z.string().optional(),
  })
  .superRefine((env, ctx) => {
    const strict = env.NODE_ENV === 'production' || env.APP_ENV === 'staging' || env.APP_ENV === 'production';
    if (env.APP_ENV === 'test' && env.NODE_ENV === 'production') {
      ctx.addIssue({ code: 'custom', path: ['APP_ENV'], message: 'test tier must not run with NODE_ENV=production' });
    }
    if (strict) {
      if (env.DATABASE_MIGRATOR_URL) {
        ctx.addIssue({ code: 'custom', path: ['DATABASE_MIGRATOR_URL'], message: 'migrator credentials must not be present in the running API environment' });
      }
      if (env.TRUST_PROXY !== true) {
        ctx.addIssue({ code: 'custom', path: ['TRUST_PROXY'], message: 'TRUST_PROXY=true is required (API sits behind the BFF/edge; per-client IP limits depend on it)' });
      }
      if (env.OTP_DELIVERY === 'console') {
        ctx.addIssue({ code: 'custom', path: ['OTP_DELIVERY'], message: 'console OTP delivery is forbidden in production' });
      }
      const user = new URL(env.DATABASE_URL).username;
      if (['postgres', 'rahyar_migrator'].includes(user)) {
        ctx.addIssue({ code: 'custom', path: ['DATABASE_URL'], message: 'application must not connect as a privileged role' });
      }
      if (/change[-_]?me|example|0000000/i.test(env.OTP_PEPPER)) {
        ctx.addIssue({ code: 'custom', path: ['OTP_PEPPER'], message: 'placeholder pepper in production' });
      }
    }
    if (env.AI_PROVIDER !== 'none' && !env.AI_API_KEY) {
      ctx.addIssue({ code: 'custom', path: ['AI_API_KEY'], message: 'AI_API_KEY required when AI_PROVIDER is set' });
    }
  });

export type Env = z.infer<typeof EnvSchema>;

export function loadEnv(source: NodeJS.ProcessEnv = process.env): Env {
  const parsed = EnvSchema.safeParse(source);
  if (!parsed.success) {
    // Names and messages only — never echo values (they may be secrets).
    const lines = parsed.error.issues.map((i) => `  - ${i.path.join('.')}: ${i.message}`);
    throw new Error(`Invalid environment configuration:\n${lines.join('\n')}`);
  }
  return parsed.data;
}
