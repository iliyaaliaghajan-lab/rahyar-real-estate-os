import { createHash, createHmac, randomBytes } from 'node:crypto';

export type TokenKind = 'access' | 'refresh';
const PREFIX: Record<TokenKind, string> = { access: 'rhy_at_', refresh: 'rhy_rt_' };

/** 256-bit opaque bearer tokens. Only a SHA-256 digest is stored; tokens are never logged. */
export function generateToken(kind: TokenKind): string {
  return PREFIX[kind] + randomBytes(32).toString('base64url');
}

export const hashToken = (token: string): string => createHash('sha256').update(token).digest('hex');

export function hasTokenShape(kind: TokenKind, token: unknown): token is string {
  return (
    typeof token === 'string' &&
    token.startsWith(PREFIX[kind]) &&
    /^[A-Za-z0-9_-]{43}$/.test(token.slice(PREFIX[kind].length))
  );
}

/** Keyed hash for low-entropy identifiers (IPs, device fingerprints) so raw values are not stored. */
export const keyedHash = (pepper: string, namespace: string, value: string): string =>
  createHmac('sha256', pepper).update(`${namespace}\u0000${value}`).digest('hex');
