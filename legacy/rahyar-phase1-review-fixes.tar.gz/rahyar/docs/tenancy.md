# Tenancy & RLS

* Tenant-owned tables carry `organization_id`; RLS is `ENABLE`d **and** `FORCE`d on every table.
* App role `rahyar_app`: NOSUPERUSER, NOBYPASSRLS, owns nothing (startup self-check `assertSafeApplicationRole`; CI catalog test).
* Context is transaction-scoped: `set_config('app.org_id'|'app.user_id'|'app.scope', value, true)`; pooled connections cannot leak it.
  Malformed values raise (fail closed). No context ⇒ zero rows.
* The organization id is **never** taken from headers/query/body. It comes from the verified session and is re-validated against an
  ACTIVE membership in `withTenantContext` (single choke point). Only `bootstrapOrganization` (creating a new tenant) skips that check.
* `auth` scope exists only for pre-authentication flows (OTP, token lookup, refresh) and is set by the DB layer, not by request data.
* Composite FK `(organization_id, role_id) → roles(organization_id, id)` prevents cross-tenant role assignment.
* Users/devices/sessions are user-scoped (global identity); a session's `organization_id` is its *active* tenant.
* Select policies on `organizations` and `organization_memberships` widen to "all of the user's orgs" **only when no org is bound**
  (login / org switcher). Inside an org-bound transaction only that org is visible, even to a user who belongs to several.
* Self-service session/device operations run in a **user-bound** transaction (`runAsUser`), so RLS — not only application code —
  confines them to the caller's own rows. Only token lookup, OTP and refresh use the `auth` scope.
* Creating a tenant uses `TenantUnitOfWork.bootstrap`: a server-generated org id, RLS admitting rows for exactly that id, a primary
  key that rejects an existing id, and a **write-only** transaction facade (no reads). The generic `run()` has no bypass flag.
* Audit inserts must name the bound user as actor (or the trusted auth flow / a system actor); actors cannot be forged.

Known boundary: RLS trusts `app.org_id` as set by trusted server code. A SQL-injection or code-execution bug in the API process could set it;
mitigations are parameterised queries only (Kysely), no raw SQL from AI/plugins, and the membership check above.
